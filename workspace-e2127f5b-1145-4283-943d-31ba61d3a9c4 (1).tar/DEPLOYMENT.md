# Panduan Deployment - Sistem Absensi Siswa

## Opsi 1: Deploy ke Vercel (Rekomendasi - Gratis)

### Langkah 1: Push ke GitHub

1. Buat repository baru di GitHub
2. Push kode dari lokal:
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/absensi-siswa.git
git push -u origin main
```

### Langkah 2: Deploy ke Vercel

1. Buka https://vercel.com
2. Login dengan akun GitHub
3. Klik "Add New..." → "Project"
4. Import repository dari GitHub
5. Konfigurasi project:
   - Framework Preset: **Next.js**
   - Root Directory: ./
   - Build Command: `bun run build`
   - Output Directory: `.next`

### Langkah 3: Setting Environment Variables

Di dashboard Vercel, tambahkan environment variables:
```
JWT_SECRET=your-super-secret-key-change-in-production-min-32-characters
DATABASE_URL=file:./prod.db
```

### Langkah 4: Deploy

1. Klik "Deploy"
2. Tunggu proses build selesai
3. Aplikasi akan tersedia di: `https://absensi-siswa.vercel.app`

### Langkah 5: Custom Domain (Opsional)

Jika ingin menggunakan subdomain `maalmujahidinsmd.sch.id/absensi`:

**Opsi A: Subdomain penuh (maalmujahidinsmd.sch.id)**
1. Di Vercel Dashboard → Settings → Domains
2. Tambahkan domain: `maalmujahidinsmd.sch.id`
3. Di IDWebHost, ubah DNS A record ke IP Vercel

**Opsi B: Path subdomain (/absensi)**
- Tidak bisa langsung, karena Vercel tidak mendukung path-based routing
- Alternatif: Gunakan iframe redirect atau reverse proxy di hosting utama

---

## Opsi 2: Deploy ke VPS/Cloud Server

### Persyaratan:
- Server dengan Node.js 18+ dan bun/npm
- Akses SSH ke server
- IP Public atau domain

### Langkah 1: Siapkan Server

```bash
# Install Node.js (Ubuntu/Debian)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install bun
curl -fsSL https://bun.sh/install | bash

# Install PM2 (process manager)
sudo npm install -g pm2
```

### Langkah 2: Upload Aplikasi

```bash
# Di server
mkdir -p /var/www/absensi
cd /var/www/absensi

# Clone dari git atau upload via SCP
git clone https://github.com/USERNAME/absensi-siswa.git .
```

### Langkah 3: Install Dependencies & Build

```bash
bun install
bun run build
```

### Langkah 4: Setup Database

```bash
bun run db:push
```

### Langkah 5: Jalankan dengan PM2

```bash
pm2 start bun --name "absensi" -- run start
pm2 save
pm2 startup
```

### Langkah 6: Setup Nginx Reverse Proxy

```nginx
server {
    listen 80;
    server_name maalmujahidinsmd.sch.id;
    
    location /absensi/ {
        proxy_pass http://localhost:3000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### Langkah 7: SSL dengan Let's Encrypt

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d maalmujahidinsmd.sch.id
```

---

## Opsi 3: Deploy ke IDWebHost dengan Subdomain

### Catatan Penting:
Shared hosting IDWebHost biasanya **TIDAK mendukung Node.js**.
Jadi ada 2 alternatif:

### Alternatif A: Gunakan VPS dari IDWebHost
- Upgrade ke paket VPS yang mendukung Node.js
- Ikuti langkah Opsi 2 di atas

### Alternatif B: Hosting Hybrid
1. **Aplikasi di Vercel/Cloud** - `https://absensi-maalmujahidin.vercel.app`
2. **Subdomain di IDWebHost** pointing ke Vercel

**Setup di IDWebHost:**
1. Login ke cPanel IDWebHost
2. Masuk ke "Subdomains"
3. Buat subdomain: `absensi.maalmujahidinsmd.sch.id`
4. Masuk ke "Zone Editor" / DNS Management
5. Tambahkan CNAME record:
   - Name: `absensi`
   - CNAME: `cname.vercel-dns.com`

6. Di Vercel, tambahkan domain `absensi.maalmujahidinsmd.sch.id`

---

## Checklist Sebelum Deploy

- [ ] Ganti `JWT_SECRET` dengan string random yang kuat (min 32 karakter)
- [ ] Pastikan database sudah disetup
- [ ] Test build lokal: `bun run build`
- [ ] Test production mode: `bun run start`

## Environment Variables yang Diperlukan

```env
# Required
JWT_SECRET=your-super-secret-key-min-32-characters-long-random-string

# Database (SQLite - default)
DATABASE_URL=file:./db/custom.db

# Optional - untuk production database
# DATABASE_URL=mysql://user:password@localhost:3306/dbname
```

## Troubleshooting

### Error: Prisma Client not found
```bash
bun run db:generate
```

### Error: Database locked
- Untuk SQLite, pastikan tidak ada proses lain yang mengakses database
- Pertimbangkan upgrade ke MySQL/PostgreSQL untuk production

### Port already in use
```bash
# Cari proses yang menggunakan port
lsof -i :3000
# Kill proses
kill -9 <PID>
```

---

## Rekomendasi Final

Untuk kemudahan dan keandalan, saya rekomendasikan:

1. **Vercel** untuk hosting aplikasi (gratis, optimal untuk Next.js)
2. **Vercel Postgres** atau **PlanetScale** untuk database production
3. **Subdomain**: `absensi.maalmujahidinsmd.sch.id` pointing ke Vercel

Dengan setup ini, aplikasi akan:
- ✅ Auto-deploy setiap push ke GitHub
- ✅ SSL gratis
- ✅ CDN global
- ✅ High availability
- ✅ Monitoring built-in
