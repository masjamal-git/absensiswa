# 🎓 Sistem Absensi Siswa

Sistem Informasi Absensi Siswa berbasis Web yang modern, responsif, dan siap production untuk yayasan pendidikan (multi sekolah).

![Next.js](https://img.shields.io/badge/Next.js-16-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-38B2AC)
![Prisma](https://img.shields.io/badge/Prisma-ORM-2D3748)

## ✨ Fitur Utama

### 1. 📱 Absensi QR Code
- Generate QR unik untuk setiap siswa (secure token)
- Scan menggunakan kamera (web-based)
- Respon < 1 detik
- Notifikasi visual + suara saat berhasil

### 2. ✍️ Mode Manual
- Input absensi tanpa QR (cari nama / NIS)
- Tetap kirim notifikasi WhatsApp

### 3. 📲 Notifikasi WhatsApp
- Integrasi WhatsApp API (Fonnte / Twilio)
- Kirim otomatis: "Ananda [Nama] telah hadir pukul [Jam]"
- Retry jika gagal
- Mock mode untuk testing

### 4. 📊 Dashboard Admin
- Statistik kehadiran realtime
- Grafik Pie & Bar Chart
- Data siswa & orang tua
- Multi sekolah support

### 5. ⏰ Deteksi Terlambat
- Jam masuk configurable
- Auto tandai "Terlambat"

### 6. 📄 Laporan
- Export PDF & Excel
- Filter berdasarkan tanggal, kelas, status

## 🔐 Keamanan

- JWT Authentication
- Enkripsi token QR
- Proteksi API
- Environment variables

## 🛠️ Teknologi

| Frontend | Backend | Database |
|----------|---------|----------|
| Next.js 16 | Node.js | SQLite (Prisma) |
| Tailwind CSS 4 | Socket.io | PostgreSQL Ready |
| shadcn/ui | JWT Auth | |
| Recharts | Zod Validation | |
| html5-qrcode | | |

## 📦 Instalasi

### Prerequisites
- Node.js 18+
- Bun / npm / yarn
- Git

### Langkah Instalasi

```bash
# Clone repository
git clone <repository-url>
cd sistem-absensi-siswa

# Install dependencies
bun install

# Copy environment variables
cp .env.example .env

# Generate Prisma Client
bun run db:generate

# Push database schema
bun run db:push

# Start development server
bun run dev
```

### Inisialisasi Data

1. Buka aplikasi di browser
2. Klik tombol "Inisialisasi Database"
3. Login dengan akun demo:
   - Email: `superadmin@nurulhuda.sch.id`
   - Password: `admin123`

## 📁 Struktur Project

```
├── prisma/
│   └── schema.prisma       # Database schema
├── src/
│   ├── app/
│   │   ├── api/            # API Routes
│   │   │   ├── auth/       # Authentication
│   │   │   ├── absensi/    # Attendance
│   │   │   ├── siswa/      # Students
│   │   │   ├── sekolah/    # Schools
│   │   │   ├── dashboard/  # Statistics
│   │   │   ├── export/     # PDF/Excel Export
│   │   │   ├── qr/         # QR Code
│   │   │   └── init/       # Database Init
│   │   ├── layout.tsx
│   │   ├── page.tsx        # Main Application
│   │   └── globals.css
│   ├── lib/
│   │   ├── auth.ts         # JWT & Auth Utilities
│   │   ├── qrcode.ts       # QR Code Generation
│   │   ├── whatsapp.ts     # WhatsApp Service
│   │   ├── store.ts        # Zustand Store
│   │   └── db.ts           # Prisma Client
│   └── components/ui/      # shadcn/ui Components
├── mini-services/
│   └── realtime-service/   # Socket.io Service
└── .env.example
```

## 🚀 Deployment

### Deploy ke Vercel (Frontend)

1. Push code ke GitHub
2. Hubungkan repository ke Vercel
3. Set environment variables di Vercel:
   - `DATABASE_URL` - PostgreSQL connection string
   - `JWT_SECRET` - Secret key untuk JWT
   - `QR_SECRET` - Secret key untuk QR token
   - `WHATSAPP_PROVIDER` - 'mock' atau 'fonnte'
   - `WHATSAPP_API_KEY` - API key dari Fonnte

4. Deploy!

### Deploy ke Railway (Database + Backend)

1. Buat project baru di Railway
2. Add PostgreSQL database
3. Deploy sebagai service:
   ```bash
   railway login
   railway init
   railway up
   ```

### Menggunakan PostgreSQL

1. Update `prisma/schema.prisma`:
   ```prisma
   datasource db {
     provider = "postgresql"
     url      = env("DATABASE_URL")
   }
   ```

2. Set `DATABASE_URL` di `.env`:
   ```
   DATABASE_URL="postgresql://user:password@host:5432/absensi?schema=public"
   ```

3. Run migration:
   ```bash
   bun run db:push
   ```

## 📱 Integrasi WhatsApp

### Menggunakan Fonnte (Indonesia)

1. Daftar di [fonnte.com](https://fonnte.com)
2. Dapatkan API Key
3. Set environment variables:
   ```
   WHATSAPP_PROVIDER=fonnte
   WHATSAPP_API_KEY=your-api-key
   ```

### Menggunakan Twilio

1. Daftar di [twilio.com](https://www.twilio.com/whatsapp)
2. Dapatkan Account SID dan Auth Token
3. Set environment variables:
   ```
   WHATSAPP_PROVIDER=twilio
   TWILIO_ACCOUNT_SID=your-account-sid
   TWILIO_AUTH_TOKEN=your-auth-token
   TWILIO_PHONE_NUMBER=whatsapp:+14155238886
   ```

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login user |
| POST | `/api/auth/logout` | Logout user |
| GET | `/api/auth/me` | Get current user |
| GET | `/api/sekolah` | List schools |
| GET | `/api/siswa` | List students |
| POST | `/api/siswa` | Create student |
| POST | `/api/absensi` | Record attendance (QR/Manual) |
| GET | `/api/absensi` | Get attendance records |
| GET | `/api/dashboard` | Dashboard statistics |
| GET | `/api/qr` | Get QR code for student |
| POST | `/api/qr` | Regenerate QR token |
| GET | `/api/export` | Export PDF/Excel |
| POST | `/api/init` | Initialize database |

## 🧪 Testing

### Akun Demo

| Role | Email | Password |
|------|-------|----------|
| Super Admin | superadmin@nurulhuda.sch.id | admin123 |
| Admin SD | admin.sd@nurulhuda.sch.id | admin123 |
| Admin SMP | admin.smp@nurulhuda.sch.id | admin123 |
| Operator | operator@nurulhuda.sch.id | admin123 |

### QR Code Testing

Setelah inisialisasi database, setiap siswa memiliki QR token yang bisa di-scan untuk mencatat absensi.

## 📊 Database Schema

```mermaid
erDiagram
    Yayasan ||--o{ Sekolah : has
    Sekolah ||--o{ Kelas : has
    Sekolah ||--o{ Siswa : has
    Kelas ||--o{ Siswa : has
    Siswa ||--o{ Absensi : has
    User ||--o{ LogAktivitas : has
    Yayasan ||--o{ User : has
    Sekolah ||--o{ User : has
```

## 🤝 Kontribusi

1. Fork repository
2. Buat branch fitur (`git checkout -b feature/AmazingFeature`)
3. Commit perubahan (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buat Pull Request

## 📄 Lisensi

MIT License - Lihat file [LICENSE](LICENSE) untuk detail.

## 👨‍💻 Developer

Developed with ❤️ for Indonesian Education

---

**Sistem Absensi Siswa** - Solusi modern untuk manajemen kehadiran siswa berbasis QR Code dengan notifikasi WhatsApp real-time.
