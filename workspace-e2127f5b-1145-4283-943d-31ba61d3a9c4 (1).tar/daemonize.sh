#!/bin/bash
cd /home/z/my-project

# Double fork to daemonize
(
  setsid bash -c '
    cd /home/z/my-project
    while true; do
      echo "[$(date)] Starting Next.js..." > /home/z/my-project/dev.log
      bun run dev >> /home/z/my-project/dev.log 2>&1
      echo "[$(date)] Restarting in 3s..." >> /home/z/my-project/dev.log
      sleep 3
    done
  ' &
  disown
) &

disown
echo "Daemon started"
