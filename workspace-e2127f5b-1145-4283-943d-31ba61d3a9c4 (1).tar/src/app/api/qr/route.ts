import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';
import { generateQRCodeDataURL, regenerateQRToken } from '@/lib/qrcode';

// GET - Get QR code for a student
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const siswaId = searchParams.get('siswaId');
    
    if (!siswaId) {
      return NextResponse.json(
        { success: false, message: 'Siswa ID wajib diisi' },
        { status: 400 }
      );
    }
    
    const siswa = await db.siswa.findUnique({
      where: { id: siswaId },
      include: {
        kelas: { select: { nama: true } },
        sekolah: { select: { id: true, nama: true } }
      }
    });
    
    if (!siswa) {
      return NextResponse.json(
        { success: false, message: 'Siswa tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!hasAccessToSekolah(user, siswa.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Generate QR code
    const qrDataURL = await generateQRCodeDataURL(siswa.qrToken);
    
    return NextResponse.json({
      success: true,
      data: {
        siswa: {
          id: siswa.id,
          nama: siswa.nama,
          nis: siswa.nis,
          kelas: siswa.kelas?.nama || '-',
          sekolah: siswa.sekolah?.nama || '-'
        },
        qrCode: qrDataURL,
        qrToken: siswa.qrToken,
        qrExpiredAt: siswa.qrExpiredAt
      }
    });
  } catch (error) {
    console.error('Get QR error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// POST - Regenerate QR token
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const { siswaId } = body;
    
    if (!siswaId) {
      return NextResponse.json(
        { success: false, message: 'Siswa ID wajib diisi' },
        { status: 400 }
      );
    }
    
    const siswa = await db.siswa.findUnique({
      where: { id: siswaId },
      include: { sekolah: { select: { id: true } } }
    });
    
    if (!siswa) {
      return NextResponse.json(
        { success: false, message: 'Siswa tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!hasAccessToSekolah(user, siswa.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Regenerate QR token
    const newToken = await regenerateQRToken(siswaId);
    const qrDataURL = await generateQRCodeDataURL(newToken);
    
    return NextResponse.json({
      success: true,
      message: 'QR Code berhasil diperbarui',
      data: {
        qrCode: qrDataURL,
        qrToken: newToken
      }
    });
  } catch (error) {
    console.error('Regenerate QR error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
