import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { regenerateQRToken } from '@/lib/qrcode';
import { z } from 'zod';

// Helper function to check access
function checkAccess(user: any, sekolahId: string): boolean {
  if (user.role === 'SUPER_ADMIN') return true;
  if (user.sekolahId === sekolahId) return true;
  return false;
}

const updateSiswaSchema = z.object({
  nis: z.string().min(1, 'NIS wajib diisi').optional(),
  nisn: z.string().optional().nullable(),
  nama: z.string().min(1, 'Nama wajib diisi').optional(),
  jenisKelamin: z.enum(['L', 'P']).optional(),
  tempatLahir: z.string().optional().nullable(),
  tanggalLahir: z.string().optional().nullable(),
  alamat: z.string().optional().nullable(),
  kelasId: z.string().min(1, 'Kelas wajib dipilih').optional(),
  namaAyah: z.string().optional().nullable(),
  pekerjaanAyah: z.string().optional().nullable(),
  phoneAyah: z.string().optional().nullable(),
  namaIbu: z.string().optional().nullable(),
  pekerjaanIbu: z.string().optional().nullable(),
  phoneIbu: z.string().optional().nullable(),
  namaWali: z.string().optional().nullable(),
  phoneWali: z.string().optional().nullable(),
  foto: z.string().optional().nullable(), // Base64 image
  isActive: z.boolean().optional()
});

// GET - Get single siswa
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    
    const siswa = await db.siswa.findUnique({
      where: { id },
      include: {
        kelas: {
          select: { id: true, nama: true, tingkat: true }
        },
        sekolah: {
          select: { id: true, nama: true, jamMasuk: true, jamToleransi: true }
        }
      }
    });
    
    if (!siswa) {
      return NextResponse.json(
        { success: false, message: 'Siswa tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, siswa.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: siswa
    });
  } catch (error) {
    console.error('Get siswa error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// PUT - Update siswa
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    const body = await request.json();
    const validation = updateSiswaSchema.safeParse(body);
    
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: 'Input tidak valid', errors: validation.error.flatten() },
        { status: 400 }
      );
    }
    
    const data = validation.data;
    
    // Get existing siswa
    const existingSiswa = await db.siswa.findUnique({
      where: { id }
    });
    
    if (!existingSiswa) {
      return NextResponse.json(
        { success: false, message: 'Siswa tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, existingSiswa.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if NIS already exists (if changing NIS)
    if (data.nis && data.nis !== existingSiswa.nis) {
      const duplicateNIS = await db.siswa.findFirst({
        where: {
          sekolahId: existingSiswa.sekolahId,
          nis: data.nis,
          id: { not: id }
        }
      });
      
      if (duplicateNIS) {
        return NextResponse.json(
          { success: false, message: 'NIS sudah digunakan siswa lain' },
          { status: 400 }
        );
      }
    }
    
    // Prepare update data
    const updateData: any = {};
    
    if (data.nis !== undefined) updateData.nis = data.nis;
    if (data.nisn !== undefined) updateData.nisn = data.nisn;
    if (data.nama !== undefined) updateData.nama = data.nama;
    if (data.jenisKelamin !== undefined) updateData.jenisKelamin = data.jenisKelamin;
    if (data.tempatLahir !== undefined) updateData.tempatLahir = data.tempatLahir;
    if (data.tanggalLahir !== undefined) updateData.tanggalLahir = data.tanggalLahir ? new Date(data.tanggalLahir) : null;
    if (data.alamat !== undefined) updateData.alamat = data.alamat;
    if (data.kelasId !== undefined) updateData.kelasId = data.kelasId;
    if (data.namaAyah !== undefined) updateData.namaAyah = data.namaAyah;
    if (data.pekerjaanAyah !== undefined) updateData.pekerjaanAyah = data.pekerjaanAyah;
    if (data.phoneAyah !== undefined) updateData.phoneAyah = data.phoneAyah;
    if (data.namaIbu !== undefined) updateData.namaIbu = data.namaIbu;
    if (data.pekerjaanIbu !== undefined) updateData.pekerjaanIbu = data.pekerjaanIbu;
    if (data.phoneIbu !== undefined) updateData.phoneIbu = data.phoneIbu;
    if (data.namaWali !== undefined) updateData.namaWali = data.namaWali;
    if (data.phoneWali !== undefined) updateData.phoneWali = data.phoneWali;
    if (data.foto !== undefined) updateData.foto = data.foto;
    if (data.isActive !== undefined) updateData.isActive = data.isActive;
    
    // Update siswa
    const siswa = await db.siswa.update({
      where: { id },
      data: updateData,
      include: {
        kelas: {
          select: { id: true, nama: true, tingkat: true }
        },
        sekolah: {
          select: { id: true, nama: true }
        }
      }
    });
    
    // Regenerate QR token if NIS changed
    if (data.nis && data.nis !== existingSiswa.nis) {
      await regenerateQRToken(id);
    }
    
    return NextResponse.json({
      success: true,
      message: 'Data siswa berhasil diperbarui',
      data: siswa
    });
  } catch (error) {
    console.error('Update siswa error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// DELETE - Delete siswa
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    
    // Get existing siswa
    const existingSiswa = await db.siswa.findUnique({
      where: { id }
    });
    
    if (!existingSiswa) {
      return NextResponse.json(
        { success: false, message: 'Siswa tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, existingSiswa.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Delete related records first
    await db.notifikasiQueue.deleteMany({
      where: { siswaId: id }
    });
    
    await db.absensi.deleteMany({
      where: { siswaId: id }
    });
    
    // Delete siswa
    await db.siswa.delete({
      where: { id }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Siswa berhasil dihapus'
    });
  } catch (error) {
    console.error('Delete siswa error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat menghapus siswa' },
      { status: 500 }
    );
  }
}
