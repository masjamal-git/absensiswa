import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import * as XLSX from 'xlsx';

// GET - Download Excel template for siswa import
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    
    // Get kelas list for the sekolah
    let kelasList: { nama: string }[] = [];
    if (sekolahId) {
      kelasList = await db.kelas.findMany({
        where: { sekolahId, isActive: true },
        select: { nama: true },
        orderBy: { nama: 'asc' }
      });
    }
    
    // Create workbook
    const workbook = XLSX.utils.book_new();
    
    // Template data with headers
    const templateData = [
      [
        'NIS',
        'NISN',
        'Nama',
        'Kelas',
        'Jenis Kelamin',
        'Tempat Lahir',
        'Tanggal Lahir',
        'Alamat',
        'Nama Ayah',
        'Pekerjaan Ayah',
        'No. HP Ayah',
        'Nama Ibu',
        'Pekerjaan Ibu',
        'No. HP Ibu',
        'Nama Wali',
        'No. HP Wali'
      ],
      // Example row 1
      [
        '12345',
        '0012345678',
        'Ahmad Fauzi',
        kelasList[0]?.nama || 'Kelas 1A',
        'L',
        'Samarinda',
        '01/01/2015',
        'Jl. Merdeka No. 1',
        'Budi Santoso',
        'Wiraswasta',
        '081234567890',
        'Siti Aminah',
        'Ibu Rumah Tangga',
        '081234567891',
        '',
        ''
      ],
      // Example row 2
      [
        '12346',
        '0012345679',
        'Siti Nurhaliza',
        kelasList[0]?.nama || 'Kelas 1A',
        'P',
        'Balikpapan',
        '15/03/2015',
        'Jl. Sudirman No. 2',
        'Hendra Wijaya',
        'PNS',
        '081234567892',
        'Dewi Lestari',
        'Guru',
        '081234567893',
        '',
        ''
      ],
      // Example row 3
      [
        '12347',
        '0012345680',
        'Muhammad Rizki',
        kelasList[1]?.nama || kelasList[0]?.nama || 'Kelas 1B',
        'L',
        'Tenggarong',
        '20/05/2015',
        'Jl. Gajah Mada No. 3',
        '',
        '',
        '',
        'Ratna Sari',
        'Pedagang',
        '081234567894',
        'Pakde Budi',
        '081234567895'
      ]
    ];
    
    // Create worksheet
    const worksheet = XLSX.utils.aoa_to_sheet(templateData);
    
    // Set column widths
    worksheet['!cols'] = [
      { wch: 10 },  // NIS
      { wch: 12 },  // NISN
      { wch: 25 },  // Nama
      { wch: 12 },  // Kelas
      { wch: 15 },  // Jenis Kelamin
      { wch: 15 },  // Tempat Lahir
      { wch: 15 },  // Tanggal Lahir
      { wch: 30 },  // Alamat
      { wch: 20 },  // Nama Ayah
      { wch: 18 },  // Pekerjaan Ayah
      { wch: 15 },  // No. HP Ayah
      { wch: 20 },  // Nama Ibu
      { wch: 18 },  // Pekerjaan Ibu
      { wch: 15 },  // No. HP Ibu
      { wch: 20 },  // Nama Wali
      { wch: 15 },  // No. HP Wali
    ];
    
    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Siswa');
    
    // Add info sheet with kelas list if available
    if (kelasList.length > 0) {
      const infoData = [
        ['DAFTAR KELAS YANG TERSEDIA'],
        [''],
        ['Kelas'],
        ...kelasList.map(k => [k.nama]),
        [''],
        ['PETUNJUK:'],
        ['1. Kolom Wajib: NIS, Nama, Kelas, Jenis Kelamin'],
        ['2. Jenis Kelamin: L (Laki-laki) atau P (Perempuan)'],
        ['3. Tanggal Lahir: Format DD/MM/YYYY (contoh: 01/01/2015)'],
        ['4. Pastikan nama Kelas sesuai dengan daftar di atas'],
        ['5. Hapus baris contoh sebelum mengupload'],
        ['6. NIS tidak boleh duplikat dalam satu sekolah']
      ];
      
      const infoSheet = XLSX.utils.aoa_to_sheet(infoData);
      infoSheet['!cols'] = [{ wch: 50 }];
      XLSX.utils.book_append_sheet(workbook, infoSheet, 'Petunjuk');
    }
    
    // Generate buffer
    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    
    // Return file
    return new NextResponse(buffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': 'attachment; filename="template_import_siswa.xlsx"'
      }
    });
    
  } catch (error) {
    console.error('Template error:', error);
    return NextResponse.json(
      { success: false, message: 'Gagal membuat template' },
      { status: 500 }
    );
  }
}
