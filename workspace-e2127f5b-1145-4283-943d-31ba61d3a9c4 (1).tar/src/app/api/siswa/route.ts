import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';
import { regenerateQRToken, generateQRCodeDataURL } from '@/lib/qrcode';
import { z } from 'zod';

const siswaSchema = z.object({
  nis: z.string().min(1, 'NIS wajib diisi'),
  nisn: z.string().optional(),
  nama: z.string().min(1, 'Nama wajib diisi'),
  jenisKelamin: z.enum(['L', 'P']),
  tempatLahir: z.string().optional(),
  tanggalLahir: z.string().optional(),
  alamat: z.string().optional(),
  kelasId: z.string().min(1, 'Kelas wajib dipilih'),
  sekolahId: z.string().min(1, 'Sekolah wajib dipilih'),
  namaAyah: z.string().optional(),
  pekerjaanAyah: z.string().optional(),
  phoneAyah: z.string().optional(),
  namaIbu: z.string().optional(),
  pekerjaanIbu: z.string().optional(),
  phoneIbu: z.string().optional(),
  namaWali: z.string().optional(),
  phoneWali: z.string().optional(),
  foto: z.string().optional() // Base64 image
});

// GET - List siswa
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    const kelasId = searchParams.get('kelasId');
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    
    const where: any = {};
    
    if (sekolahId) {
      if (!hasAccessToSekolah(user, sekolahId)) {
        return NextResponse.json(
          { success: false, message: 'Akses ditolak' },
          { status: 403 }
        );
      }
      where.sekolahId = sekolahId;
    } else if (user.sekolahId) {
      where.sekolahId = user.sekolahId;
    }
    
    if (kelasId) {
      where.kelasId = kelasId;
    }
    
    if (search) {
      where.OR = [
        { nama: { contains: search } },
        { nis: { contains: search } },
        { nisn: { contains: search } }
      ];
    }
    
    const [siswa, total] = await Promise.all([
      db.siswa.findMany({
        where,
        include: {
          kelas: {
            select: { id: true, nama: true, tingkat: true }
          },
          sekolah: {
            select: { id: true, nama: true }
          }
        },
        orderBy: [
          { kelas: { nama: 'asc' } },
          { nama: 'asc' }
        ],
        skip: (page - 1) * limit,
        take: limit
      }),
      db.siswa.count({ where })
    ]);
    
    return NextResponse.json({
      success: true,
      data: siswa,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get siswa error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// POST - Create siswa
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const validation = siswaSchema.safeParse(body);
    
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: 'Input tidak valid', errors: validation.error.flatten() },
        { status: 400 }
      );
    }
    
    const data = validation.data;
    
    if (!hasAccessToSekolah(user, data.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if NIS already exists
    const existingSiswa = await db.siswa.findFirst({
      where: {
        sekolahId: data.sekolahId,
        nis: data.nis
      }
    });
    
    if (existingSiswa) {
      return NextResponse.json(
        { success: false, message: 'NIS sudah terdaftar di sekolah ini' },
        { status: 400 }
      );
    }
    
    // Create siswa with QR token
    const tempId = `temp_${Date.now()}`;
    const qrToken = `QR_${tempId}_${Math.random().toString(36).substring(7)}`;
    const qrExpiredAt = new Date();
    qrExpiredAt.setFullYear(qrExpiredAt.getFullYear() + 1);
    
    const siswa = await db.siswa.create({
      data: {
        nis: data.nis,
        nisn: data.nisn,
        nama: data.nama,
        jenisKelamin: data.jenisKelamin,
        tempatLahir: data.tempatLahir,
        tanggalLahir: data.tanggalLahir ? new Date(data.tanggalLahir) : null,
        alamat: data.alamat,
        kelasId: data.kelasId,
        sekolahId: data.sekolahId,
        namaAyah: data.namaAyah,
        pekerjaanAyah: data.pekerjaanAyah,
        phoneAyah: data.phoneAyah,
        namaIbu: data.namaIbu,
        pekerjaanIbu: data.pekerjaanIbu,
        phoneIbu: data.phoneIbu,
        namaWali: data.namaWali,
        phoneWali: data.phoneWali,
        foto: data.foto,
        qrToken,
        qrExpiredAt
      },
      include: {
        kelas: true,
        sekolah: true
      }
    });
    
    // Generate proper QR token
    const properToken = await regenerateQRToken(siswa.id);
    
    return NextResponse.json({
      success: true,
      message: 'Siswa berhasil ditambahkan',
      data: siswa
    });
  } catch (error) {
    console.error('Create siswa error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
