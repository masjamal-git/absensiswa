import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';
import { regenerateQRToken } from '@/lib/qrcode';
import * as XLSX from 'xlsx';

// POST - Import siswa from Excel
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const sekolahId = formData.get('sekolahId') as string;
    
    if (!file || !sekolahId) {
      return NextResponse.json(
        { success: false, message: 'File dan sekolah wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Read Excel file
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: 'array' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet) as Record<string, any>[];
    
    if (data.length === 0) {
      return NextResponse.json(
        { success: false, message: 'File Excel kosong' },
        { status: 400 }
      );
    }
    
    // Get all kelas for the sekolah
    const kelasList = await db.kelas.findMany({
      where: { sekolahId },
      select: { id: true, nama: true }
    });
    
    const kelasMap = new Map(kelasList.map(k => [k.nama.toLowerCase(), k.id]));
    
    // Process each row
    const results = {
      success: 0,
      failed: 0,
      errors: [] as { row: number; message: string }[]
    };
    
    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      const rowNum = i + 2; // Excel row number (header is row 1)
      
      try {
        // Map Excel columns to siswa fields
        const nis = String(row['NIS'] || row['nis'] || '').trim();
        const nama = String(row['Nama'] || row['nama'] || '').trim();
        const kelasNama = String(row['Kelas'] || row['kelas'] || '').trim();
        const jenisKelamin = String(row['Jenis Kelamin'] || row['jenis_kelamin'] || row['JK'] || row['jk'] || 'L').trim().toUpperCase();
        const nisn = String(row['NISN'] || row['nisn'] || '').trim() || null;
        const tempatLahir = String(row['Tempat Lahir'] || row['tempat_lahir'] || '').trim() || null;
        const tanggalLahirStr = String(row['Tanggal Lahir'] || row['tanggal_lahir'] || '').trim();
        const alamat = String(row['Alamat'] || row['alamat'] || '').trim() || null;
        const namaAyah = String(row['Nama Ayah'] || row['nama_ayah'] || '').trim() || null;
        const pekerjaanAyah = String(row['Pekerjaan Ayah'] || row['pekerjaan_ayah'] || '').trim() || null;
        const phoneAyah = String(row['No. HP Ayah'] || row['phone_ayah'] || row['No HP Ayah'] || '').trim() || null;
        const namaIbu = String(row['Nama Ibu'] || row['nama_ibu'] || '').trim() || null;
        const pekerjaanIbu = String(row['Pekerjaan Ibu'] || row['pekerjaan_ibu'] || '').trim() || null;
        const phoneIbu = String(row['No. HP Ibu'] || row['phone_ibu'] || row['No HP Ibu'] || '').trim() || null;
        const namaWali = String(row['Nama Wali'] || row['nama_wali'] || '').trim() || null;
        const phoneWali = String(row['No. HP Wali'] || row['phone_wali'] || row['No HP Wali'] || '').trim() || null;
        
        // Validation
        if (!nis) {
          results.failed++;
          results.errors.push({ row: rowNum, message: 'NIS wajib diisi' });
          continue;
        }
        
        if (!nama) {
          results.failed++;
          results.errors.push({ row: rowNum, message: 'Nama wajib diisi' });
          continue;
        }
        
        if (!kelasNama) {
          results.failed++;
          results.errors.push({ row: rowNum, message: 'Kelas wajib diisi' });
          continue;
        }
        
        // Find kelas ID
        const kelasId = kelasMap.get(kelasNama.toLowerCase());
        if (!kelasId) {
          results.failed++;
          results.errors.push({ row: rowNum, message: `Kelas "${kelasNama}" tidak ditemukan` });
          continue;
        }
        
        // Validate jenis kelamin
        const jk = jenisKelamin === 'L' || jenisKelamin === 'LAKI-LAKI' ? 'L' : 
                   jenisKelamin === 'P' || jenisKelamin === 'PEREMPUAN' ? 'P' : 'L';
        
        // Check if NIS already exists
        const existingSiswa = await db.siswa.findFirst({
          where: { sekolahId, nis }
        });
        
        if (existingSiswa) {
          results.failed++;
          results.errors.push({ row: rowNum, message: `NIS "${nis}" sudah terdaftar` });
          continue;
        }
        
        // Parse tanggal lahir
        let tanggalLahir: Date | null = null;
        if (tanggalLahirStr) {
          // Try parsing various date formats
          const parsed = new Date(tanggalLahirStr);
          if (!isNaN(parsed.getTime())) {
            tanggalLahir = parsed;
          } else {
            // Try DD/MM/YYYY format
            const parts = tanggalLahirStr.split('/');
            if (parts.length === 3) {
              const day = parseInt(parts[0]);
              const month = parseInt(parts[1]) - 1;
              const year = parseInt(parts[2]);
              tanggalLahir = new Date(year, month, day);
            }
          }
        }
        
        // Generate QR token
        const tempId = `temp_${Date.now()}_${i}`;
        const qrToken = `QR_${tempId}_${Math.random().toString(36).substring(7)}`;
        const qrExpiredAt = new Date();
        qrExpiredAt.setFullYear(qrExpiredAt.getFullYear() + 1);
        
        // Create siswa
        const siswa = await db.siswa.create({
          data: {
            nis,
            nisn,
            nama,
            jenisKelamin: jk,
            tempatLahir,
            tanggalLahir,
            alamat,
            kelasId,
            sekolahId,
            namaAyah,
            pekerjaanAyah,
            phoneAyah,
            namaIbu,
            pekerjaanIbu,
            phoneIbu,
            namaWali,
            phoneWali,
            qrToken,
            qrExpiredAt
          }
        });
        
        // Generate proper QR token
        await regenerateQRToken(siswa.id);
        
        results.success++;
      } catch (error) {
        results.failed++;
        results.errors.push({ row: rowNum, message: 'Gagal memproses data' });
      }
    }
    
    return NextResponse.json({
      success: true,
      message: `Import selesai: ${results.success} berhasil, ${results.failed} gagal`,
      data: results
    });
    
  } catch (error) {
    console.error('Import siswa error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat import' },
      { status: 500 }
    );
  }
}
