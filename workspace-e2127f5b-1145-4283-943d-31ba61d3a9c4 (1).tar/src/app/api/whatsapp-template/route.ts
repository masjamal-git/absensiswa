import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';

const DEFAULT_TEMPLATE_MASUK = `✅ *NOTIFIKASI ABSENSI*

Sekolah: {{sekolah}}
Tanggal: {{tanggal}}

Ananda *{{nama_siswa}}* (Kelas {{kelas}}) telah {{status}} pada pukul *{{jam}}*.

_Status: {{status}}_

---
Pesan ini dikirim otomatis oleh Sistem Absensi Digital.
_Jika ini adalah kesalahan, silakan hubungi pihak sekolah._`;

const DEFAULT_TEMPLATE_PULANG = `🏃 *NOTIFIKASI ABSENSI - PULANG*

Sekolah: {{sekolah}}
Tanggal: {{tanggal}}

Ananda *{{nama_siswa}}* (Kelas {{kelas}}) telah *PULANG* pada pukul *{{jam}}*.

---
Pesan ini dikirim otomatis oleh Sistem Absensi Digital.`;

// GET - Fetch template pesan WhatsApp
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');

    if (!sekolahId) {
      return NextResponse.json({ success: false, message: 'Sekolah ID wajib diisi' }, { status: 400 });
    }

    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json({ success: false, message: 'Akses ditolak' }, { status: 403 });
    }

    // Use compound unique key sekolahId_key for Pengaturan model
    const masukSetting = await db.pengaturan.findUnique({
      where: { sekolahId_key: { sekolahId, key: 'template_pesan_masuk' } }
    });

    const pulangSetting = await db.pengaturan.findUnique({
      where: { sekolahId_key: { sekolahId, key: 'template_pesan_pulang' } }
    });

    return NextResponse.json({
      success: true,
      data: {
        templateMasuk: masukSetting?.value || DEFAULT_TEMPLATE_MASUK,
        templatePulang: pulangSetting?.value || DEFAULT_TEMPLATE_PULANG
      }
    });
  } catch (error) {
    console.error('Get template pesan error:', error);
    return NextResponse.json({ success: false, message: 'Terjadi kesalahan' }, { status: 500 });
  }
}

// POST - Save template pesan WhatsApp
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { sekolahId, templateMasuk, templatePulang } = body;

    if (!sekolahId) {
      return NextResponse.json({ success: false, message: 'Sekolah ID wajib diisi' }, { status: 400 });
    }

    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json({ success: false, message: 'Akses ditolak' }, { status: 403 });
    }

    if (!templateMasuk || !templatePulang) {
      return NextResponse.json({ success: false, message: 'Template pesan masuk dan pulang wajib diisi' }, { status: 400 });
    }

    // Use Pengaturan model (key-value store) - upsert via compound unique
    await db.pengaturan.upsert({
      where: { sekolahId_key: { sekolahId, key: 'template_pesan_masuk' } },
      update: { value: templateMasuk },
      create: { sekolahId, key: 'template_pesan_masuk', value: templateMasuk }
    });

    await db.pengaturan.upsert({
      where: { sekolahId_key: { sekolahId, key: 'template_pesan_pulang' } },
      update: { value: templatePulang },
      create: { sekolahId, key: 'template_pesan_pulang', value: templatePulang }
    });

    return NextResponse.json({
      success: true,
      message: 'Template pesan WhatsApp berhasil disimpan',
      data: { templateMasuk, templatePulang }
    });
  } catch (error) {
    console.error('Save template pesan error:', error);
    return NextResponse.json({ success: false, message: 'Terjadi kesalahan' }, { status: 500 });
  }
}
