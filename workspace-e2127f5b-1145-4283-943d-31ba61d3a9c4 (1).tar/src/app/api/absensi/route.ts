import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';
import { verifyQRToken } from '@/lib/qrcode';
import {
  generateMasukMessage,
  generatePulangMessage,
  sendWhatsAppNotification,
  formatPhoneNumber,
  queueNotification
} from '@/lib/whatsapp';
import {
  isWithinTimeWindow,
  isLateInTimezone,
  formatTimeInTimezone,
  formatDateInTimezone,
  getStartOfDayInTimezone,
  getEndOfDayInTimezone,
} from '@/lib/timezone';
import { emitAttendanceUpdate } from '@/lib/socket-emitter';
import { z } from 'zod';

const absensiQRSchema = z.object({
  qrToken: z.string().min(1, 'QR Token wajib diisi'),
  sekolahId: z.string().min(1, 'Sekolah ID wajib diisi')
});

const absensiManualSchema = z.object({
  siswaId: z.string().min(1, 'Siswa wajib dipilih'),
  sekolahId: z.string().min(1, 'Sekolah wajib dipilih'),
  status: z.enum(['HADIR', 'TERLAMBAT', 'IZIN', 'SAKIT', 'ALPA']),
  keterangan: z.string().optional(),
  mode: z.enum(['masuk', 'pulang']).optional()
});

// GET - Get attendance records
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    const tanggal = searchParams.get('tanggal');
    const tanggalDari = searchParams.get('tanggalDari');
    const tanggalSampai = searchParams.get('tanggalSampai');
    const kelasId = searchParams.get('kelasId');
    const siswaId = searchParams.get('siswaId');
    const status = searchParams.get('status');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah ID wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    const where: any = { sekolahId };
    
    // Get school timezone for date handling
    const sekolah = await db.sekolah.findUnique({
      where: { id: sekolahId },
      select: { timezone: true }
    });
    const tz = sekolah?.timezone || 'Asia/Jakarta';
    
    // Date range filter: tanggalDari/tanggalSampai takes priority over single tanggal
    if (tanggalDari && tanggalSampai) {
      const start = getStartOfDayInTimezone(new Date(tanggalDari + 'T00:00:00'), tz);
      const end = getEndOfDayInTimezone(new Date(tanggalSampai + 'T00:00:00'), tz);
      where.tanggal = {
        gte: start,
        lte: end
      };
    } else if (tanggal) {
      // Single date filter (backward compatibility)
      const today = getStartOfDayInTimezone(new Date(tanggal + 'T00:00:00'), tz);
      const tomorrow = getEndOfDayInTimezone(new Date(tanggal + 'T00:00:00'), tz);
      where.tanggal = {
        gte: today,
        lt: tomorrow
      };
    }
    
    if (kelasId) {
      where.siswa = { kelasId };
    }
    
    if (siswaId) {
      where.siswaId = siswaId;
    }
    
    if (status) {
      where.status = status;
    }
    
    const [absensi, total] = await Promise.all([
      db.absensi.findMany({
        where,
        include: {
          siswa: {
            include: {
              kelas: {
                select: { id: true, nama: true }
              }
            }
          }
        },
        orderBy: [
          { jamMasuk: 'desc' }
        ],
        skip: (page - 1) * limit,
        take: limit
      }),
      db.absensi.count({ where })
    ]);
    
    return NextResponse.json({
      success: true,
      data: absensi,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get absensi error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// POST - Record attendance (QR or Manual)
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    const body = await request.json();
    const { type, ...data } = body;
    
    if (type === 'qr') {
      return handleQRAbsensi(data, user);
    } else {
      return handleManualAbsensi(data, user);
    }
  } catch (error) {
    console.error('Record absensi error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

async function handleQRAbsensi(data: any, user: any) {
  const validation = absensiQRSchema.safeParse(data);
  
  if (!validation.success) {
    return NextResponse.json(
      { success: false, message: 'Input tidak valid', errors: validation.error.flatten() },
      { status: 400 }
    );
  }
  
  const { qrToken, sekolahId } = validation.data;
  const mode = data.mode || 'masuk'; // Default to masuk
  
  // Verify QR token
  const tokenData = await verifyQRToken(qrToken);
  
  if (!tokenData) {
    return NextResponse.json(
      { success: false, message: 'QR Code tidak valid atau sudah expired' },
      { status: 400 }
    );
  }
  
  // Get siswa
  const siswa = await db.siswa.findUnique({
    where: { id: tokenData.siswaId },
    include: {
      kelas: true,
      sekolah: true
    }
  });
  
  if (!siswa || siswa.sekolahId !== sekolahId) {
    return NextResponse.json(
      { success: false, message: 'Siswa tidak ditemukan di sekolah ini' },
      { status: 404 }
    );
  }
  
  // Check if attendance system is active
  if (siswa.sekolah.absensiAktif === false) {
    return NextResponse.json(
      { success: false, message: 'Sistem absensi sedang tidak aktif' },
      { status: 400 }
    );
  }
  
  const now = new Date();
  const tz = siswa.sekolah.timezone || 'Asia/Jakarta';
  
  // Validate attendance time based on mode
  if (mode === 'masuk') {
    const timeCheck = isWithinTimeWindow(
      tz,
      siswa.sekolah.jamBukaAbsen || '06:30',
      siswa.sekolah.jamTutupAbsen || '12:00'
    );
    if (!timeCheck.allowed) {
      return NextResponse.json(
        { success: false, message: timeCheck.message },
        { status: 400 }
      );
    }
  } else if (mode === 'pulang') {
    const timeCheck = isWithinTimeWindow(
      tz,
      siswa.sekolah.jamBukaAbsenPulang || '12:00',
      siswa.sekolah.jamTutupAbsenPulang || '18:00'
    );
    if (!timeCheck.allowed) {
      return NextResponse.json(
        { success: false, message: timeCheck.message },
        { status: 400 }
      );
    }
  }
  
  // Check if already recorded today
  const today = getStartOfDayInTimezone(now, tz);
  const tomorrow = getEndOfDayInTimezone(now, tz);
  
  const existingAbsensi = await db.absensi.findFirst({
    where: {
      siswaId: siswa.id,
      tanggal: {
        gte: today,
        lt: tomorrow
      }
    }
  });
  
  // Handle PULANG mode
  if (mode === 'pulang') {
    if (!existingAbsensi) {
      // Create new absensi with jamKeluar only (no masuk recorded)
      const absensi = await db.absensi.create({
        data: {
          siswaId: siswa.id,
          sekolahId: siswa.sekolahId,
          tanggal: today,
          jamKeluar: now,
          status: 'HADIR',
          metode: 'QR',
          dicatatOleh: user?.id,
          updatedAt: new Date()
        },
        include: {
          siswa: {
            include: { kelas: true }
          }
        }
      });
      
      // Send WhatsApp notification for PULANG
      const jam = formatTimeInTimezone(now, tz);
      const tanggalStr = formatDateInTimezone(now, tz);
      
      const message = await generatePulangMessage(siswa.sekolahId, {
        namaSiswa: siswa.nama,
        nis: siswa.nis,
        kelas: siswa.kelas?.nama || '-',
        status: 'PULANG',
        jam,
        tanggal: tanggalStr,
        sekolah: siswa.sekolah.nama,
        metode: 'QR',
      });
      
      const phones = [siswa.phoneAyah, siswa.phoneIbu, siswa.phoneWali].filter(Boolean);
      
      if (phones.length > 0) {
        const primaryPhone = formatPhoneNumber(phones[0]);
        
        await queueNotification({
          siswaId: siswa.id,
          absensiId: absensi.id,
          phone: primaryPhone,
          message
        });
        
        sendWhatsAppNotification({
          phone: primaryPhone,
          message,
          siswaId: siswa.id,
          absensiId: absensi.id,
          sekolahId: siswa.sekolahId
        }).catch(err => console.error('WhatsApp notification error:', err));
      }
      
      // Update notification status
      await db.absensi.update({
        where: { id: absensi.id },
        data: { notifSent: true, notifSentAt: new Date() }
      });
      
      // Emit realtime update
      emitAttendanceUpdate({
        sekolahId: siswa.sekolahId,
        siswaId: siswa.id,
        nama: siswa.nama,
        kelas: siswa.kelas?.nama || '-',
        status: 'PULANG',
        jam,
        mode: 'pulang',
      });
      
      return NextResponse.json({
        success: true,
        message: `${siswa.nama} tercatat PULANG pada pukul ${jam} (tanpa absen masuk)`,
        data: {
          absensi,
          siswa: {
            id: siswa.id,
            nama: siswa.nama,
            kelas: siswa.kelas?.nama,
            jenisKelamin: siswa.jenisKelamin
          },
          status: 'PULANG',
          jam,
          mode: 'pulang'
        }
      });
    }
    
    // Update existing absensi with jamKeluar
    if (existingAbsensi.jamKeluar) {
      return NextResponse.json(
        { 
          success: false, 
          message: `${siswa.nama} sudah tercatat PULANG hari ini pada pukul ${formatTimeInTimezone(new Date(existingAbsensi.jamKeluar), tz)}`,
          data: {
            siswa: {
              id: siswa.id,
              nama: siswa.nama,
              kelas: siswa.kelas?.nama
            },
            absensi: existingAbsensi
          }
        },
        { status: 400 }
      );
    }
    
    const absensi = await db.absensi.update({
      where: { id: existingAbsensi.id },
      data: {
        jamKeluar: now,
        updatedAt: new Date()
      },
      include: {
        siswa: {
          include: { kelas: true }
        }
      }
    });
    
    // Send WhatsApp notification for PULANG
    const jam = formatTimeInTimezone(now, tz);
    const tanggalStr = formatDateInTimezone(now, tz);
    const jamMasukStr = existingAbsensi.jamMasuk ? formatTimeInTimezone(new Date(existingAbsensi.jamMasuk), tz) : '-';
    
    const message = await generatePulangMessage(siswa.sekolahId, {
      namaSiswa: siswa.nama,
      nis: siswa.nis,
      kelas: siswa.kelas?.nama || '-',
      status: 'PULANG',
      jam,
      jamMasuk: jamMasukStr,
      jamKeluar: jam,
      tanggal: tanggalStr,
      sekolah: siswa.sekolah.nama,
      metode: 'QR',
    });
    
    const phones = [siswa.phoneAyah, siswa.phoneIbu, siswa.phoneWali].filter(Boolean);
    
    if (phones.length > 0) {
      const primaryPhone = formatPhoneNumber(phones[0]);
      
      await queueNotification({
        siswaId: siswa.id,
        absensiId: absensi.id,
        phone: primaryPhone,
        message
      });
      
      sendWhatsAppNotification({
        phone: primaryPhone,
        message,
        siswaId: siswa.id,
        absensiId: absensi.id,
        sekolahId: siswa.sekolahId
      }).catch(err => console.error('WhatsApp notification error:', err));
    }
    
    // Update notification status
    await db.absensi.update({
      where: { id: absensi.id },
      data: { notifSent: true, notifSentAt: new Date() }
    });
    
    // Emit realtime update
    emitAttendanceUpdate({
      sekolahId: siswa.sekolahId,
      siswaId: siswa.id,
      nama: siswa.nama,
      kelas: siswa.kelas?.nama || '-',
      status: 'PULANG',
      jam,
      mode: 'pulang',
    });
    
    return NextResponse.json({
      success: true,
      message: `${siswa.nama} tercatat PULANG pada pukul ${jam}`,
      data: {
        absensi,
        siswa: {
          id: siswa.id,
          nama: siswa.nama,
          kelas: siswa.kelas?.nama,
          jenisKelamin: siswa.jenisKelamin
        },
        status: 'PULANG',
        jam,
        mode: 'pulang'
      }
    });
  }
  
  // Handle MASUK mode
  if (existingAbsensi) {
    // If already has jamMasuk, show error
    if (existingAbsensi.jamMasuk) {
      return NextResponse.json(
        { 
          success: false, 
          message: `${siswa.nama} sudah tercatat MASUK hari ini pada pukul ${formatTimeInTimezone(new Date(existingAbsensi.jamMasuk), tz)}`,
          data: {
            siswa: {
              id: siswa.id,
              nama: siswa.nama,
              kelas: siswa.kelas?.nama
            },
            absensi: existingAbsensi
          }
        },
        { status: 400 }
      );
    }
    // If has jamKeluar but no jamMasuk (pulang first), update with jamMasuk
    const absensi = await db.absensi.update({
      where: { id: existingAbsensi.id },
      data: {
        jamMasuk: now,
        status: 'HADIR',
        updatedAt: new Date()
      },
      include: {
        siswa: {
          include: { kelas: true }
        }
      }
    });
    
    const jamPulang = existingAbsensi.jamKeluar ? formatTimeInTimezone(new Date(existingAbsensi.jamKeluar), tz) : null;
    const jamMasukStr = formatTimeInTimezone(now, tz);
    
    // Emit realtime update
    emitAttendanceUpdate({
      sekolahId: siswa.sekolahId,
      siswaId: siswa.id,
      nama: siswa.nama,
      kelas: siswa.kelas?.nama || '-',
      status: 'HADIR',
      jam: jamMasukStr,
      mode: 'masuk',
    });
    
    return NextResponse.json({
      success: true,
      message: `${siswa.nama} tercatat MASUK pada pukul ${jamMasukStr}${jamPulang ? ` (sudah pulang pukul ${jamPulang})` : ''}`,
      data: {
        absensi,
        siswa: {
          id: siswa.id,
          nama: siswa.nama,
          kelas: siswa.kelas?.nama,
          jenisKelamin: siswa.jenisKelamin
        },
        status: 'HADIR',
        jam: jamMasukStr,
        mode: 'masuk'
      }
    });
  }
  
  // Determine if late (using school's timezone)
  const isLate = isLateInTimezone(tz, siswa.sekolah.jamMasuk, siswa.sekolah.jamToleransi);
  const status = isLate ? 'TERLAMBAT' : 'HADIR';
  
  // Create absensi record
  const absensi = await db.absensi.create({
    data: {
      siswaId: siswa.id,
      sekolahId: siswa.sekolahId,
      tanggal: today,
      jamMasuk: now,
      status,
      metode: 'QR',
      dicatatOleh: user?.id,
      updatedAt: new Date()
    },
    include: {
      siswa: {
        include: { kelas: true }
      }
    }
  });
  
  // Send WhatsApp notification
  const jam = formatTimeInTimezone(now, tz);
  const tanggalStr = formatDateInTimezone(now, tz);
  
  const message = await generateMasukMessage(siswa.sekolahId, {
    namaSiswa: siswa.nama,
    nis: siswa.nis,
    kelas: siswa.kelas?.nama || '-',
    status,
    jam,
    tanggal: tanggalStr,
    sekolah: siswa.sekolah.nama,
    metode: 'QR',
  });
  
  const phones = [siswa.phoneAyah, siswa.phoneIbu, siswa.phoneWali].filter(Boolean);
  
  if (phones.length > 0) {
    const primaryPhone = formatPhoneNumber(phones[0]);
    
    await queueNotification({
      siswaId: siswa.id,
      absensiId: absensi.id,
      phone: primaryPhone,
      message
    });
    
    sendWhatsAppNotification({
      phone: primaryPhone,
      message,
      siswaId: siswa.id,
      absensiId: absensi.id,
      sekolahId: siswa.sekolahId
    }).catch(err => console.error('WhatsApp notification error:', err));
  }
  
  // Update notification status
  await db.absensi.update({
    where: { id: absensi.id },
    data: { notifSent: true, notifSentAt: new Date() }
  });
  
  // Log activity
  if (user) {
    await db.logAktivitas.create({
      data: {
        userId: user.id,
        aksi: 'ABSENSI_QR',
        deskripsi: `Absensi QR untuk ${siswa.nama} (${siswa.kelas?.nama})`,
        ip: 'system'
      }
    });
  }
  
  // Emit realtime update
  emitAttendanceUpdate({
    sekolahId: siswa.sekolahId,
    siswaId: siswa.id,
    nama: siswa.nama,
    kelas: siswa.kelas?.nama || '-',
    status,
    jam,
    mode: 'masuk',
  });
  
  return NextResponse.json({
    success: true,
    message: isLate 
      ? `${siswa.nama} tercatat TERLAMBAT pada pukul ${jam}` 
      : `${siswa.nama} tercatat HADIR pada pukul ${jam}`,
    data: {
      absensi,
      siswa: {
        id: siswa.id,
        nama: siswa.nama,
        kelas: siswa.kelas?.nama,
        jenisKelamin: siswa.jenisKelamin
      },
      status,
      jam
    }
  });
}

async function handleManualAbsensi(data: any, user: any) {
  if (!user) {
    return NextResponse.json(
      { success: false, message: 'Unauthorized' },
      { status: 401 }
    );
  }
  
  const validation = absensiManualSchema.safeParse(data);
  
  if (!validation.success) {
    return NextResponse.json(
      { success: false, message: 'Input tidak valid', errors: validation.error.flatten() },
      { status: 400 }
    );
  }
  
  const { siswaId, sekolahId, status, keterangan, mode = 'masuk' } = validation.data;
  
  if (!hasAccessToSekolah(user, sekolahId)) {
    return NextResponse.json(
      { success: false, message: 'Akses ditolak' },
      { status: 403 }
    );
  }
  
  // Get siswa
  const siswa = await db.siswa.findUnique({
    where: { id: siswaId },
    include: { kelas: true, sekolah: true }
  });
  
  if (!siswa) {
    return NextResponse.json(
      { success: false, message: 'Siswa tidak ditemukan' },
      { status: 404 }
    );
  }
  
  // Check if attendance system is active (only for QR mode, not for manual status like IZIN/SAKIT/ALPA)
  if (status === 'HADIR' && siswa.sekolah.absensiAktif === false) {
    return NextResponse.json(
      { success: false, message: 'Sistem absensi sedang tidak aktif' },
      { status: 400 }
    );
  }
  
  const now = new Date();
  const tz = siswa.sekolah.timezone || 'Asia/Jakarta';
  
  // Validate attendance time based on mode (only for HADIR status)
  if (status === 'HADIR') {
    if (mode === 'masuk') {
      const timeCheck = isWithinTimeWindow(
        tz,
        siswa.sekolah.jamBukaAbsen || '06:30',
        siswa.sekolah.jamTutupAbsen || '12:00'
      );
      if (!timeCheck.allowed) {
        return NextResponse.json(
          { success: false, message: timeCheck.message },
          { status: 400 }
        );
      }
    } else if (mode === 'pulang') {
      const timeCheck = isWithinTimeWindow(
        tz,
        siswa.sekolah.jamBukaAbsenPulang || '12:00',
        siswa.sekolah.jamTutupAbsenPulang || '18:00'
      );
      if (!timeCheck.allowed) {
        return NextResponse.json(
          { success: false, message: timeCheck.message },
          { status: 400 }
        );
      }
    }
  }
  
  // Check if already recorded today
  const today = getStartOfDayInTimezone(now, tz);
  const tomorrow = getEndOfDayInTimezone(now, tz);
  
  const existingAbsensi = await db.absensi.findFirst({
    where: {
      siswaId: siswa.id,
      tanggal: {
        gte: today,
        lt: tomorrow
      }
    }
  });
  
  const jam = formatTimeInTimezone(now, tz);
  
  // Determine actual status - check if student is late for HADIR masuk
  let actualStatus = status;
  if (status === 'HADIR' && mode === 'masuk' && siswa.sekolah.jamMasuk) {
    const isLate = isLateInTimezone(tz, siswa.sekolah.jamMasuk, siswa.sekolah.jamToleransi || '0');
    if (isLate) {
      actualStatus = 'TERLAMBAT';
    }
  }
  
  // Handle PULANG mode
  if (mode === 'pulang') {
    if (!existingAbsensi) {
      // Create new absensi with jamKeluar only (no masuk recorded)
      const absensi = await db.absensi.create({
        data: {
          siswaId: siswa.id,
          sekolahId: siswa.sekolahId,
          tanggal: today,
          jamKeluar: now,
          status: 'HADIR',
          keterangan,
          metode: 'MANUAL',
          dicatatOleh: user.id,
          updatedAt: new Date()
        },
        include: {
          siswa: {
            include: { kelas: true }
          }
        }
      });
      
      // Send WhatsApp notification
      const tanggalStr = formatDateInTimezone(now, tz);
      const message = await generatePulangMessage(siswa.sekolahId, {
        namaSiswa: siswa.nama,
        nis: siswa.nis,
        kelas: siswa.kelas?.nama || '-',
        status: 'PULANG',
        jam,
        tanggal: tanggalStr,
        sekolah: siswa.sekolah.nama,
        metode: 'MANUAL',
        keterangan: keterangan || undefined,
      });
      
      const phones = [siswa.phoneAyah, siswa.phoneIbu, siswa.phoneWali].filter(Boolean);
      
      if (phones.length > 0) {
        const primaryPhone = formatPhoneNumber(phones[0]);
        
        await queueNotification({
          siswaId: siswa.id,
          absensiId: absensi.id,
          phone: primaryPhone,
          message
        });
        
        sendWhatsAppNotification({
          phone: primaryPhone,
          message,
          siswaId: siswa.id,
          absensiId: absensi.id,
          sekolahId: siswa.sekolahId
        }).catch(err => console.error('WhatsApp notification error:', err));
      }
      
      // Log activity
      await db.logAktivitas.create({
        data: {
          userId: user.id,
          aksi: 'ABSENSI_MANUAL_PULANG',
          deskripsi: `Absensi manual pulang untuk ${siswa.nama} (${siswa.kelas?.nama})`,
          ip: 'system'
        }
      });
      
      // Emit realtime update
      emitAttendanceUpdate({
        sekolahId: siswa.sekolahId,
        siswaId: siswa.id,
        nama: siswa.nama,
        kelas: siswa.kelas?.nama || '-',
        status: 'PULANG',
        jam,
        mode: 'pulang',
      });
      
      return NextResponse.json({
        success: true,
        message: `${siswa.nama} tercatat PULANG pada pukul ${jam} (tanpa absen masuk)`,
        data: {
          absensi,
          siswa: {
            id: siswa.id,
            nama: siswa.nama,
            kelas: siswa.kelas?.nama,
            jenisKelamin: siswa.jenisKelamin
          },
          status: 'PULANG',
          jam,
          mode: 'pulang'
        }
      });
    }
    
    // Check if already has jamKeluar
    if (existingAbsensi.jamKeluar) {
      return NextResponse.json(
        { 
          success: false, 
          message: `${siswa.nama} sudah tercatat PULANG hari ini pada pukul ${formatTimeInTimezone(new Date(existingAbsensi.jamKeluar), tz)}`,
          data: {
            siswa: {
              id: siswa.id,
              nama: siswa.nama,
              kelas: siswa.kelas?.nama
            },
            absensi: existingAbsensi
          }
        },
        { status: 400 }
      );
    }
    
    // Update existing absensi with jamKeluar
    const absensi = await db.absensi.update({
      where: { id: existingAbsensi.id },
      data: {
        jamKeluar: now,
        keterangan,
        updatedAt: new Date()
      },
      include: {
        siswa: {
          include: { kelas: true }
        }
      }
    });
    
    // Send WhatsApp notification
    const tanggalStr = formatDateInTimezone(now, tz);
    const jamMasukStr = existingAbsensi.jamMasuk ? formatTimeInTimezone(new Date(existingAbsensi.jamMasuk), tz) : '-';
    const message = await generatePulangMessage(siswa.sekolahId, {
      namaSiswa: siswa.nama,
      nis: siswa.nis,
      kelas: siswa.kelas?.nama || '-',
      status: 'PULANG',
      jam,
      jamMasuk: jamMasukStr,
      jamKeluar: jam,
      tanggal: tanggalStr,
      sekolah: siswa.sekolah.nama,
      metode: 'MANUAL',
      keterangan: keterangan || undefined,
    });
    
    const phones = [siswa.phoneAyah, siswa.phoneIbu, siswa.phoneWali].filter(Boolean);
    
    if (phones.length > 0) {
      const primaryPhone = formatPhoneNumber(phones[0]);
      
      await queueNotification({
        siswaId: siswa.id,
        absensiId: absensi.id,
        phone: primaryPhone,
        message
      });
      
      sendWhatsAppNotification({
        phone: primaryPhone,
        message,
        siswaId: siswa.id,
        absensiId: absensi.id,
        sekolahId: siswa.sekolahId
      }).catch(err => console.error('WhatsApp notification error:', err));
    }
    
    // Log activity
    await db.logAktivitas.create({
      data: {
        userId: user.id,
        aksi: 'ABSENSI_MANUAL_PULANG',
        deskripsi: `Absensi manual pulang untuk ${siswa.nama} (${siswa.kelas?.nama})`,
        ip: 'system'
      }
    });
    
    // Emit realtime update
    emitAttendanceUpdate({
      sekolahId: siswa.sekolahId,
      siswaId: siswa.id,
      nama: siswa.nama,
      kelas: siswa.kelas?.nama || '-',
      status: 'PULANG',
      jam,
      mode: 'pulang',
    });
    
    return NextResponse.json({
      success: true,
      message: `${siswa.nama} tercatat PULANG pada pukul ${jam}`,
      data: {
        absensi,
        siswa: {
          id: siswa.id,
          nama: siswa.nama,
          kelas: siswa.kelas?.nama,
          jenisKelamin: siswa.jenisKelamin
        },
        status: 'PULANG',
        jam,
        mode: 'pulang'
      }
    });
  }
  
  // Helper function for status messages
  const getStatusMessage = (nama: string, status: string, jamStr: string): string => {
    switch (status) {
      case 'TERLAMBAT': return `${nama} tercatat TERLAMBAT pada pukul ${jamStr}`;
      case 'HADIR': return `${nama} tercatat HADIR pada pukul ${jamStr}`;
      case 'SAKIT': return `${nama} tercatat SAKIT hari ini`;
      case 'IZIN': return `${nama} tercatat IZIN hari ini`;
      case 'ALPA': return `${nama} tercatat ALPA hari ini`;
      default: return `${nama} tercatat ${status} hari ini`;
    }
  };

  // Handle MASUK mode
  if (existingAbsensi) {
    // For SAKIT/IZIN/ALPA: update existing record's status
    if (['SAKIT', 'IZIN', 'ALPA'].includes(actualStatus)) {
      const absensi = await db.absensi.update({
        where: { id: existingAbsensi.id },
        data: {
          status: actualStatus,
          keterangan: keterangan || existingAbsensi.keterangan,
          dicatatOleh: user.id,
          updatedAt: new Date()
        },
        include: {
          siswa: {
            include: { kelas: true }
          }
        }
      });

      // Emit realtime update
      emitAttendanceUpdate({
        sekolahId: siswa.sekolahId,
        siswaId: siswa.id,
        nama: siswa.nama,
        kelas: siswa.kelas?.nama || '-',
        status: actualStatus,
        jam,
        mode: 'masuk',
      });

      return NextResponse.json({
        success: true,
        message: getStatusMessage(siswa.nama, actualStatus, jam),
        data: {
          absensi,
          siswa: {
            id: siswa.id,
            nama: siswa.nama,
            kelas: siswa.kelas?.nama,
            jenisKelamin: siswa.jenisKelamin
          },
          status: actualStatus,
          jam,
          mode: 'masuk'
        }
      });
    }

    // Check if already has jamMasuk (already checked in)
    if (existingAbsensi.jamMasuk) {
      return NextResponse.json(
        { 
          success: false, 
          message: `${siswa.nama} sudah tercatat MASUK hari ini pada pukul ${formatTimeInTimezone(new Date(existingAbsensi.jamMasuk), tz)}`,
          data: {
            siswa: {
              id: siswa.id,
              nama: siswa.nama,
              kelas: siswa.kelas?.nama
            },
            absensi: existingAbsensi
          }
        },
        { status: 400 }
      );
    }
    
    // If has jamKeluar but no jamMasuk, update with jamMasuk
    const absensi = await db.absensi.update({
      where: { id: existingAbsensi.id },
      data: {
        jamMasuk: now,
        status: actualStatus,
        keterangan,
        dicatatOleh: user.id,
        updatedAt: new Date()
      },
      include: {
        siswa: {
          include: { kelas: true }
        }
      }
    });
    
    // Emit realtime update
    emitAttendanceUpdate({
      sekolahId: siswa.sekolahId,
      siswaId: siswa.id,
      nama: siswa.nama,
      kelas: siswa.kelas?.nama || '-',
      status: actualStatus,
      jam,
      mode: 'masuk',
    });
    
    return NextResponse.json({
      success: true,
      message: getStatusMessage(siswa.nama, actualStatus, jam),
      data: {
        absensi,
        siswa: {
          id: siswa.id,
          nama: siswa.nama,
          kelas: siswa.kelas?.nama,
          jenisKelamin: siswa.jenisKelamin
        },
        status: actualStatus,
        jam,
        mode: 'masuk'
      }
    });
  }
  
  // Create new absensi for MASUK (HADIR/TERLAMBAT) or non-attendance (SAKIT/IZIN/ALPA)
  const isPresenceStatus = ['HADIR', 'TERLAMBAT'].includes(actualStatus);
  
  const absensi = await db.absensi.create({
    data: {
      siswaId: siswa.id,
      sekolahId: siswa.sekolahId,
      tanggal: today,
      jamMasuk: isPresenceStatus ? now : null,
      status: actualStatus,
      keterangan,
      metode: 'MANUAL',
      dicatatOleh: user.id,
      updatedAt: new Date()
    },
    include: {
      siswa: {
        include: { kelas: true }
      }
    }
  });
  
  // Send notification if HADIR or TERLAMBAT
  if (actualStatus === 'HADIR' || actualStatus === 'TERLAMBAT') {
    const tanggalStr = formatDateInTimezone(now, tz);
    
    const message = await generateMasukMessage(siswa.sekolahId, {
      namaSiswa: siswa.nama,
      nis: siswa.nis,
      kelas: siswa.kelas?.nama || '-',
      status: actualStatus,
      jam,
      tanggal: tanggalStr,
      sekolah: siswa.sekolah.nama,
      metode: 'MANUAL',
      keterangan: keterangan || undefined,
    });
    
    const phones = [siswa.phoneAyah, siswa.phoneIbu, siswa.phoneWali].filter(Boolean);
    
    if (phones.length > 0) {
      const primaryPhone = formatPhoneNumber(phones[0]);
      
      await queueNotification({
        siswaId: siswa.id,
        absensiId: absensi.id,
        phone: primaryPhone,
        message
      });
      
      sendWhatsAppNotification({
        phone: primaryPhone,
        message,
        siswaId: siswa.id,
        absensiId: absensi.id,
        sekolahId: siswa.sekolahId
      }).catch(err => console.error('WhatsApp notification error:', err));
    }
  }
  
  // Log activity
  await db.logAktivitas.create({
    data: {
      userId: user.id,
      aksi: 'ABSENSI_MANUAL',
      deskripsi: `Absensi manual untuk ${siswa.nama} (${siswa.kelas?.nama}) - ${actualStatus}`,
      ip: 'system'
    }
  });
  
  // Emit realtime update
  emitAttendanceUpdate({
    sekolahId: siswa.sekolahId,
    siswaId: siswa.id,
    nama: siswa.nama,
    kelas: siswa.kelas?.nama || '-',
    status: actualStatus,
    jam,
    mode: 'masuk',
  });
  
  return NextResponse.json({
    success: true,
    message: getStatusMessage(siswa.nama, actualStatus, jam),
    data: {
      absensi,
      siswa: {
        id: siswa.id,
        nama: siswa.nama,
        kelas: siswa.kelas?.nama,
        jenisKelamin: siswa.jenisKelamin
      },
      status: actualStatus,
      jam,
      mode: 'masuk'
    }
  });
}
