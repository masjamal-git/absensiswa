import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';

// Helper function to check access
function checkAccess(user: any, sekolahId: string): boolean {
  if (user.role === 'SUPER_ADMIN') return true;
  if (user.sekolahId === sekolahId) return true;
  return false;
}

// GET - Get single kelas
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    
    const kelas = await db.kelas.findUnique({
      where: { id },
      include: {
        tingkat: {
          select: { id: true, nama: true }
        },
        tahunAjaran: {
          select: { id: true, nama: true }
        },
        _count: {
          select: { siswa: true }
        }
      }
    });
    
    if (!kelas) {
      return NextResponse.json(
        { success: false, message: 'Kelas tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, kelas.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: kelas
    });
  } catch (error) {
    console.error('Get kelas error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// PUT - Update kelas
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    const body = await request.json();
    const { nama, tingkatId, waliKelas, tahunAjaranId, isActive } = body;
    
    // Get existing kelas
    const existingKelas = await db.kelas.findUnique({
      where: { id }
    });
    
    if (!existingKelas) {
      return NextResponse.json(
        { success: false, message: 'Kelas tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, existingKelas.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if kelas with same name already exists (excluding current)
    if (nama && nama !== existingKelas.nama) {
      const duplicateKelas = await db.kelas.findFirst({
        where: {
          sekolahId: existingKelas.sekolahId,
          nama,
          isActive: true,
          id: { not: id }
        }
      });
      
      if (duplicateKelas) {
        return NextResponse.json(
          { success: false, message: 'Kelas dengan nama tersebut sudah ada' },
          { status: 400 }
        );
      }
    }
    
    const updateData: any = {};
    if (nama !== undefined) updateData.nama = nama;
    if (tingkatId !== undefined) updateData.tingkatId = tingkatId;
    if (waliKelas !== undefined) updateData.waliKelas = waliKelas || null;
    if (tahunAjaranId !== undefined) updateData.tahunAjaranId = tahunAjaranId || null;
    if (isActive !== undefined) updateData.isActive = isActive;
    
    const kelas = await db.kelas.update({
      where: { id },
      data: updateData,
      include: {
        tingkat: {
          select: { nama: true }
        },
        tahunAjaran: {
          select: { nama: true }
        }
      }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Kelas berhasil diperbarui',
      data: kelas
    });
  } catch (error) {
    console.error('Update kelas error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// DELETE - Delete kelas (soft delete)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    
    // Get existing kelas
    const existingKelas = await db.kelas.findUnique({
      where: { id },
      include: {
        _count: {
          select: { siswa: true }
        }
      }
    });
    
    if (!existingKelas) {
      return NextResponse.json(
        { success: false, message: 'Kelas tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, existingKelas.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if kelas has students
    if (existingKelas._count.siswa > 0) {
      return NextResponse.json(
        { success: false, message: `Tidak dapat menghapus kelas karena masih memiliki ${existingKelas._count.siswa} siswa` },
        { status: 400 }
      );
    }
    
    // Soft delete
    await db.kelas.update({
      where: { id },
      data: { isActive: false }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Kelas berhasil dihapus'
    });
  } catch (error) {
    console.error('Delete kelas error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
