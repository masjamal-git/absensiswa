import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';

// Helper function to check access
function checkAccess(user: any, sekolahId: string): boolean {
  if (user.role === 'SUPER_ADMIN') return true;
  if (user.sekolahId === sekolahId) return true;
  return false;
}

// GET - List kelas by sekolah
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    const tahunAjaranId = searchParams.get('tahunAjaranId');
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah ID wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!checkAccess(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    const whereClause: any = { sekolahId };
    
    // Filter by tahun ajaran if provided
    if (tahunAjaranId) {
      whereClause.tahunAjaranId = tahunAjaranId;
    }
    
    const kelas = await db.kelas.findMany({
      where: whereClause,
      include: {
        tingkat: {
          select: { id: true, nama: true, urutan: true }
        },
        tahunAjaran: {
          select: { nama: true }
        },
        _count: {
          select: { siswa: true }
        }
      },
      orderBy: [
        { tingkat: { urutan: 'asc' } },
        { nama: 'asc' }
      ]
    });
    
    return NextResponse.json({
      success: true,
      data: kelas
    });
  } catch (error) {
    console.error('Get kelas error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// POST - Create new kelas
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const { sekolahId, nama, tingkatId, waliKelas, tahunAjaranId, isActive } = body;
    
    if (!sekolahId || !nama || !tingkatId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah, nama kelas, dan tingkat wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!checkAccess(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if kelas with same name already exists in sekolah
    const existingKelas = await db.kelas.findFirst({
      where: {
        sekolahId,
        nama,
        isActive: true
      }
    });
    
    if (existingKelas) {
      return NextResponse.json(
        { success: false, message: 'Kelas dengan nama tersebut sudah ada' },
        { status: 400 }
      );
    }
    
    const kelas = await db.kelas.create({
      data: {
        sekolahId,
        nama,
        tingkatId,
        waliKelas: waliKelas || null,
        tahunAjaranId: tahunAjaranId || null,
        isActive: isActive ?? true
      },
      include: {
        tingkat: {
          select: { nama: true }
        },
        tahunAjaran: {
          select: { nama: true }
        }
      }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Kelas berhasil ditambahkan',
      data: kelas
    });
  } catch (error) {
    console.error('Create kelas error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
