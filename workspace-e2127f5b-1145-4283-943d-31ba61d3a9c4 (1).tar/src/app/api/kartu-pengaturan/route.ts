import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get card settings
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    
    if (!sekolahId) {
      return NextResponse.json({ success: false, message: 'sekolahId required' }, { status: 400 });
    }
    
    let pengaturan = await db.pengaturanKartu.findUnique({
      where: { sekolahId }
    });
    
    // Create default settings if not exist
    if (!pengaturan) {
      pengaturan = await db.pengaturanKartu.create({
        data: {
          sekolahId,
          warnaHeader: '#059669',
          warnaBackground: '#ffffff',
          tahunAjaran: '2024/2025',
          berlakuSampai: 'Juli 2025',
          showQR: true,
          showFoto: true,
          kartuPerHalaman: 6
        }
      });
    }
    
    return NextResponse.json({ success: true, data: pengaturan });
  } catch (error) {
    console.error('Error getting card settings:', error);
    return NextResponse.json({ success: false, message: 'Terjadi kesalahan' }, { status: 500 });
  }
}

// POST - Update card settings
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sekolahId, kartuPerHalaman, ...settings } = body;
    
    if (!sekolahId) {
      return NextResponse.json({ success: false, message: 'sekolahId required' }, { status: 400 });
    }
    
    // Build update data, only include known fields
    const updateData: Record<string, unknown> = {};
    if (settings.warnaHeader !== undefined) updateData.warnaHeader = settings.warnaHeader;
    if (settings.warnaBackground !== undefined) updateData.warnaBackground = settings.warnaBackground;
    if (settings.tahunAjaran !== undefined) updateData.tahunAjaran = settings.tahunAjaran;
    if (settings.berlakuSampai !== undefined) updateData.berlakuSampai = settings.berlakuSampai;
    if (settings.namaKepalaSekolah !== undefined) updateData.namaKepalaSekolah = settings.namaKepalaSekolah;
    if (settings.nipKepalaSekolah !== undefined) updateData.nipKepalaSekolah = settings.nipKepalaSekolah;
    if (settings.showQR !== undefined) updateData.showQR = settings.showQR;
    if (settings.showFoto !== undefined) updateData.showFoto = settings.showFoto;
    if (settings.logoSekolah !== undefined) updateData.logoSekolah = settings.logoSekolah;
    if (kartuPerHalaman !== undefined) updateData.kartuPerHalaman = Number(kartuPerHalaman);
    
    const pengaturan = await db.pengaturanKartu.upsert({
      where: { sekolahId },
      create: {
        sekolahId,
        ...updateData
      },
      update: {
        ...updateData
      }
    });
    
    return NextResponse.json({ success: true, data: pengaturan });
  } catch (error) {
    console.error('Error updating card settings:', error);
    return NextResponse.json({ success: false, message: 'Terjadi kesalahan' }, { status: 500 });
  }
}
