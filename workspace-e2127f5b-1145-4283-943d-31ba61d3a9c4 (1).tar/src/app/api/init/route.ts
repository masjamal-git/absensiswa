import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword } from '@/lib/auth';
import { generateSecureToken } from '@/lib/qrcode';

// POST - Initialize database with sample data
export async function POST() {
  try {
    // Check if already initialized
    const existingYayasan = await db.yayasan.findFirst();
    
    if (existingYayasan) {
      return NextResponse.json({
        success: false,
        message: 'Database sudah diinisialisasi'
      });
    }
    
    // Create Yayasan
    const yayasan = await db.yayasan.create({
      data: {
        nama: 'Yayasan Pendidikan Nurul Huda',
        alamat: 'Jl. Pendidikan No. 123, Jakarta',
        telepon: '021-12345678',
        email: 'info@nurulhuda.sch.id'
      }
    });
    
    // Create Sekolah (multi-school)
    const sekolahSD = await db.sekolah.create({
      data: {
        yayasanId: yayasan.id,
        nama: 'SD Nurul Huda',
        npsn: '12345678',
        alamat: 'Jl. Pendidikan No. 123, Jakarta',
        telepon: '021-12345678',
        email: 'sd@nurulhuda.sch.id',
        jenis: 'SD',
        jamMasuk: '07:00',
        jamToleransi: '15'
      }
    });
    
    const sekolahSMP = await db.sekolah.create({
      data: {
        yayasanId: yayasan.id,
        nama: 'SMP Nurul Huda',
        npsn: '12345679',
        alamat: 'Jl. Pendidikan No. 124, Jakarta',
        telepon: '021-12345679',
        email: 'smp@nurulhuda.sch.id',
        jenis: 'SMP',
        jamMasuk: '07:15',
        jamToleransi: '15'
      }
    });
    
    // Create Tingkat for SD (Kelas 1-6)
    const tingkatSD: { id: string; nama: string; urutan: number }[] = [];
    for (let i = 1; i <= 6; i++) {
      const t = await db.tingkat.create({
        data: {
          sekolahId: sekolahSD.id,
          nama: `${i}`,
          urutan: i,
          keterangan: `Kelas ${i} SD`
        }
      });
      tingkatSD.push(t);
    }
    
    // Create Tingkat for SMP (Kelas 7-9)
    const tingkatSMP: { id: string; nama: string; urutan: number }[] = [];
    for (let i = 7; i <= 9; i++) {
      const t = await db.tingkat.create({
        data: {
          sekolahId: sekolahSMP.id,
          nama: `${i}`,
          urutan: i,
          keterangan: `Kelas ${i} SMP`
        }
      });
      tingkatSMP.push(t);
    }
    
    // Create Tahun Ajaran for SD
    const tahunAjaranSD1 = await db.tahunAjaran.create({
      data: {
        sekolahId: sekolahSD.id,
        nama: '2023/2024',
        tanggalMulai: new Date('2023-07-15'),
        tanggalSelesai: new Date('2024-06-30'),
        semester: 2,
        isActive: true,
        isCurrent: false
      }
    });
    
    const tahunAjaranSD2 = await db.tahunAjaran.create({
      data: {
        sekolahId: sekolahSD.id,
        nama: '2024/2025',
        tanggalMulai: new Date('2024-07-15'),
        tanggalSelesai: new Date('2025-06-30'),
        semester: 1,
        isActive: true,
        isCurrent: true
      }
    });
    
    // Create Tahun Ajaran for SMP
    const tahunAjaranSMP1 = await db.tahunAjaran.create({
      data: {
        sekolahId: sekolahSMP.id,
        nama: '2023/2024',
        tanggalMulai: new Date('2023-07-15'),
        tanggalSelesai: new Date('2024-06-30'),
        semester: 2,
        isActive: true,
        isCurrent: false
      }
    });
    
    const tahunAjaranSMP2 = await db.tahunAjaran.create({
      data: {
        sekolahId: sekolahSMP.id,
        nama: '2024/2025',
        tanggalMulai: new Date('2024-07-15'),
        tanggalSelesai: new Date('2025-06-30'),
        semester: 1,
        isActive: true,
        isCurrent: true
      }
    });
    
    // Create Kelas for SD
    const kelasSD: { id: string; nama: string; tingkatId: string }[] = [];
    for (let i = 0; i < 6; i++) {
      const tingkat = tingkatSD[i];
      const kelasA = await db.kelas.create({
        data: {
          sekolahId: sekolahSD.id,
          nama: `${tingkat.nama}A`,
          tingkatId: tingkat.id,
          waliKelas: `Guru Kelas ${tingkat.nama}A`,
          tahunAjaranId: tahunAjaranSD2.id
        }
      });
      kelasSD.push(kelasA);
      
      const kelasB = await db.kelas.create({
        data: {
          sekolahId: sekolahSD.id,
          nama: `${tingkat.nama}B`,
          tingkatId: tingkat.id,
          waliKelas: `Guru Kelas ${tingkat.nama}B`,
          tahunAjaranId: tahunAjaranSD2.id
        }
      });
      kelasSD.push(kelasB);
    }
    
    // Create Kelas for SMP
    const kelasSMP: { id: string; nama: string; tingkatId: string }[] = [];
    for (let i = 0; i < 3; i++) {
      const tingkat = tingkatSMP[i];
      const kelasA = await db.kelas.create({
        data: {
          sekolahId: sekolahSMP.id,
          nama: `${tingkat.nama}A`,
          tingkatId: tingkat.id,
          waliKelas: `Wali Kelas ${tingkat.nama}A`,
          tahunAjaranId: tahunAjaranSMP2.id
        }
      });
      kelasSMP.push(kelasA);
      
      const kelasB = await db.kelas.create({
        data: {
          sekolahId: sekolahSMP.id,
          nama: `${tingkat.nama}B`,
          tingkatId: tingkat.id,
          waliKelas: `Wali Kelas ${tingkat.nama}B`,
          tahunAjaranId: tahunAjaranSMP2.id
        }
      });
      kelasSMP.push(kelasB);
    }
    
    // Create sample students for SD
    const namaSiswaL = [
      'Ahmad Rizki', 'Budi Santoso', 'Cahyo Wibowo', 'Deni Prasetyo', 'Eko Saputra',
      'Fajar Nugroho', 'Galih Pratama', 'Hendra Wijaya', 'Irfan Hakim', 'Joko Susilo',
      'Kevin Pratama', 'Lukman Hakim', 'Muhammad Alif', 'Naufal Aziz', 'Oki Setiawan'
    ];
    
    const namaSiswaP = [
      'Anisa Putri', 'Bella Safitri', 'Citra Dewi', 'Dinda Permata', 'Eva Susanti',
      'Fitri Handayani', 'Gita Rahayu', 'Hana Safira', 'Indah Permata', 'Julia Putri',
      'Kartika Sari', 'Linda Wati', 'Maya Sari', 'Nadia Putri', 'Olivia Sari'
    ];
    
    let siswaCounter = 1;
    
    for (let kelasIdx = 0; kelasIdx < kelasSD.length; kelasIdx++) {
      const kelas = kelasSD[kelasIdx];
      const tingkatIdx = Math.floor(kelasIdx / 2);
      
      // Add 5 male students
      for (let i = 0; i < 5; i++) {
        const nama = namaSiswaL[(siswaCounter + i) % namaSiswaL.length];
        const nis = `SD${String(siswaCounter).padStart(4, '0')}`;
        const tempId = `siswa_${Date.now()}_${siswaCounter}`;
        const qrToken = generateSecureToken(tempId, nis);
        
        await db.siswa.create({
          data: {
            sekolahId: sekolahSD.id,
            kelasId: kelas.id,
            nis,
            nisn: `00${String(siswaCounter).padStart(8, '0')}`,
            nama,
            jenisKelamin: 'L',
            tempatLahir: 'Jakarta',
            tanggalLahir: new Date(2017 - tingkatIdx, Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1),
            namaAyah: `Ayah ${nama}`,
            phoneAyah: `081${Math.floor(Math.random() * 1000000000).toString().padStart(9, '0')}`,
            namaIbu: `Ibu ${nama}`,
            phoneIbu: `082${Math.floor(Math.random() * 1000000000).toString().padStart(9, '0')}`,
            qrToken,
            qrExpiredAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
          }
        });
        siswaCounter++;
      }
      
      // Add 5 female students
      for (let i = 0; i < 5; i++) {
        const nama = namaSiswaP[(siswaCounter + i) % namaSiswaP.length];
        const nis = `SD${String(siswaCounter).padStart(4, '0')}`;
        const tempId = `siswa_${Date.now()}_${siswaCounter}`;
        const qrToken = generateSecureToken(tempId, nis);
        
        await db.siswa.create({
          data: {
            sekolahId: sekolahSD.id,
            kelasId: kelas.id,
            nis,
            nisn: `00${String(siswaCounter).padStart(8, '0')}`,
            nama,
            jenisKelamin: 'P',
            tempatLahir: 'Jakarta',
            tanggalLahir: new Date(2017 - tingkatIdx, Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1),
            namaAyah: `Ayah ${nama}`,
            phoneAyah: `081${Math.floor(Math.random() * 1000000000).toString().padStart(9, '0')}`,
            namaIbu: `Ibu ${nama}`,
            phoneIbu: `082${Math.floor(Math.random() * 1000000000).toString().padStart(9, '0')}`,
            qrToken,
            qrExpiredAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
          }
        });
        siswaCounter++;
      }
    }
    
    // Create sample students for SMP
    for (let kelasIdx = 0; kelasIdx < kelasSMP.length; kelasIdx++) {
      const kelas = kelasSMP[kelasIdx];
      const tingkatIdx = kelasIdx < 2 ? 0 : (kelasIdx < 4 ? 1 : 2);
      
      for (let i = 0; i < 5; i++) {
        const nama = namaSiswaL[(siswaCounter + i) % namaSiswaL.length];
        const nis = `SMP${String(siswaCounter).padStart(4, '0')}`;
        const tempId = `siswa_${Date.now()}_${siswaCounter}`;
        const qrToken = generateSecureToken(tempId, nis);
        
        await db.siswa.create({
          data: {
            sekolahId: sekolahSMP.id,
            kelasId: kelas.id,
            nis,
            nisn: `00${String(siswaCounter).padStart(8, '0')}`,
            nama,
            jenisKelamin: 'L',
            tempatLahir: 'Jakarta',
            tanggalLahir: new Date(2011 - tingkatIdx, Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1),
            namaAyah: `Ayah ${nama}`,
            phoneAyah: `081${Math.floor(Math.random() * 1000000000).toString().padStart(9, '0')}`,
            namaIbu: `Ibu ${nama}`,
            phoneIbu: `082${Math.floor(Math.random() * 1000000000).toString().padStart(9, '0')}`,
            qrToken,
            qrExpiredAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
          }
        });
        siswaCounter++;
      }
      
      for (let i = 0; i < 5; i++) {
        const nama = namaSiswaP[(siswaCounter + i) % namaSiswaP.length];
        const nis = `SMP${String(siswaCounter).padStart(4, '0')}`;
        const tempId = `siswa_${Date.now()}_${siswaCounter}`;
        const qrToken = generateSecureToken(tempId, nis);
        
        await db.siswa.create({
          data: {
            sekolahId: sekolahSMP.id,
            kelasId: kelas.id,
            nis,
            nisn: `00${String(siswaCounter).padStart(8, '0')}`,
            nama,
            jenisKelamin: 'P',
            tempatLahir: 'Jakarta',
            tanggalLahir: new Date(2011 - tingkatIdx, Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1),
            namaAyah: `Ayah ${nama}`,
            phoneAyah: `081${Math.floor(Math.random() * 1000000000).toString().padStart(9, '0')}`,
            namaIbu: `Ibu ${nama}`,
            phoneIbu: `082${Math.floor(Math.random() * 1000000000).toString().padStart(9, '0')}`,
            qrToken,
            qrExpiredAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
          }
        });
        siswaCounter++;
      }
    }
    
    // Create admin users
    const hashedPassword = await hashPassword('admin123');
    
    await db.user.create({
      data: {
        email: 'superadmin@nurulhuda.sch.id',
        password: hashedPassword,
        nama: 'Super Admin',
        role: 'SUPER_ADMIN',
        yayasanId: yayasan.id
      }
    });
    
    await db.user.create({
      data: {
        email: 'admin.sd@nurulhuda.sch.id',
        password: hashedPassword,
        nama: 'Admin SD',
        role: 'ADMIN_SEKOLAH',
        sekolahId: sekolahSD.id,
        yayasanId: yayasan.id
      }
    });
    
    await db.user.create({
      data: {
        email: 'admin.smp@nurulhuda.sch.id',
        password: hashedPassword,
        nama: 'Admin SMP',
        role: 'ADMIN_SEKOLAH',
        sekolahId: sekolahSMP.id,
        yayasanId: yayasan.id
      }
    });
    
    await db.user.create({
      data: {
        email: 'operator@nurulhuda.sch.id',
        password: hashedPassword,
        nama: 'Operator Absensi',
        role: 'OPERATOR',
        sekolahId: sekolahSD.id,
        yayasanId: yayasan.id
      }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Database berhasil diinisialisasi',
      data: {
        yayasan: yayasan.nama,
        sekolah: [
          { nama: sekolahSD.nama, siswa: 120 },
          { nama: sekolahSMP.nama, siswa: 30 }
        ],
        users: [
          { email: 'superadmin@nurulhuda.sch.id', password: 'admin123' },
          { email: 'admin.sd@nurulhuda.sch.id', password: 'admin123' },
          { email: 'admin.smp@nurulhuda.sch.id', password: 'admin123' },
          { email: 'operator@nurulhuda.sch.id', password: 'admin123' }
        ]
      }
    });
    
  } catch (error) {
    console.error('Init error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat inisialisasi', error: String(error) },
      { status: 500 }
    );
  }
}

// GET - Check initialization status
export async function GET() {
  try {
    const yayasan = await db.yayasan.findFirst();
    
    return NextResponse.json({
      success: true,
      initialized: !!yayasan
    });
  } catch (error) {
    return NextResponse.json({
      success: true,
      initialized: false
    });
  }
}
