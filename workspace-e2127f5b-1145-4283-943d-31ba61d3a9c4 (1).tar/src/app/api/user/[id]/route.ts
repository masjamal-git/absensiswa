import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';

// GET - Get single user
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const user = await db.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        nama: true,
        role: true,
        phone: true,
        avatar: true,
        isActive: true,
        lastLogin: true,
        createdAt: true,
        updatedAt: true,
        yayasanId: true,
        sekolahId: true,
        yayasan: {
          select: { id: true, nama: true }
        },
        sekolah: {
          select: { id: true, nama: true }
        }
      }
    });

    if (!user) {
      return NextResponse.json(
        { success: false, message: 'User tidak ditemukan' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, data: user });
  } catch (error) {
    console.error('Error fetching user:', error);
    return NextResponse.json(
      { success: false, message: 'Gagal mengambil data user' },
      { status: 500 }
    );
  }
}

// PUT - Update user
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { email, password, nama, role, yayasanId, sekolahId, phone, isActive } = body;

    // Check if user exists
    const existingUser = await db.user.findUnique({
      where: { id }
    });

    if (!existingUser) {
      return NextResponse.json(
        { success: false, message: 'User tidak ditemukan' },
        { status: 404 }
      );
    }

    // Check if email is being changed and already exists
    if (email && email !== existingUser.email) {
      const emailExists = await db.user.findUnique({
        where: { email }
      });
      if (emailExists) {
        return NextResponse.json(
          { success: false, message: 'Email sudah digunakan' },
          { status: 400 }
        );
      }
    }

    // Validate role if provided
    if (role) {
      const validRoles = ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'];
      if (!validRoles.includes(role)) {
        return NextResponse.json(
          { success: false, message: 'Role tidak valid' },
          { status: 400 }
        );
      }
    }

    // Build update data
    const updateData: any = {};
    if (email) updateData.email = email;
    if (password) updateData.password = await bcrypt.hash(password, 10);
    if (nama) updateData.nama = nama;
    if (role) updateData.role = role;
    if (yayasanId !== undefined) updateData.yayasanId = yayasanId || null;
    if (sekolahId !== undefined) updateData.sekolahId = sekolahId || null;
    if (phone !== undefined) updateData.phone = phone || null;
    if (isActive !== undefined) updateData.isActive = isActive;

    // Update user
    const user = await db.user.update({
      where: { id },
      data: updateData,
      select: {
        id: true,
        email: true,
        nama: true,
        role: true,
        phone: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
        yayasan: {
          select: { id: true, nama: true }
        },
        sekolah: {
          select: { id: true, nama: true }
        }
      }
    });

    return NextResponse.json({ 
      success: true, 
      message: 'User berhasil diperbarui',
      data: user 
    });
  } catch (error) {
    console.error('Error updating user:', error);
    return NextResponse.json(
      { success: false, message: 'Gagal memperbarui user' },
      { status: 500 }
    );
  }
}

// DELETE - Delete user
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Check if user exists
    const existingUser = await db.user.findUnique({
      where: { id }
    });

    if (!existingUser) {
      return NextResponse.json(
        { success: false, message: 'User tidak ditemukan' },
        { status: 404 }
      );
    }

    // Delete user
    await db.user.delete({
      where: { id }
    });

    return NextResponse.json({ 
      success: true, 
      message: 'User berhasil dihapus' 
    });
  } catch (error) {
    console.error('Error deleting user:', error);
    return NextResponse.json(
      { success: false, message: 'Gagal menghapus user' },
      { status: 500 }
    );
  }
}
