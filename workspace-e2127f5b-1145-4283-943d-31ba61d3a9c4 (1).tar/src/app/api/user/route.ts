import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';

// GET - List all users
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const yayasanId = searchParams.get('yayasanId');
    const sekolahId = searchParams.get('sekolahId');
    const role = searchParams.get('role');
    const search = searchParams.get('search');

    const where: any = {};
    
    if (yayasanId) where.yayasanId = yayasanId;
    if (sekolahId) where.sekolahId = sekolahId;
    if (role) where.role = role;
    if (search) {
      where.OR = [
        { nama: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    const users = await db.user.findMany({
      where,
      select: {
        id: true,
        email: true,
        nama: true,
        role: true,
        phone: true,
        avatar: true,
        isActive: true,
        lastLogin: true,
        createdAt: true,
        updatedAt: true,
        yayasanId: true,
        sekolahId: true,
        yayasan: {
          select: { id: true, nama: true }
        },
        sekolah: {
          select: { id: true, nama: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({ success: true, data: users });
  } catch (error) {
    console.error('Error fetching users:', error);
    return NextResponse.json(
      { success: false, message: 'Gagal mengambil data user' },
      { status: 500 }
    );
  }
}

// POST - Create new user
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, nama, role, yayasanId, sekolahId, phone, isActive } = body;

    // Validation
    if (!email || !password || !nama || !role) {
      return NextResponse.json(
        { success: false, message: 'Email, password, nama, dan role wajib diisi' },
        { status: 400 }
      );
    }

    // Check if email already exists
    const existingUser = await db.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      return NextResponse.json(
        { success: false, message: 'Email sudah terdaftar' },
        { status: 400 }
      );
    }

    // Validate role
    const validRoles = ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'];
    if (!validRoles.includes(role)) {
      return NextResponse.json(
        { success: false, message: 'Role tidak valid' },
        { status: 400 }
      );
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const user = await db.user.create({
      data: {
        email,
        password: hashedPassword,
        nama,
        role,
        yayasanId: yayasanId || null,
        sekolahId: sekolahId || null,
        phone: phone || null,
        isActive: isActive ?? true,
      },
      select: {
        id: true,
        email: true,
        nama: true,
        role: true,
        phone: true,
        isActive: true,
        createdAt: true,
        yayasan: {
          select: { id: true, nama: true }
        },
        sekolah: {
          select: { id: true, nama: true }
        }
      }
    });

    return NextResponse.json({ 
      success: true, 
      message: 'User berhasil dibuat',
      data: user 
    });
  } catch (error) {
    console.error('Error creating user:', error);
    return NextResponse.json(
      { success: false, message: 'Gagal membuat user' },
      { status: 500 }
    );
  }
}
