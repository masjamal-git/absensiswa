import { NextResponse } from 'next/server';
import { clearAuthCookie, getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';

export async function POST() {
  try {
    const user = await getCurrentUser();
    
    if (user) {
      await db.logAktivitas.create({
        data: {
          userId: user.id,
          aksi: 'LOGOUT',
          deskripsi: 'User logged out'
        }
      });
    }
    
    await clearAuthCookie();
    
    return NextResponse.json({
      success: true,
      message: 'Logout berhasil'
    });
  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
