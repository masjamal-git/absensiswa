import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyPassword, generateToken, setAuthCookie } from '@/lib/auth';
import { z } from 'zod';

const loginSchema = z.object({
  email: z.string().email('Email tidak valid'),
  password: z.string().min(6, 'Password minimal 6 karakter')
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const validation = loginSchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: 'Input tidak valid', errors: validation.error.flatten() },
        { status: 400 }
      );
    }
    
    const { email, password } = validation.data;
    
    const user = await db.user.findUnique({
      where: { email },
      include: {
        sekolah: {
          select: {
            id: true,
            nama: true,
            yayasanId: true
          }
        }
      }
    });
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Email atau password salah' },
        { status: 401 }
      );
    }
    
    if (!user.isActive) {
      return NextResponse.json(
        { success: false, message: 'Akun Anda tidak aktif' },
        { status: 401 }
      );
    }
    
    const isValid = await verifyPassword(password, user.password);
    if (!isValid) {
      return NextResponse.json(
        { success: false, message: 'Email atau password salah' },
        { status: 401 }
      );
    }
    
    const token = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      sekolahId: user.sekolahId || undefined,
      yayasanId: user.yayasanId || undefined
    });
    
    await setAuthCookie(token);
    
    await db.user.update({
      where: { id: user.id },
      data: { lastLogin: new Date() }
    });
    
    await db.logAktivitas.create({
      data: {
        id: crypto.randomUUID(),
        userId: user.id,
        aksi: 'LOGIN',
        deskripsi: 'User logged in',
        ip: request.headers.get('x-forwarded-for') || 'unknown',
        userAgent: request.headers.get('user-agent') || 'unknown'
      }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Login berhasil',
      user: {
        id: user.id,
        email: user.email,
        nama: user.nama,
        role: user.role,
        sekolah: user.sekolah
      }
    });
    
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan server' },
      { status: 500 }
    );
  }
}
