import { NextRequest, NextResponse } from 'next/server';
import { writeFile, mkdir, unlink } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';
import { db } from '@/lib/db';

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads', 'logo');
const MAX_FILE_SIZE = 2 * 1024 * 1024; // 2MB
const ALLOWED_TYPES = ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml', 'image/webp'];

// POST - Upload school logo
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    const sekolahId = formData.get('sekolahId') as string | null;
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'sekolahId wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    if (!file) {
      return NextResponse.json(
        { success: false, message: 'File tidak ditemukan' },
        { status: 400 }
      );
    }
    
    // Validate file type
    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json(
        { success: false, message: 'Format file tidak didukung. Gunakan PNG, JPG, SVG, atau WebP.' },
        { status: 400 }
      );
    }
    
    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json(
        { success: false, message: 'Ukuran file maksimal 2MB.' },
        { status: 400 }
      );
    }
    
    // Ensure upload directory exists
    if (!existsSync(UPLOAD_DIR)) {
      await mkdir(UPLOAD_DIR, { recursive: true });
    }
    
    // Delete old logo if exists
    const oldSettings = await db.pengaturanKartu.findUnique({
      where: { sekolahId },
      select: { logoSekolah: true }
    });
    
    if (oldSettings?.logoSekolah) {
      const oldPath = path.join(process.cwd(), 'public', oldSettings.logoSekolah);
      if (existsSync(oldPath)) {
        try { await unlink(oldPath); } catch {}
      }
    }
    
    // Generate unique filename
    const ext = file.name.split('.').pop() || 'png';
    const filename = `logo-${sekolahId}-${Date.now()}.${ext}`;
    const filePath = path.join(UPLOAD_DIR, filename);
    
    // Write file
    const bytes = await file.arrayBuffer();
    await writeFile(filePath, Buffer.from(bytes));
    
    // Public URL path
    const publicPath = `/uploads/logo/${filename}`;
    
    // Update database
    await db.pengaturanKartu.upsert({
      where: { sekolahId },
      create: { sekolahId, logoSekolah: publicPath },
      update: { logoSekolah: publicPath }
    });
    
    return NextResponse.json({
      success: true,
      data: {
        url: publicPath,
        filename
      }
    });
    
  } catch (error) {
    console.error('Logo upload error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat upload logo' },
      { status: 500 }
    );
  }
}

// DELETE - Remove school logo
export async function DELETE(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'sekolahId wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Get current logo path
    const settings = await db.pengaturanKartu.findUnique({
      where: { sekolahId },
      select: { logoSekolah: true }
    });
    
    if (settings?.logoSekolah) {
      const filePath = path.join(process.cwd(), 'public', settings.logoSekolah);
      if (existsSync(filePath)) {
        try { await unlink(filePath); } catch {}
      }
      
      // Clear logo from database
      await db.pengaturanKartu.update({
        where: { sekolahId },
        data: { logoSekolah: null }
      });
    }
    
    return NextResponse.json({
      success: true,
      message: 'Logo berhasil dihapus'
    });
    
  } catch (error) {
    console.error('Logo delete error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
