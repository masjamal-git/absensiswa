import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';

// Helper function to check access
function checkAccess(user: any, sekolahId: string): boolean {
  if (user.role === 'SUPER_ADMIN') return true;
  if (user.sekolahId === sekolahId) return true;
  return false;
}

// GET - Get single tingkat
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    
    const tingkat = await db.tingkat.findUnique({
      where: { id },
      include: {
        _count: {
          select: { kelas: true }
        }
      }
    });
    
    if (!tingkat) {
      return NextResponse.json(
        { success: false, message: 'Tingkat tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, tingkat.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: tingkat
    });
  } catch (error) {
    console.error('Get tingkat error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// PUT - Update tingkat
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    const body = await request.json();
    const { nama, urutan, keterangan, isActive } = body;
    
    // Get existing tingkat
    const existingTingkat = await db.tingkat.findUnique({
      where: { id }
    });
    
    if (!existingTingkat) {
      return NextResponse.json(
        { success: false, message: 'Tingkat tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, existingTingkat.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if tingkat with same name already exists (excluding current)
    if (nama && nama !== existingTingkat.nama) {
      const duplicateTingkat = await db.tingkat.findFirst({
        where: {
          sekolahId: existingTingkat.sekolahId,
          nama,
          isActive: true,
          id: { not: id }
        }
      });
      
      if (duplicateTingkat) {
        return NextResponse.json(
          { success: false, message: 'Tingkat dengan nama tersebut sudah ada' },
          { status: 400 }
        );
      }
    }
    
    const updateData: any = {};
    if (nama !== undefined) updateData.nama = nama;
    if (urutan !== undefined) updateData.urutan = parseInt(urutan);
    if (keterangan !== undefined) updateData.keterangan = keterangan || null;
    if (isActive !== undefined) updateData.isActive = isActive;
    
    const tingkat = await db.tingkat.update({
      where: { id },
      data: updateData
    });
    
    return NextResponse.json({
      success: true,
      message: 'Tingkat berhasil diperbarui',
      data: tingkat
    });
  } catch (error) {
    console.error('Update tingkat error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// DELETE - Delete tingkat (soft delete)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    
    // Get existing tingkat
    const existingTingkat = await db.tingkat.findUnique({
      where: { id },
      include: {
        _count: {
          select: { kelas: true }
        }
      }
    });
    
    if (!existingTingkat) {
      return NextResponse.json(
        { success: false, message: 'Tingkat tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, existingTingkat.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if tingkat has classes
    if (existingTingkat._count.kelas > 0) {
      return NextResponse.json(
        { success: false, message: `Tidak dapat menghapus tingkat karena masih memiliki ${existingTingkat._count.kelas} kelas` },
        { status: 400 }
      );
    }
    
    // Soft delete
    await db.tingkat.update({
      where: { id },
      data: { isActive: false }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Tingkat berhasil dihapus'
    });
  } catch (error) {
    console.error('Delete tingkat error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
