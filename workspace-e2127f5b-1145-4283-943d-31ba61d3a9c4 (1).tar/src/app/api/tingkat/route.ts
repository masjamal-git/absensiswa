import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';

// Helper function to check access
function checkAccess(user: any, sekolahId: string): boolean {
  if (user.role === 'SUPER_ADMIN') return true;
  if (user.sekolahId === sekolahId) return true;
  return false;
}

// GET - List tingkat by sekolah
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah ID wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!checkAccess(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    const tingkat = await db.tingkat.findMany({
      where: {
        sekolahId,
        isActive: true
      },
      include: {
        _count: {
          select: { kelas: true }
        }
      },
      orderBy: { urutan: 'asc' }
    });
    
    return NextResponse.json({
      success: true,
      data: tingkat
    });
  } catch (error) {
    console.error('Get tingkat error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// POST - Create new tingkat
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const { sekolahId, nama, urutan, keterangan, isActive } = body;
    
    if (!sekolahId || !nama || urutan === undefined) {
      return NextResponse.json(
        { success: false, message: 'Sekolah, nama, dan urutan wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!checkAccess(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if tingkat with same name already exists in sekolah
    const existingTingkat = await db.tingkat.findFirst({
      where: {
        sekolahId,
        nama,
        isActive: true
      }
    });
    
    if (existingTingkat) {
      return NextResponse.json(
        { success: false, message: 'Tingkat dengan nama tersebut sudah ada' },
        { status: 400 }
      );
    }
    
    const tingkat = await db.tingkat.create({
      data: {
        sekolahId,
        nama,
        urutan: parseInt(urutan),
        keterangan: keterangan || null,
        isActive: isActive ?? true
      }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Tingkat berhasil ditambahkan',
      data: tingkat
    });
  } catch (error) {
    console.error('Create tingkat error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
