import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';

// GET - Get WhatsApp settings for a school
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah ID wajib diisi' },
        { status: 400 }
      );
    }
    
    // Get or create settings
    let settings = await db.pengaturanWhatsApp.findUnique({
      where: { sekolahId }
    });
    
    if (!settings) {
      // Create default settings
      settings = await db.pengaturanWhatsApp.create({
        data: {
          sekolahId,
          provider: 'fonnte',
          isActive: false,
          notifMasuk: true,
          notifPulang: true
        }
      });
    }
    
    // Return settings (mask API key)
    return NextResponse.json({
      success: true,
      data: {
        id: settings.id,
        provider: settings.provider,
        apiKey: settings.apiKey ? '******' : '',
        hasApiKey: !!settings.apiKey,
        apiUrl: settings.apiUrl,
        isActive: settings.isActive,
        notifMasuk: settings.notifMasuk,
        notifPulang: settings.notifPulang,
        isConfigured: !!(settings.apiKey && settings.isActive)
      }
    });
  } catch (error) {
    console.error('Get WhatsApp settings error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// POST - Save WhatsApp settings
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const { sekolahId, provider, apiKey, apiUrl, isActive, notifMasuk, notifPulang } = body;
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah ID wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Get existing settings
    const existing = await db.pengaturanWhatsApp.findUnique({
      where: { sekolahId }
    });
    
    let settings;
    
    if (existing) {
      // Update - only update apiKey if provided (not masked)
      const updateData: any = {
        provider: provider || existing.provider,
        apiUrl: apiUrl || existing.apiUrl,
        isActive: isActive !== undefined ? isActive : existing.isActive,
        notifMasuk: notifMasuk !== undefined ? notifMasuk : existing.notifMasuk,
        notifPulang: notifPulang !== undefined ? notifPulang : existing.notifPulang
      };
      
      // Only update API key if it's not the masked version
      if (apiKey && apiKey !== '******') {
        updateData.apiKey = apiKey;
      }
      
      settings = await db.pengaturanWhatsApp.update({
        where: { sekolahId },
        data: updateData
      });
    } else {
      // Create new
      settings = await db.pengaturanWhatsApp.create({
        data: {
          sekolahId,
          provider: provider || 'fonnte',
          apiKey: apiKey || null,
          apiUrl: apiUrl || 'https://api.fonnte.com/send',
          isActive: isActive || false,
          notifMasuk: notifMasuk !== false,
          notifPulang: notifPulang !== false
        }
      });
    }
    
    return NextResponse.json({
      success: true,
      message: 'Pengaturan WhatsApp berhasil disimpan',
      data: {
        id: settings.id,
        provider: settings.provider,
        apiKey: settings.apiKey ? '******' : '',
        hasApiKey: !!settings.apiKey,
        apiUrl: settings.apiUrl,
        isActive: settings.isActive,
        notifMasuk: settings.notifMasuk,
        notifPulang: settings.notifPulang,
        isConfigured: !!(settings.apiKey && settings.isActive)
      }
    });
  } catch (error) {
    console.error('Save WhatsApp settings error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat menyimpan pengaturan' },
      { status: 500 }
    );
  }
}

// DELETE - Delete WhatsApp settings (reset)
export async function DELETE(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah ID wajib diisi' },
        { status: 400 }
      );
    }
    
    await db.pengaturanWhatsApp.delete({
      where: { sekolahId }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Pengaturan WhatsApp berhasil direset'
    });
  } catch (error) {
    console.error('Delete WhatsApp settings error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
