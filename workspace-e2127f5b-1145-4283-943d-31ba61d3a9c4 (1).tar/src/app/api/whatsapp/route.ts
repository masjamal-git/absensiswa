import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { testWhatsAppConnection, formatPhoneNumber } from '@/lib/whatsapp';
import { formatNowInTimezone } from '@/lib/timezone';

// GET - Get WhatsApp settings status
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    
    if (!sekolahId) {
      return NextResponse.json({
        success: true,
        data: {
          provider: 'fonnte',
          isConfigured: false
        }
      });
    }
    
    // Get settings from database
    const settings = await db.pengaturanWhatsApp.findUnique({
      where: { sekolahId }
    });
    
    return NextResponse.json({
      success: true,
      data: {
        provider: settings?.provider || 'fonnte',
        isConfigured: !!(settings?.apiKey && settings?.isActive),
        isActive: settings?.isActive || false,
        hasApiKey: !!settings?.apiKey
      }
    });
  } catch (error) {
    console.error('Get WhatsApp settings error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// POST - Test WhatsApp notification
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const { phone, sekolahId, testMessage } = body;
    
    if (!phone) {
      return NextResponse.json(
        { success: false, message: 'Nomor HP wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah ID wajib diisi' },
        { status: 400 }
      );
    }
    
    const formattedPhone = formatPhoneNumber(phone);
    
    // Get school timezone
    const sekolah = await db.sekolah.findUnique({ where: { id: sekolahId }, select: { timezone: true } });
    const tz = sekolah?.timezone || 'Asia/Jakarta';
    
    const message = testMessage || `🧪 *TEST NOTIFIKASI*

Ini adalah pesan test dari Sistem Absensi Digital.

Waktu: ${formatNowInTimezone(tz)}

Jika Anda menerima pesan ini, berarti konfigurasi WhatsApp berhasil! ✅

---
Pesan ini dikirim otomatis oleh Sistem Absensi Digital.`;

    const result = await testWhatsAppConnection(sekolahId, formattedPhone);
    
    if (result.success) {
      return NextResponse.json({
        success: true,
        message: 'Pesan test berhasil dikirim',
        data: {
          phone: formattedPhone,
          messageId: result.messageId
        }
      });
    } else {
      return NextResponse.json({
        success: false,
        message: `Gagal mengirim: ${result.error}`,
        data: {
          phone: formattedPhone
        }
      });
    }
  } catch (error) {
    console.error('Test WhatsApp error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat mengirim test' },
      { status: 500 }
    );
  }
}
