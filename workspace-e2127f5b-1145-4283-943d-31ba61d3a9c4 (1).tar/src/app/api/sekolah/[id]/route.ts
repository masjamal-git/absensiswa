import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { z } from 'zod';

const sekolahUpdateSchema = z.object({
  nama: z.string().min(1, 'Nama sekolah wajib diisi'),
  npsn: z.string().optional(),
  alamat: z.string().optional(),
  telepon: z.string().optional(),
  email: z.string().email('Email tidak valid').optional().or(z.literal('')),
  jenis: z.enum(['SD', 'SMP', 'SMA', 'SMK', 'TK', 'RA', 'MI', 'MTs', 'MA']),
  jamMasuk: z.string().regex(/^\d{2}:\d{2}$/, 'Format jam tidak valid (HH:MM)'),
  jamToleransi: z.string().regex(/^\d+$/, 'Toleransi harus angka'),
  jamPulang: z.string().regex(/^\d{2}:\d{2}$/, 'Format jam tidak valid (HH:MM)'),
  jamToleransiPulang: z.string().regex(/^\d+$/, 'Toleransi harus angka'),
  isActive: z.boolean().optional()
});

// GET - Get single sekolah
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    
    const sekolah = await db.sekolah.findUnique({
      where: { id },
      include: {
        yayasan: {
          select: { id: true, nama: true }
        },
        _count: {
          select: { siswa: true, kelas: true }
        }
      }
    });
    
    if (!sekolah) {
      return NextResponse.json(
        { success: false, message: 'Sekolah tidak ditemukan' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: sekolah
    });
  } catch (error) {
    console.error('Get sekolah error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// PUT - Update sekolah
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json(
        { success: false, message: 'Unauthorized - Hanya Super Admin yang dapat mengubah sekolah' },
        { status: 403 }
      );
    }
    
    const { id } = await params;
    const body = await request.json();
    const validation = sekolahUpdateSchema.safeParse(body);
    
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: 'Input tidak valid', errors: validation.error.flatten() },
        { status: 400 }
      );
    }
    
    const data = validation.data;
    
    // Check if sekolah exists
    const existingSekolah = await db.sekolah.findUnique({
      where: { id }
    });
    
    if (!existingSekolah) {
      return NextResponse.json(
        { success: false, message: 'Sekolah tidak ditemukan' },
        { status: 404 }
      );
    }
    
    // Check if NPSN already exists (for different school)
    if (data.npsn) {
      const existingNPSN = await db.sekolah.findFirst({
        where: { 
          npsn: data.npsn,
          NOT: { id }
        }
      });
      
      if (existingNPSN) {
        return NextResponse.json(
          { success: false, message: 'NPSN sudah digunakan sekolah lain' },
          { status: 400 }
        );
      }
    }
    
    const sekolah = await db.sekolah.update({
      where: { id },
      data: {
        nama: data.nama,
        npsn: data.npsn || null,
        alamat: data.alamat,
        telepon: data.telepon,
        email: data.email || null,
        jenis: data.jenis,
        jamMasuk: data.jamMasuk,
        jamToleransi: data.jamToleransi,
        jamPulang: data.jamPulang,
        jamToleransiPulang: data.jamToleransiPulang,
        isActive: data.isActive
      },
      include: {
        yayasan: {
          select: { id: true, nama: true }
        }
      }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Sekolah berhasil diperbarui',
      data: sekolah
    });
  } catch (error) {
    console.error('Update sekolah error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// DELETE - Delete sekolah
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json(
        { success: false, message: 'Unauthorized - Hanya Super Admin yang dapat menghapus sekolah' },
        { status: 403 }
      );
    }
    
    const { id } = await params;
    
    // Check if sekolah exists
    const existingSekolah = await db.sekolah.findUnique({
      where: { id },
      include: {
        _count: {
          select: { siswa: true, kelas: true, users: true }
        }
      }
    });
    
    if (!existingSekolah) {
      return NextResponse.json(
        { success: false, message: 'Sekolah tidak ditemukan' },
        { status: 404 }
      );
    }
    
    // Check if sekolah has data
    if (existingSekolah._count.siswa > 0 || existingSekolah._count.kelas > 0) {
      return NextResponse.json(
        { success: false, message: 'Tidak dapat menghapus sekolah yang masih memiliki siswa atau kelas' },
        { status: 400 }
      );
    }
    
    await db.sekolah.delete({
      where: { id }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Sekolah berhasil dihapus'
    });
  } catch (error) {
    console.error('Delete sekolah error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
