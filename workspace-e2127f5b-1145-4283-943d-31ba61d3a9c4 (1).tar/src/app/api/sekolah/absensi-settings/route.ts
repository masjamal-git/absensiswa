import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';
import { z } from 'zod';

const settingsSchema = z.object({
  sekolahId: z.string().min(1, 'Sekolah ID wajib diisi'),
  jamBukaAbsen: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Format jam tidak valid (HH:MM)'),
  jamTutupAbsen: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Format jam tidak valid (HH:MM)'),
  jamBukaAbsenPulang: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Format jam tidak valid (HH:MM)'),
  jamTutupAbsenPulang: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Format jam tidak valid (HH:MM)'),
  jamToleransi: z.string().optional(),
  jamToleransiPulang: z.string().optional(),
  absensiAktif: z.boolean(),
  timezone: z.string().min(1, 'Timezone wajib diisi')
});

// GET - Get attendance settings
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah ID wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    const sekolah = await db.sekolah.findUnique({
      where: { id: sekolahId },
      select: {
        id: true,
        nama: true,
        jamMasuk: true,
        jamToleransi: true,
        jamPulang: true,
        jamToleransiPulang: true,
        jamBukaAbsen: true,
        jamTutupAbsen: true,
        jamBukaAbsenPulang: true,
        jamTutupAbsenPulang: true,
        absensiAktif: true,
        timezone: true
      }
    });
    
    if (!sekolah) {
      return NextResponse.json(
        { success: false, message: 'Sekolah tidak ditemukan' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: sekolah
    });
  } catch (error) {
    console.error('Get attendance settings error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// POST - Update attendance settings
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const validation = settingsSchema.safeParse(body);
    
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: 'Input tidak valid', errors: validation.error.flatten() },
        { status: 400 }
      );
    }
    
    const { sekolahId, jamBukaAbsen, jamTutupAbsen, jamBukaAbsenPulang, jamTutupAbsenPulang, jamToleransi, jamToleransiPulang, absensiAktif, timezone } = validation.data;
    
    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Update sekolah settings
    // Also sync jamMasuk with jamBukaAbsen and jamPulang with jamBukaAbsenPulang
    const sekolah = await db.sekolah.update({
      where: { id: sekolahId },
      data: {
        // Attendance time settings
        jamBukaAbsen,
        jamTutupAbsen,
        jamBukaAbsenPulang,
        jamTutupAbsenPulang,
        // Toleransi keterlambatan (in minutes)
        ...(jamToleransi !== undefined && { jamToleransi }),
        ...(jamToleransiPulang !== undefined && { jamToleransiPulang }),
        absensiAktif,
        // Timezone setting
        timezone,
        // Sync school times with attendance settings
        jamMasuk: jamBukaAbsen,
        jamPulang: jamBukaAbsenPulang,
        updatedAt: new Date()
      }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Pengaturan absensi berhasil disimpan',
      data: sekolah
    });
  } catch (error) {
    console.error('Update attendance settings error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
