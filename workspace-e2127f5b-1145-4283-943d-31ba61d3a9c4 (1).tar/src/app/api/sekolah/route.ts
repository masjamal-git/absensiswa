import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { z } from 'zod';

const sekolahSchema = z.object({
  nama: z.string().min(1, 'Nama sekolah wajib diisi'),
  npsn: z.string().optional(),
  alamat: z.string().optional(),
  telepon: z.string().optional(),
  email: z.string().email('Email tidak valid').optional().or(z.literal('')),
  jenis: z.enum(['SD', 'SMP', 'SMA', 'SMK', 'TK', 'RA', 'MI', 'MTs', 'MA']),
  jamMasuk: z.string().regex(/^\d{2}:\d{2}$/, 'Format jam tidak valid (HH:MM)'),
  jamToleransi: z.string().regex(/^\d+$/, 'Toleransi harus angka'),
  jamPulang: z.string().regex(/^\d{2}:\d{2}$/, 'Format jam tidak valid (HH:MM)'),
  jamToleransiPulang: z.string().regex(/^\d+$/, 'Toleransi harus angka'),
  yayasanId: z.string().min(1, 'Yayasan wajib dipilih'),
  isActive: z.boolean().optional()
});

// GET - List all sekolah
export async function GET() {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    let sekolah;
    
    if (user.role === 'SUPER_ADMIN') {
      sekolah = await db.sekolah.findMany({
        include: {
          yayasan: {
            select: { id: true, nama: true }
          },
          _count: {
            select: { siswa: true, kelas: true }
          }
        },
        orderBy: { createdAt: 'desc' }
      });
    } else {
      sekolah = await db.sekolah.findMany({
        where: {
          OR: [
            { id: user.sekolahId || '' },
            { yayasanId: user.yayasanId || '' }
          ]
        },
        include: {
          yayasan: {
            select: { id: true, nama: true }
          },
          _count: {
            select: { siswa: true, kelas: true }
          }
        },
        orderBy: { createdAt: 'desc' }
      });
    }
    
    return NextResponse.json({
      success: true,
      data: sekolah
    });
  } catch (error) {
    console.error('Get sekolah error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// POST - Create new sekolah
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json(
        { success: false, message: 'Unauthorized - Hanya Super Admin yang dapat menambah sekolah' },
        { status: 403 }
      );
    }
    
    const body = await request.json();
    const validation = sekolahSchema.safeParse(body);
    
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: 'Input tidak valid', errors: validation.error.flatten() },
        { status: 400 }
      );
    }
    
    const data = validation.data;
    
    // Check if NPSN already exists
    if (data.npsn) {
      const existingNPSN = await db.sekolah.findUnique({
        where: { npsn: data.npsn }
      });
      
      if (existingNPSN) {
        return NextResponse.json(
          { success: false, message: 'NPSN sudah terdaftar' },
          { status: 400 }
        );
      }
    }
    
    const sekolah = await db.sekolah.create({
      data: {
        nama: data.nama,
        npsn: data.npsn || null,
        alamat: data.alamat,
        telepon: data.telepon,
        email: data.email || null,
        jenis: data.jenis,
        jamMasuk: data.jamMasuk,
        jamToleransi: data.jamToleransi,
        jamPulang: data.jamPulang,
        jamToleransiPulang: data.jamToleransiPulang,
        yayasanId: data.yayasanId,
        isActive: data.isActive ?? true
      },
      include: {
        yayasan: {
          select: { id: true, nama: true }
        }
      }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Sekolah berhasil ditambahkan',
      data: sekolah
    });
  } catch (error) {
    console.error('Create sekolah error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
