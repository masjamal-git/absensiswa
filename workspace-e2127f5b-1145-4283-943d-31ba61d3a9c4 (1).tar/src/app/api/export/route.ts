import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import {
  formatTimeInTimezone,
  formatNowInTimezone,
  formatDateInTimezone,
} from '@/lib/timezone';

// GET - Export attendance report
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    const format_type = searchParams.get('format') || 'excel';
    const tanggalDari = searchParams.get('dari');
    const tanggalSampai = searchParams.get('sampai');
    const kelasId = searchParams.get('kelasId');
    const tipe = searchParams.get('tipe') || 'detail'; // 'detail' | 'rekap'
    const periodeLabel = searchParams.get('periodeLabel') || '';
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah ID wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Get sekolah info
    const sekolah = await db.sekolah.findUnique({
      where: { id: sekolahId }
    });
    
    if (!sekolah) {
      return NextResponse.json(
        { success: false, message: 'Sekolah tidak ditemukan' },
        { status: 404 }
      );
    }
    
    const tz = sekolah.timezone || 'Asia/Jakarta';
    
    // Build date range
    let dari: Date;
    let sampai: Date;
    
    if (tanggalDari && tanggalSampai) {
      dari = new Date(tanggalDari + 'T00:00:00');
      sampai = new Date(tanggalSampai + 'T23:59:59');
    } else {
      // Default to current month
      const now = new Date();
      dari = new Date(now.getFullYear(), now.getMonth(), 1);
      sampai = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
    }
    
    // Build where clause
    const where: any = { 
      sekolahId,
      tanggal: { gte: dari, lte: sampai }
    };
    
    if (kelasId) {
      where.siswa = { kelasId };
    }
    
    // Get kelas filter info
    let kelasNama = 'Semua Kelas';
    if (kelasId) {
      const kelas = await db.kelas.findUnique({ where: { id: kelasId } });
      if (kelas) kelasNama = kelas.nama;
    }
    
    const label = periodeLabel || `${format(dari, 'dd/MM/yyyy')} - ${format(sampai, 'dd/MM/yyyy')}`;
    
    if (tipe === 'rekap') {
      // ===== REKAP REPORT (Summary per student) =====
      return generateRekapReport(sekolah, where, kelasId, kelasNama, dari, sampai, label, tz, format_type);
    } else {
      // ===== DETAIL REPORT (Daily log) =====
      return generateDetailReport(sekolah, where, dari, sampai, label, tz, format_type);
    }
    
  } catch (error) {
    console.error('Export error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// ===== DETAIL REPORT =====
async function generateDetailReport(
  sekolah: any, where: any, dari: Date, sampai: Date, 
  label: string, tz: string, format_type: string
) {
  const absensi = await db.absensi.findMany({
    where,
    include: {
      siswa: {
        include: {
          kelas: { select: { nama: true } }
        }
      }
    },
    orderBy: [
      { tanggal: 'asc' },
      { siswa: { nama: 'asc' } }
    ]
  });
  
  const data = absensi.map(a => ({
    tanggal: format(new Date(a.tanggal), 'dd/MM/yyyy', { locale: id }),
    nis: a.siswa.nis,
    nama: a.siswa.nama,
    kelas: a.siswa.kelas?.nama || '-',
    status: a.status,
    jamMasuk: a.jamMasuk ? formatTimeInTimezone(new Date(a.jamMasuk), tz) : '-',
    jamKeluar: a.jamKeluar ? formatTimeInTimezone(new Date(a.jamKeluar), tz) : '-',
    metode: a.metode,
    keterangan: a.keterangan || '-'
  }));
  
  if (format_type === 'excel') {
    return generateExcelDetail(data, sekolah.nama, label, tz);
  } else {
    return generatePDFDetail(data, sekolah.nama, label, tz);
  }
}

// ===== REKAP REPORT =====
async function generateRekapReport(
  sekolah: any, where: any, kelasId: string | null,
  kelasNama: string, dari: Date, sampai: Date,
  label: string, tz: string, format_type: string
) {
  // Get all siswa in the selected range
  const siswaWhere: any = { sekolahId: sekolah.id };
  if (kelasId) siswaWhere.kelasId = kelasId;
  
  const siswaList = await db.siswa.findMany({
    where: siswaWhere,
    include: {
      kelas: { select: { id: true, nama: true } }
    },
    orderBy: [
      { kelasId: 'asc' },
      { nama: 'asc' }
    ]
  });
  
  // Get all absensi in date range
  const absensiWhere: any = { sekolahId: sekolah.id, tanggal: { gte: dari, lte: sampai } };
  if (kelasId) absensiWhere.siswa = { kelasId };
  
  const absensiList = await db.absensi.findMany({
    where: absensiWhere,
    include: {
      siswa: { select: { id: true } }
    }
  });
  
  // Build per-student summary
  const summary: any[] = siswaList.map((siswa, index) => {
    const records = absensiList.filter(a => a.siswaId === siswa.id);
    
    const hadir = records.filter(a => a.status === 'HADIR').length;
    const terlambat = records.filter(a => a.status === 'TERLAMBAT').length;
    const sakit = records.filter(a => a.status === 'SAKIT').length;
    const izin = records.filter(a => a.status === 'IZIN').length;
    const alpa = records.filter(a => a.status === 'ALPA').length;
    const totalRecorded = hadir + terlambat + sakit + izin + alpa;
    
    // Count total school days in range
    const totalDays = countSchoolDays(dari, sampai);
    const belumAbsen = Math.max(0, totalDays - totalRecorded);
    
    return {
      no: index + 1,
      nis: siswa.nis,
      nama: siswa.nama,
      kelas: siswa.kelas?.nama || '-',
      hadir,
      terlambat,
      sakit,
      izin,
      alpa,
      belumAbsen,
      totalHari: totalDays,
      persentase: totalDays > 0 ? Math.round(((hadir + terlambat) / totalDays) * 100) : 0,
    };
  });
  
  // Per-class summary
  const kelasGroups: Record<string, any[]> = {};
  summary.forEach(s => {
    if (!kelasGroups[s.kelas]) kelasGroups[s.kelas] = [];
    kelasGroups[s.kelas].push(s);
  });
  
  const classSummaries = Object.entries(kelasGroups).map(([kelas, students]) => {
    const totals = students.reduce((acc, s) => ({
      hadir: acc.hadir + s.hadir,
      terlambat: acc.terlambat + s.terlambat,
      sakit: acc.sakit + s.sakit,
      izin: acc.izin + s.izin,
      alpa: acc.alpa + s.alpa,
      belumAbsen: acc.belumAbsen + s.belumAbsen,
    }), { hadir: 0, terlambat: 0, sakit: 0, izin: 0, alpa: 0, belumAbsen: 0 });
    
    return {
      kelas,
      jumlahSiswa: students.length,
      ...totals,
      persentaseKehadiran: students.length > 0 
        ? Math.round(((totals.hadir + totals.terlambat) / (students.length * countSchoolDays(dari, sampai))) * 100)
        : 0
    };
  });
  
  const reportData = {
    sekolah: sekolah.nama,
    npsn: sekolah.npsn || '-',
    alamat: sekolah.alamat || '-',
    periode: label,
    kelas: kelasNama,
    dari: format(dari, 'dd/MM/yyyy'),
    sampai: format(sampai, 'dd/MM/yyyy'),
    totalHari: countSchoolDays(dari, sampai),
    tanggalCetak: formatNowInTimezone(tz),
    summary,
    classSummaries,
    totalSiswa: siswaList.length,
    grandTotal: summary.reduce((acc, s) => ({
      hadir: acc.hadir + s.hadir,
      terlambat: acc.terlambat + s.terlambat,
      sakit: acc.sakit + s.sakit,
      izin: acc.izin + s.izin,
      alpa: acc.alpa + s.alpa,
      belumAbsen: acc.belumAbsen + s.belumAbsen,
    }), { hadir: 0, terlambat: 0, sakit: 0, izin: 0, alpa: 0, belumAbsen: 0 }),
  };
  
  if (format_type === 'excel') {
    return generateExcelRekap(reportData, sekolah.nama, label, tz);
  } else {
    return generatePDFRekap(reportData, sekolah.nama, label, tz);
  }
}

// Count school days (Mon-Sat, excluding Sunday) in a date range
function countSchoolDays(dari: Date, sampai: Date): number {
  let count = 0;
  const current = new Date(dari);
  const end = new Date(sampai);
  
  while (current <= end) {
    const day = current.getDay();
    if (day !== 0) count++; // Exclude Sunday (0)
    current.setDate(current.getDate() + 1);
  }
  
  return count;
}

// ===== EXCEL DETAIL =====
function generateExcelDetail(data: any[], sekolahNama: string, periode: string, tz: string) {
  const wb = XLSX.utils.book_new();
  
  const headers = [
    'No', 'Tanggal', 'NIS', 'Nama Siswa', 'Kelas', 
    'Status', 'Jam Masuk', 'Jam Keluar', 'Metode', 'Keterangan'
  ];
  
  const rows = data.map((row, i) => [
    i + 1, row.tanggal, row.nis, row.nama, row.kelas,
    row.status, row.jamMasuk, row.jamKeluar, row.metode, row.keterangan
  ]);
  
  const wsData = [headers, ...rows];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  
  ws['!cols'] = [
    { wch: 5 }, { wch: 12 }, { wch: 12 }, { wch: 25 }, { wch: 12 },
    { wch: 12 }, { wch: 10 }, { wch: 10 }, { wch: 10 }, { wch: 20 }
  ];
  
  XLSX.utils.book_append_sheet(wb, ws, 'Detail Absensi');
  
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  
  return new NextResponse(buf, {
    headers: {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="detail-absensi-${format(new Date(), 'yyyy-MM-dd')}.xlsx"`
    }
  });
}

// ===== PDF DETAIL =====
function generatePDFDetail(data: any[], sekolahNama: string, periode: string, tz: string) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' }) as any;
  
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('LAPORAN DETAIL ABSENSI SISWA', doc.internal.pageSize.getWidth() / 2, 15, { align: 'center' });
  
  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.text(sekolahNama, doc.internal.pageSize.getWidth() / 2, 22, { align: 'center' });
  
  doc.setFontSize(9);
  doc.text(`Periode: ${periode}`, doc.internal.pageSize.getWidth() / 2, 28, { align: 'center' });
  
  const headers = [['No', 'Tanggal', 'NIS', 'Nama', 'Kelas', 'Status', 'Jam Masuk', 'Jam Keluar', 'Metode', 'Keterangan']];
  
  const rows = data.map((row, i) => [
    i + 1, row.tanggal, row.nis, row.nama, row.kelas,
    row.status, row.jamMasuk, row.jamKeluar, row.metode, row.keterangan
  ]);
  
  doc.autoTable({
    head: headers,
    body: rows,
    startY: 33,
    styles: { fontSize: 7, cellPadding: 2 },
    headStyles: { fillColor: [16, 185, 129], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 250, 252] },
  });
  
  addPDFFooter(doc, tz);
  
  const pdfBuffer = Buffer.from(doc.output('arraybuffer'));
  return new NextResponse(pdfBuffer, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="detail-absensi-${format(new Date(), 'yyyy-MM-dd')}.pdf"`
    }
  });
}

// ===== EXCEL REKAP =====
function generateExcelRekap(reportData: any, sekolahNama: string, periode: string, tz: string) {
  const wb = XLSX.utils.book_new();
  
  // Sheet 1: Rekap Per Siswa
  const headers1 = [
    'No', 'NIS', 'Nama Siswa', 'Kelas', 'Hadir', 'Terlambat', 'Sakit', 'Izin', 'Alpa', 'Belum Absen', 'Total Hari', '% Kehadiran'
  ];
  
  const rows1 = reportData.summary.map((s: any) => [
    s.no, s.nis, s.nama, s.kelas, s.hadir, s.terlambat, s.sakit, s.izin, s.alpa, s.belumAbsen, s.totalHari, `${s.persentase}%`
  ]);
  
  // Add grand total row
  rows1.push([
    '', '', 'TOTAL', '', 
    reportData.grandTotal.hadir, reportData.grandTotal.terlambat,
    reportData.grandTotal.sakit, reportData.grandTotal.izin, reportData.grandTotal.alpa,
    reportData.grandTotal.belumAbsen, '', ''
  ]);
  
  const ws1Data = [headers1, ...rows1];
  const ws1 = XLSX.utils.aoa_to_sheet(ws1Data);
  
  ws1['!cols'] = [
    { wch: 5 }, { wch: 12 }, { wch: 25 }, { wch: 12 },
    { wch: 8 }, { wch: 10 }, { wch: 8 }, { wch: 8 }, { wch: 8 }, { wch: 12 }, { wch: 10 }, { wch: 12 }
  ];
  
  XLSX.utils.book_append_sheet(wb, ws1, 'Rekap Per Siswa');
  
  // Sheet 2: Rekap Per Kelas
  const headers2 = [
    'No', 'Kelas', 'Jumlah Siswa', 'Hadir', 'Terlambat', 'Sakit', 'Izin', 'Alpa', 'Belum Absen', '% Kehadiran'
  ];
  
  const rows2 = reportData.classSummaries.map((c: any, i: number) => [
    i + 1, c.kelas, c.jumlahSiswa, c.hadir, c.terlambat, c.sakit, c.izin, c.alpa, c.belumAbsen, `${c.persentaseKehadiran}%`
  ]);
  
  const ws2Data = [headers2, ...rows2];
  const ws2 = XLSX.utils.aoa_to_sheet(ws2Data);
  
  ws2['!cols'] = [
    { wch: 5 }, { wch: 15 }, { wch: 14 }, { wch: 8 }, { wch: 10 }, { wch: 8 }, { wch: 8 }, { wch: 8 }, { wch: 12 }, { wch: 12 }
  ];
  
  XLSX.utils.book_append_sheet(wb, ws2, 'Rekap Per Kelas');
  
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  
  return new NextResponse(buf, {
    headers: {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="rekap-absensi-${format(new Date(), 'yyyy-MM-dd')}.xlsx"`
    }
  });
}

// ===== PDF REKAP =====
function generatePDFRekap(reportData: any, sekolahNama: string, periode: string, tz: string) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Title
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('REKAP ABSENSI SISWA', pageWidth / 2, 12, { align: 'center' });
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(reportData.sekolah, pageWidth / 2, 17, { align: 'center' });
  if (reportData.npsn && reportData.npsn !== '-') {
    doc.text(`NPSN: ${reportData.npsn}`, pageWidth / 2, 21, { align: 'center' });
  }
  
  doc.setFontSize(9);
  const infoY = reportData.npsn && reportData.npsn !== '-' ? 26 : 22;
  doc.text(`Periode: ${periode}  |  Kelas: ${reportData.kelas}  |  Total Hari Efektif: ${reportData.totalHari} hari`, pageWidth / 2, infoY, { align: 'center' });
  
  // Rekap Per Siswa Table
  const tableStartY = infoY + 6;
  
  const headers = [['No', 'NIS', 'Nama Siswa', 'Kelas', 'H', 'T', 'S', 'I', 'A', 'BA', '%']];
  
  const rows = reportData.summary.map((s: any) => [
    s.no, s.nis, s.nama, s.kelas,
    s.hadir, s.terlambat, s.sakit, s.izin, s.alpa, s.belumAbsen,
    `${s.persentase}%`
  ]);
  
  doc.autoTable({
    head: headers,
    body: rows,
    startY: tableStartY,
    styles: { fontSize: 7, cellPadding: 1.5 },
    headStyles: { fillColor: [16, 185, 129], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    columnStyles: {
      0: { cellWidth: 8 },
      1: { cellWidth: 16 },
      2: { cellWidth: 45 },
      3: { cellWidth: 18 },
      4: { cellWidth: 8, halign: 'center' },
      5: { cellWidth: 8, halign: 'center' },
      6: { cellWidth: 8, halign: 'center' },
      7: { cellWidth: 8, halign: 'center' },
      8: { cellWidth: 8, halign: 'center' },
      9: { cellWidth: 10, halign: 'center' },
      10: { cellWidth: 12, halign: 'center' },
    },
    didDrawPage: (data: any) => {
      // Add footer on each page
      const pageCount = doc.internal.getNumberOfPages();
      doc.setFontSize(7);
      doc.setFont('helvetica', 'normal');
      doc.text(
        `Halaman ${pageCount} - Dicetak: ${reportData.tanggalCetak}  |  H=Hadir T=Terlambat S=Sakit I=Izin A=Alpa BA=Belum Absen`,
        pageWidth / 2,
        doc.internal.pageSize.getHeight() - 8,
        { align: 'center' }
      );
    },
  });
  
  const pdfBuffer = Buffer.from(doc.output('arraybuffer'));
  return new NextResponse(pdfBuffer, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="rekap-absensi-${format(new Date(), 'yyyy-MM-dd')}.pdf"`
    }
  });
}

// Helper: Add page footer to PDF
function addPDFFooter(doc: any, tz: string) {
  const pageCount = doc.internal.getNumberOfPages();
  const pageWidth = doc.internal.pageSize.getWidth();
  
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.text(
      `Halaman ${i} dari ${pageCount} - Dicetak pada ${formatNowInTimezone(tz)}`,
      pageWidth / 2,
      doc.internal.pageSize.getHeight() - 8,
      { align: 'center' }
    );
  }
}
