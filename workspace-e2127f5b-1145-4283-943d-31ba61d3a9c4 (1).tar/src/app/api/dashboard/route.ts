import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, subDays } from 'date-fns';
import { id } from 'date-fns/locale';
import {
  formatTimeInTimezone,
  formatDateYYYYMMDD,
  getStartOfDayInTimezone,
  getEndOfDayInTimezone,
  formatDateInTimezone,
} from '@/lib/timezone';

// GET - Dashboard statistics
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    
    if (!sekolahId) {
      return NextResponse.json(
        { success: false, message: 'Sekolah ID wajib diisi' },
        { status: 400 }
      );
    }
    
    if (!hasAccessToSekolah(user, sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Get sekolah info
    const sekolah = await db.sekolah.findUnique({
      where: { id: sekolahId },
      include: {
        _count: { select: { siswa: true, kelas: true } }
      }
    });
    
    if (!sekolah) {
      return NextResponse.json(
        { success: false, message: 'Sekolah tidak ditemukan' },
        { status: 404 }
      );
    }
    
    const tz = sekolah.timezone || 'Asia/Jakarta';
    const tanggal = searchParams.get('tanggal') || formatDateYYYYMMDD(new Date(), tz);
    
    // Today's date range (in school's timezone, converted to UTC for DB query)
    const now = new Date();
    const today = getStartOfDayInTimezone(tanggal ? new Date(tanggal + 'T00:00:00') : now, tz);
    const tomorrow = getEndOfDayInTimezone(tanggal ? new Date(tanggal + 'T00:00:00') : now, tz);
    
    // Get today's attendance stats
    const todayStats = await db.absensi.groupBy({
      by: ['status'],
      where: {
        sekolahId,
        tanggal: {
          gte: today,
          lt: tomorrow
        }
      },
      _count: true
    });
    
    // Calculate stats
    let totalHadir = 0;
    let totalTerlambat = 0;
    let totalIzin = 0;
    let totalSakit = 0;
    let totalAlpa = 0;
    
    todayStats.forEach(stat => {
      switch (stat.status) {
        case 'HADIR': totalHadir = stat._count; break;
        case 'TERLAMBAT': totalTerlambat = stat._count; break;
        case 'IZIN': totalIzin = stat._count; break;
        case 'SAKIT': totalSakit = stat._count; break;
        case 'ALPA': totalAlpa = stat._count; break;
      }
    });
    
    const totalSiswa = sekolah._count.siswa;
    const belumAbsen = totalSiswa - totalHadir - totalTerlambat - totalIzin - totalSakit - totalAlpa;
    
    // Get recent attendance (last 10)
    const recentAttendance = await db.absensi.findMany({
      where: {
        sekolahId,
        tanggal: {
          gte: today,
          lt: tomorrow
        }
      },
      include: {
        siswa: {
          include: {
            kelas: { select: { nama: true } }
          }
        }
      },
      orderBy: { jamMasuk: 'desc' },
      take: 10
    });
    
    // Get weekly stats for chart
    const weekStart = subDays(today, 6);
    const weeklyStats = await db.absensi.groupBy({
      by: ['status'],
      where: {
        sekolahId,
        tanggal: {
          gte: weekStart,
          lt: tomorrow
        }
      },
      _count: true
    });
    
    // Get daily stats for current month
    const monthStart = startOfMonth(today);
    const monthEnd = endOfMonth(today);
    
    const monthlyData = await db.absensi.groupBy({
      by: ['tanggal'],
      where: {
        sekolahId,
        tanggal: {
          gte: monthStart,
          lte: monthEnd
        },
        status: { in: ['HADIR', 'TERLAMBAT'] }
      },
      _count: true
    });
    
    // Get per-class stats
    const kelasStats = await db.kelas.findMany({
      where: { sekolahId, isActive: true },
      include: {
        tingkat: { select: { nama: true, urutan: true } },
        _count: { select: { siswa: true } },
        siswa: {
          include: {
            absensi: {
              where: {
                tanggal: {
                  gte: today,
                  lt: tomorrow
                }
              }
            }
          }
        }
      },
      orderBy: { nama: 'asc' }
    });
    
    const perKelasStats = kelasStats.map(kelas => {
      const hadir = kelas.siswa.filter(s => 
        s.absensi.some(a => ['HADIR', 'TERLAMBAT'].includes(a.status))
      ).length;
      
      return {
        id: kelas.id,
        nama: kelas.nama,
        tingkat: kelas.tingkat?.nama || '-',
        totalSiswa: kelas._count.siswa,
        hadir,
        belumHadir: kelas._count.siswa - hadir,
        persentase: kelas._count.siswa > 0 
          ? Math.round((hadir / kelas._count.siswa) * 100) 
          : 0
      };
    });
    
    return NextResponse.json({
      success: true,
      data: {
        sekolah: {
          id: sekolah.id,
          nama: sekolah.nama,
          jamMasuk: sekolah.jamMasuk,
          jamToleransi: sekolah.jamToleransi,
          jamPulang: sekolah.jamPulang,
          jamToleransiPulang: sekolah.jamToleransiPulang
        },
        today: {
          tanggal: formatDateInTimezone(new Date(), tz),
          totalSiswa,
          hadir: totalHadir,
          terlambat: totalTerlambat,
          izin: totalIzin,
          sakit: totalSakit,
          alpa: totalAlpa,
          belumAbsen: Math.max(0, belumAbsen),
          persentaseHadir: totalSiswa > 0 
            ? Math.round(((totalHadir + totalTerlambat) / totalSiswa) * 100) 
            : 0
        },
        recentAttendance: recentAttendance.map(a => ({
          id: a.id,
          siswaId: a.siswaId,
          nama: a.siswa.nama,
          kelas: a.siswa.kelas?.nama || '-',
          status: a.status,
          jam: a.jamMasuk ? formatTimeInTimezone(new Date(a.jamMasuk), tz) : '-',
          metode: a.metode
        })),
        weeklyStats: {
          hadir: weeklyStats.find(s => s.status === 'HADIR')?._count || 0,
          terlambat: weeklyStats.find(s => s.status === 'TERLAMBAT')?._count || 0,
          izin: weeklyStats.find(s => s.status === 'IZIN')?._count || 0,
          sakit: weeklyStats.find(s => s.status === 'SAKIT')?._count || 0,
          alpa: weeklyStats.find(s => s.status === 'ALPA')?._count || 0
        },
        perKelasStats
      }
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
