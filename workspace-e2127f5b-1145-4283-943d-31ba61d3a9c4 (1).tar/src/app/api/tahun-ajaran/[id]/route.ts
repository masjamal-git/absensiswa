import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { z } from 'zod';

const updateTahunAjaranSchema = z.object({
  nama: z.string().min(1, 'Nama tahun ajaran wajib diisi').optional(),
  tanggalMulai: z.string().min(1, 'Tanggal mulai wajib diisi').optional(),
  tanggalSelesai: z.string().min(1, 'Tanggal selesai wajib diisi').optional(),
  semester: z.number().min(1).max(2).optional(),
  isActive: z.boolean().optional(),
  isCurrent: z.boolean().optional()
});

// Helper function to check access
function checkAccess(user: any, sekolahId: string): boolean {
  if (user.role === 'SUPER_ADMIN') return true;
  if (user.sekolahId === sekolahId) return true;
  return false;
}

// GET - Get single tahun ajaran
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    
    const tahunAjaran = await db.tahunAjaran.findUnique({
      where: { id },
      include: {
        sekolah: {
          select: { id: true, nama: true }
        },
        _count: {
          select: { kelas: true }
        }
      }
    });
    
    if (!tahunAjaran) {
      return NextResponse.json(
        { success: false, message: 'Tahun ajaran tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, tahunAjaran.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: tahunAjaran
    });
  } catch (error) {
    console.error('Get tahun ajaran error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// PUT - Update tahun ajaran
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    const body = await request.json();
    const validation = updateTahunAjaranSchema.safeParse(body);
    
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: 'Input tidak valid', errors: validation.error.flatten() },
        { status: 400 }
      );
    }
    
    const data = validation.data;
    
    // Get existing tahun ajaran
    const existing = await db.tahunAjaran.findUnique({
      where: { id }
    });
    
    if (!existing) {
      return NextResponse.json(
        { success: false, message: 'Tahun ajaran tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, existing.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if nama already exists (if changing nama)
    if (data.nama && data.nama !== existing.nama) {
      const duplicate = await db.tahunAjaran.findFirst({
        where: {
          sekolahId: existing.sekolahId,
          nama: data.nama,
          id: { not: id }
        }
      });
      
      if (duplicate) {
        return NextResponse.json(
          { success: false, message: 'Nama tahun ajaran sudah digunakan' },
          { status: 400 }
        );
      }
    }
    
    // If this is set as current, unset other current tahun ajaran
    if (data.isCurrent) {
      await db.tahunAjaran.updateMany({
        where: {
          sekolahId: existing.sekolahId,
          isCurrent: true,
          id: { not: id }
        },
        data: { isCurrent: false }
      });
    }
    
    // Prepare update data
    const updateData: any = {};
    if (data.nama !== undefined) updateData.nama = data.nama;
    if (data.tanggalMulai !== undefined) updateData.tanggalMulai = new Date(data.tanggalMulai);
    if (data.tanggalSelesai !== undefined) updateData.tanggalSelesai = new Date(data.tanggalSelesai);
    if (data.semester !== undefined) updateData.semester = data.semester;
    if (data.isActive !== undefined) updateData.isActive = data.isActive;
    if (data.isCurrent !== undefined) updateData.isCurrent = data.isCurrent;
    
    const tahunAjaran = await db.tahunAjaran.update({
      where: { id },
      data: updateData
    });
    
    return NextResponse.json({
      success: true,
      message: 'Tahun ajaran berhasil diperbarui',
      data: tahunAjaran
    });
  } catch (error) {
    console.error('Update tahun ajaran error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// DELETE - Delete tahun ajaran
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    
    // Get existing tahun ajaran
    const existing = await db.tahunAjaran.findUnique({
      where: { id },
      include: {
        _count: {
          select: { kelas: true }
        }
      }
    });
    
    if (!existing) {
      return NextResponse.json(
        { success: false, message: 'Tahun ajaran tidak ditemukan' },
        { status: 404 }
      );
    }
    
    if (!checkAccess(user, existing.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if there are related kelas
    if (existing._count.kelas > 0) {
      return NextResponse.json(
        { success: false, message: `Tidak dapat menghapus. Terdapat ${existing._count.kelas} kelas yang terkait dengan tahun ajaran ini.` },
        { status: 400 }
      );
    }
    
    await db.tahunAjaran.delete({
      where: { id }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Tahun ajaran berhasil dihapus'
    });
  } catch (error) {
    console.error('Delete tahun ajaran error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan saat menghapus tahun ajaran' },
      { status: 500 }
    );
  }
}
