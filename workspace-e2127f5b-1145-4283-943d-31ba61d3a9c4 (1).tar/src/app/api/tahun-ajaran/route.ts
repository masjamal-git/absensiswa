import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, hasAccessToSekolah } from '@/lib/auth';
import { z } from 'zod';

const tahunAjaranSchema = z.object({
  nama: z.string().min(1, 'Nama tahun ajaran wajib diisi'),
  tanggalMulai: z.string().min(1, 'Tanggal mulai wajib diisi'),
  tanggalSelesai: z.string().min(1, 'Tanggal selesai wajib diisi'),
  semester: z.number().min(1).max(2),
  sekolahId: z.string().min(1, 'Sekolah wajib dipilih'),
  isActive: z.boolean().optional().default(true),
  isCurrent: z.boolean().optional().default(false)
});

// GET - List tahun ajaran
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const sekolahId = searchParams.get('sekolahId');
    const isActive = searchParams.get('isActive');
    
    const where: any = {};
    
    if (sekolahId) {
      if (!hasAccessToSekolah(user, sekolahId)) {
        return NextResponse.json(
          { success: false, message: 'Akses ditolak' },
          { status: 403 }
        );
      }
      where.sekolahId = sekolahId;
    } else if (user.sekolahId) {
      where.sekolahId = user.sekolahId;
    }
    
    if (isActive !== null && isActive !== undefined) {
      where.isActive = isActive === 'true';
    }
    
    const tahunAjaran = await db.tahunAjaran.findMany({
      where,
      include: {
        _count: {
          select: { kelas: true }
        }
      },
      orderBy: [
        { isCurrent: 'desc' },
        { createdAt: 'desc' }
      ]
    });
    
    return NextResponse.json({
      success: true,
      data: tahunAjaran
    });
  } catch (error) {
    console.error('Get tahun ajaran error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}

// POST - Create tahun ajaran
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const validation = tahunAjaranSchema.safeParse(body);
    
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: 'Input tidak valid', errors: validation.error.flatten() },
        { status: 400 }
      );
    }
    
    const data = validation.data;
    
    if (!hasAccessToSekolah(user, data.sekolahId)) {
      return NextResponse.json(
        { success: false, message: 'Akses ditolak' },
        { status: 403 }
      );
    }
    
    // Check if nama already exists for this sekolah
    const existing = await db.tahunAjaran.findFirst({
      where: {
        sekolahId: data.sekolahId,
        nama: data.nama
      }
    });
    
    if (existing) {
      return NextResponse.json(
        { success: false, message: 'Nama tahun ajaran sudah ada' },
        { status: 400 }
      );
    }
    
    // If this is set as current, unset other current tahun ajaran
    if (data.isCurrent) {
      await db.tahunAjaran.updateMany({
        where: {
          sekolahId: data.sekolahId,
          isCurrent: true
        },
        data: { isCurrent: false }
      });
    }
    
    const tahunAjaran = await db.tahunAjaran.create({
      data: {
        nama: data.nama,
        tanggalMulai: new Date(data.tanggalMulai),
        tanggalSelesai: new Date(data.tanggalSelesai),
        semester: data.semester,
        sekolahId: data.sekolahId,
        isActive: data.isActive,
        isCurrent: data.isCurrent
      }
    });
    
    return NextResponse.json({
      success: true,
      message: 'Tahun ajaran berhasil ditambahkan',
      data: tahunAjaran
    });
  } catch (error) {
    console.error('Create tahun ajaran error:', error);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
