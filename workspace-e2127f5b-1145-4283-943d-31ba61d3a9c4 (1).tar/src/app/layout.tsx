import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Sistem Absensi Siswa - QR Code & WhatsApp Notification",
  description: "Sistem Informasi Absensi Siswa berbasis Web dengan QR Code Scanner dan Notifikasi WhatsApp Real-time untuk Yayasan Pendidikan Multi Sekolah.",
  keywords: ["Absensi", "QR Code", "WhatsApp", "Sekolah", "Pendidikan", "Sistem Informasi"],
  authors: [{ name: "Yayasan Pendidikan" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Sistem Absensi Siswa",
    description: "Sistem Absensi Digital dengan QR Code & WhatsApp",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-slate-900 text-white`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
