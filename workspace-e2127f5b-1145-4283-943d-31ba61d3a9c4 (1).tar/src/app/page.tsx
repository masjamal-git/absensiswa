'use client';

import { useEffect, useState, useRef } from 'react';
import { useAppStore, Sekolah, User } from '@/lib/store';
import { io, Socket } from 'socket.io-client';

// UI Components
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';

// Icons
import { 
  Scan, Users, BarChart3, Settings, LogOut, Menu, Bell,
  CheckCircle, Clock, GraduationCap, Building2, Moon, Sun,
  RefreshCw, Database, MoreVertical, Download, ClipboardList,
  Calendar, UserCheck
} from 'lucide-react';

// Page components
import { LoginPage } from '@/components/pages/LoginPage';
import { DashboardPage } from '@/components/pages/DashboardPage';
import { ScannerPage } from '@/components/pages/ScannerPage';
import { KehadiranPage } from '@/components/pages/KehadiranPage';
import { SiswaPage } from '@/components/pages/SiswaPage';
import { TahunAjaranPage } from '@/components/pages/TahunAjaranPage';
import { LaporanPage } from '@/components/pages/LaporanPage';
import { SekolahPage } from '@/components/pages/SekolahPage';
import { PengaturanPage } from '@/components/pages/PengaturanPage';
import { PenggunaPage } from '@/components/pages/PenggunaPage';

// ============== SIDEBAR CONTENT ==============
interface SidebarContentProps {
  user: User | null;
  currentPage: string;
  setCurrentPage: (page: any) => void;
  logout: () => void;
}

function SidebarContentComponent({ user, currentPage, setCurrentPage, logout }: SidebarContentProps) {
  const { toast } = useToast();
  
  // Define all menu items with their required roles
  const allMenuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3, roles: ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'] },
    { id: 'scanner', label: 'Scanner QR', icon: Scan, roles: ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'] },
    { id: 'kehadiran', label: 'Catat Kehadiran', icon: ClipboardList, roles: ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'] },
    { id: 'siswa', label: 'Data Siswa', icon: Users, roles: ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'] },
    { id: 'sekolah', label: 'Data Sekolah', icon: Building2, roles: ['SUPER_ADMIN', 'ADMIN_SEKOLAH'] },
    { id: 'tahun-ajaran', label: 'Tahun Ajaran', icon: Calendar, roles: ['SUPER_ADMIN', 'ADMIN_SEKOLAH'] },
    { id: 'laporan', label: 'Laporan', icon: Download, roles: ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'] },
    { id: 'users', label: 'Manajemen User', icon: UserCheck, roles: ['SUPER_ADMIN'] },
    { id: 'pengaturan', label: 'Pengaturan', icon: Settings, roles: ['SUPER_ADMIN', 'ADMIN_SEKOLAH'] },
  ];
  
  // Filter menu items based on user role
  const menuItems = allMenuItems.filter(item => 
    user?.role && item.roles.includes(user.role)
  );
  
  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      logout();
      toast({
        title: 'Logout Berhasil',
        description: 'Anda telah keluar dari sistem',
      });
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal logout',
      });
    }
  };
  
  return (
    <div className="flex flex-col h-full">
      <div className="p-6 border-b border-slate-700/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
            <GraduationCap className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-white">Absensi QR</h1>
            <p className="text-xs text-slate-400">v1.0.0</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentPage(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              currentPage === item.id
                ? 'bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-400 border border-emerald-500/30'
                : 'text-slate-400 hover:bg-slate-700/50 hover:text-white'
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>
      
      <div className="p-4 border-t border-slate-700/50">
        <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-700/30">
          <Avatar className="w-10 h-10">
            <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
              {user?.nama?.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{user?.nama}</p>
            <p className="text-xs text-slate-400 truncate">{user?.email}</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLogout}
            className="text-slate-400 hover:text-red-400 hover:bg-red-500/10"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

// ============== SIDEBAR ==============
function Sidebar({ user, currentPage, setCurrentPage, logout, sidebarOpen, setSidebarOpen }: {
  user: User | null;
  currentPage: string;
  setCurrentPage: (page: any) => void;
  logout: () => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}) {
  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col fixed inset-y-0 left-0 z-50 bg-slate-800 border-r border-slate-700/50">
        <SidebarContentComponent 
          user={user} 
          currentPage={currentPage} 
          setCurrentPage={setCurrentPage} 
          logout={logout} 
        />
      </aside>
      
      {/* Mobile Sidebar */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="p-0 w-64 bg-slate-800 border-r border-slate-700/50">
          <SidebarContentComponent 
            user={user} 
            currentPage={currentPage} 
            setCurrentPage={(page) => { setCurrentPage(page); setSidebarOpen(false); }} 
            logout={logout} 
          />
        </SheetContent>
      </Sheet>
    </>
  );
}

// ============== HEADER ==============
function Header({ selectedSekolah, sekolahList, setSelectedSekolah, currentPage, setSidebarOpen }: {
  selectedSekolah: Sekolah | null;
  sekolahList: Sekolah[];
  setSelectedSekolah: (s: Sekolah | null) => void;
  currentPage: string;
  setSidebarOpen: (open: boolean) => void;
}) {
  const [darkMode, setDarkMode] = useState(true);
  
  const pageTitles: Record<string, string> = {
    dashboard: 'Dashboard',
    scanner: 'Scanner QR Code',
    kehadiran: 'Catat Kehadiran',
    siswa: 'Data Siswa',
    'tahun-ajaran': 'Tahun Ajaran',
    laporan: 'Laporan Absensi',
    users: 'Manajemen User',
    pengaturan: 'Pengaturan'
  };
  
  return (
    <header className="sticky top-0 z-40 bg-slate-800/80 backdrop-blur-lg border-b border-slate-700/50">
      <div className="flex items-center justify-between px-4 lg:px-6 h-16">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden text-slate-400 hover:text-white"
          >
            <Menu className="w-5 h-5" />
          </Button>
          
          <div>
            <h2 className="text-lg font-semibold text-white">{pageTitles[currentPage]}</h2>
            {selectedSekolah && (
              <p className="text-xs text-slate-400">{selectedSekolah.nama}</p>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          {/* Sekolah Selector */}
          {sekolahList.length > 0 && (
            <Select
              value={selectedSekolah?.id || ''}
              onValueChange={(value) => {
                const sekolah = sekolahList.find(s => s.id === value);
                setSelectedSekolah(sekolah || null);
              }}
            >
              <SelectTrigger className="w-48 bg-slate-700/50 border-slate-600 text-white">
                <Building2 className="w-4 h-4 mr-2 text-emerald-400" />
                <SelectValue placeholder="Pilih Sekolah" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                {sekolahList.map((s) => (
                  <SelectItem key={s.id} value={s.id} className="text-white hover:bg-slate-700">
                    {s.nama}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          
          {/* Dark Mode Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setDarkMode(!darkMode)}
            className="text-slate-400 hover:text-white"
          >
            {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>
          
          {/* Notifications */}
          <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </Button>
        </div>
      </div>
    </header>
  );
}

// ============== MAIN APP ==============
export default function App() {
  const { user, setUser, setLoading, isLoading, currentPage, setCurrentPage, 
          sekolahList, setSekolahList, setSelectedSekolah, selectedSekolah,
          sidebarOpen, setSidebarOpen, logout } = useAppStore();
  const { toast } = useToast();
  const socketRef = useRef<Socket | null>(null);
  const [dashboardRefreshKey, setDashboardRefreshKey] = useState(0);
  
  // Check auth on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const res = await fetch('/api/auth/me');
        const data = await res.json();
        
        if (data.success) {
          setUser(data.user);
        } else {
          setUser(null);
        }
      } catch {
        setUser(null);
      }
    };
    
    checkAuth();
  }, [setUser]);
  
  // Load sekolah list
  useEffect(() => {
    const loadSekolah = async () => {
      if (!user) return;
      
      try {
        const res = await fetch('/api/sekolah');
        const data = await res.json();
        
        if (data.success) {
          setSekolahList(data.data);
          
          if (data.data.length > 0 && !user.sekolahId) {
            setSelectedSekolah(data.data[0]);
          } else if (user.sekolahId) {
            const userSekolah = data.data.find((s: Sekolah) => s.id === user.sekolahId);
            if (userSekolah) {
              setSelectedSekolah(userSekolah);
            }
          }
        }
      } catch (error) {
        console.error('Failed to load sekolah:', error);
      }
    };
    
    loadSekolah();
  }, [user, setSekolahList, setSelectedSekolah]);
  
  // Socket.io connection + join sekolah room
  useEffect(() => {
    if (user && typeof window !== 'undefined') {
      socketRef.current = io('/?XTransformPort=3003', {
        transports: ['websocket']
      });
      
      socketRef.current.on('connect', () => {
        console.log('Connected to realtime service');
        // Join sekolah room when connected
        if (selectedSekolah) {
          socketRef.current!.emit('join-sekolah', selectedSekolah.id);
          console.log('Joined sekolah room:', selectedSekolah.id);
        }
      });
      
      socketRef.current.on('attendance-update', (data) => {
        const kelasNama = typeof data.kelas === 'object' ? data.kelas?.nama : data.kelas;
        toast({
          title: 'Absensi Baru',
          description: `${data.nama} (${kelasNama || '-'}) - ${data.status}`,
        });
        // Trigger dashboard refresh when attendance is recorded
        setDashboardRefreshKey(prev => prev + 1);
      });
      
      return () => {
        if (socketRef.current) {
          // Leave sekolah room before disconnect
          if (selectedSekolah) {
            socketRef.current.emit('leave-sekolah', selectedSekolah.id);
          }
          socketRef.current.disconnect();
        }
      };
    }
  }, [user, toast, selectedSekolah]);
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <RefreshCw className="w-8 h-8 animate-spin text-emerald-500" />
      </div>
    );
  }
  
  if (!user) {
    return <LoginPage />;
  }
  
  // Role-based access control
  const pageAccess: Record<string, string[]> = {
    'dashboard': ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'],
    'scanner': ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'],
    'kehadiran': ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'],
    'siswa': ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'],
    'sekolah': ['SUPER_ADMIN', 'ADMIN_SEKOLAH'],
    'tahun-ajaran': ['SUPER_ADMIN', 'ADMIN_SEKOLAH'],
    'laporan': ['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'OPERATOR'],
    'users': ['SUPER_ADMIN'],
    'pengaturan': ['SUPER_ADMIN', 'ADMIN_SEKOLAH'],
  };
  
  // Check if user has access to current page
  const hasAccess = (page: string) => {
    const allowedRoles = pageAccess[page] || [];
    return user?.role && allowedRoles.includes(user.role);
  };
  
  // Redirect to dashboard if no access
  const getAccessiblePage = (page: string) => {
    if (hasAccess(page)) return page;
    return 'dashboard';
  };
  
  const renderPage = () => {
    const accessiblePage = getAccessiblePage(currentPage);
    
    switch (accessiblePage) {
      case 'dashboard':
        return <DashboardPage selectedSekolah={selectedSekolah} refreshKey={dashboardRefreshKey} />;
      case 'scanner':
        return <ScannerPage selectedSekolah={selectedSekolah} />;
      case 'kehadiran':
        return <KehadiranPage selectedSekolah={selectedSekolah} />;
      case 'siswa':
        return <SiswaPage selectedSekolah={selectedSekolah} />;
      case 'sekolah':
        return <SekolahPage />;
      case 'tahun-ajaran':
        return <TahunAjaranPage selectedSekolah={selectedSekolah} />;
      case 'laporan':
        return <LaporanPage selectedSekolah={selectedSekolah} refreshKey={dashboardRefreshKey} />;
      case 'users':
        return <PenggunaPage />;
      case 'pengaturan':
        return <PengaturanPage selectedSekolah={selectedSekolah} setSelectedSekolah={setSelectedSekolah} />;
      default:
        return <DashboardPage selectedSekolah={selectedSekolah} refreshKey={dashboardRefreshKey} />;
    }
  };
  
  return (
    <div className="min-h-screen bg-slate-900">
      <Sidebar 
        user={user}
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        logout={logout}
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
      />
      <div className="lg:ml-64">
        <Header 
          selectedSekolah={selectedSekolah}
          sekolahList={sekolahList}
          setSelectedSekolah={setSelectedSekolah}
          currentPage={currentPage}
          setSidebarOpen={setSidebarOpen}
        />
        <main className="min-h-[calc(100vh-64px)]">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
