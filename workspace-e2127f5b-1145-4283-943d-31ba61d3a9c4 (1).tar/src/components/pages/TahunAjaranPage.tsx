'use client';

import { useState, useEffect } from 'react';
import { Sekolah } from '@/lib/store';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';

import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { 
  Plus, Edit, Trash2, RefreshCw, CheckCircle, Calendar, GraduationCap, BookOpen, AlertCircle
} from 'lucide-react';

// ============== TAHUN AJARAN PAGE ==============
interface TahunAjaranData {
  id: string;
  nama: string;
  tanggalMulai: Date | string;
  tanggalSelesai: Date | string;
  semester: number;
  isActive: boolean;
  isCurrent: boolean;
  sekolahId: string;
  createdAt: Date;
  updatedAt: Date;
  _count?: { kelas: number };
}

interface KelasData {
  id: string;
  nama: string;
  tingkatId: string;
  tingkat?: { id: string; nama: string; urutan: number } | null;
  waliKelas: string | null;
  tahunAjaranId: string | null;
  tahunAjaran?: { nama: string } | null;
  isActive: boolean;
  _count?: { siswa: number };
}

interface TingkatData {
  id: string;
  nama: string;
  urutan: number;
  keterangan: string | null;
  isActive: boolean;
  _count?: { kelas: number };
}

export function TahunAjaranPage({ selectedSekolah }: { selectedSekolah: Sekolah | null }) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('tahun-ajaran');
  
  // ========== Tahun Ajaran State ==========
  const [tahunAjaranList, setTahunAjaranList] = useState<TahunAjaranData[]>([]);
  const [isLoadingTA, setIsLoadingTA] = useState(false);
  const [showTADialog, setShowTADialog] = useState(false);
  const [showTADeleteDialog, setShowTADeleteDialog] = useState(false);
  const [isSubmittingTA, setIsSubmittingTA] = useState(false);
  const [taFormMode, setTAFormMode] = useState<'add' | 'edit'>('add');
  const [selectedTA, setSelectedTA] = useState<TahunAjaranData | null>(null);
  
  const [taFormData, setTAFormData] = useState({
    nama: '',
    tanggalMulai: '',
    tanggalSelesai: '',
    semester: 1 as 1 | 2,
    isActive: true,
    isCurrent: false
  });
  
  // ========== Kelas State ==========
  const [kelasList, setKelasList] = useState<KelasData[]>([]);
  const [isLoadingKelas, setIsLoadingKelas] = useState(false);
  const [showKelasDialog, setShowKelasDialog] = useState(false);
  const [showKelasDeleteDialog, setShowKelasDeleteDialog] = useState(false);
  const [isSubmittingKelas, setIsSubmittingKelas] = useState(false);
  const [kelasFormMode, setKelasFormMode] = useState<'add' | 'edit'>('add');
  const [selectedKelas, setSelectedKelas] = useState<KelasData | null>(null);
  const [filterTahunAjaran, setFilterTahunAjaran] = useState<string>('');
  
  const [kelasFormData, setKelasFormData] = useState({
    nama: '',
    tingkatId: '',
    waliKelas: '',
    tahunAjaranId: '',
    isActive: true
  });
  
  // ========== Tingkat State ==========
  const [tingkatList, setTingkatList] = useState<TingkatData[]>([]);
  const [isLoadingTingkat, setIsLoadingTingkat] = useState(false);
  const [showTingkatDialog, setShowTingkatDialog] = useState(false);
  const [showTingkatDeleteDialog, setShowTingkatDeleteDialog] = useState(false);
  const [isSubmittingTingkat, setIsSubmittingTingkat] = useState(false);
  const [tingkatFormMode, setTingkatFormMode] = useState<'add' | 'edit'>('add');
  const [selectedTingkat, setSelectedTingkat] = useState<TingkatData | null>(null);
  
  const [tingkatFormData, setTingkatFormData] = useState({
    nama: '',
    urutan: 1,
    keterangan: '',
    isActive: true
  });
  
  // ========== Effects ==========
  useEffect(() => {
    if (selectedSekolah) {
      fetchTahunAjaran();
      fetchKelas();
      fetchTingkat();
    }
  }, [selectedSekolah]);
  
  useEffect(() => {
    if (selectedSekolah) {
      fetchKelas();
    }
  }, [filterTahunAjaran]);
  
  // ========== Tahun Ajaran Functions ==========
  const fetchTahunAjaran = async () => {
    if (!selectedSekolah) return;
    
    setIsLoadingTA(true);
    try {
      const res = await fetch(`/api/tahun-ajaran?sekolahId=${selectedSekolah.id}`);
      const data = await res.json();
      
      if (data.success) {
        setTahunAjaranList(data.data);
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal memuat data tahun ajaran',
      });
    } finally {
      setIsLoadingTA(false);
    }
  };
  
  const openAddTAForm = () => {
    setTAFormMode('add');
    setTAFormData({
      nama: '',
      tanggalMulai: '',
      tanggalSelesai: '',
      semester: 1,
      isActive: true,
      isCurrent: false
    });
    setShowTADialog(true);
  };
  
  const openEditTAForm = (ta: TahunAjaranData) => {
    setTAFormMode('edit');
    setSelectedTA(ta);
    setTAFormData({
      nama: ta.nama,
      tanggalMulai: format(new Date(ta.tanggalMulai), 'yyyy-MM-dd'),
      tanggalSelesai: format(new Date(ta.tanggalSelesai), 'yyyy-MM-dd'),
      semester: ta.semester as 1 | 2,
      isActive: ta.isActive,
      isCurrent: ta.isCurrent
    });
    setShowTADialog(true);
  };
  
  const handleTASubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedSekolah) return;
    
    setIsSubmittingTA(true);
    
    try {
      if (taFormMode === 'add') {
        const res = await fetch('/api/tahun-ajaran', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...taFormData,
            sekolahId: selectedSekolah.id
          })
        });
        
        const data = await res.json();
        
        if (data.success) {
          toast({ title: 'Berhasil', description: 'Tahun ajaran berhasil ditambahkan' });
          setShowTADialog(false);
          fetchTahunAjaran();
        } else {
          toast({ variant: 'destructive', title: 'Gagal', description: data.message || 'Terjadi kesalahan' });
        }
      } else {
        const res = await fetch(`/api/tahun-ajaran/${selectedTA?.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(taFormData)
        });
        
        const data = await res.json();
        
        if (data.success) {
          toast({ title: 'Berhasil', description: 'Tahun ajaran berhasil diperbarui' });
          setShowTADialog(false);
          fetchTahunAjaran();
        } else {
          toast({ variant: 'destructive', title: 'Gagal', description: data.message || 'Terjadi kesalahan' });
        }
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Terjadi kesalahan' });
    } finally {
      setIsSubmittingTA(false);
    }
  };
  
  const handleTADelete = async () => {
    if (!selectedTA) return;
    
    setIsSubmittingTA(true);
    
    try {
      const res = await fetch(`/api/tahun-ajaran/${selectedTA.id}`, { method: 'DELETE' });
      const data = await res.json();
      
      if (data.success) {
        toast({ title: 'Berhasil', description: 'Tahun ajaran berhasil dihapus' });
        setShowTADeleteDialog(false);
        fetchTahunAjaran();
      } else {
        toast({ variant: 'destructive', title: 'Gagal', description: data.message || 'Terjadi kesalahan' });
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Terjadi kesalahan' });
    } finally {
      setIsSubmittingTA(false);
    }
  };
  
  const setAsCurrent = async (ta: TahunAjaranData) => {
    try {
      const res = await fetch(`/api/tahun-ajaran/${ta.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isCurrent: true, isActive: true })
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({ title: 'Berhasil', description: `${ta.nama} ditetapkan sebagai tahun ajaran aktif` });
        fetchTahunAjaran();
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Gagal mengubah tahun ajaran aktif' });
    }
  };
  
  // ========== Kelas Functions ==========
  const fetchKelas = async () => {
    if (!selectedSekolah) return;
    
    setIsLoadingKelas(true);
    try {
      let url = `/api/kelas?sekolahId=${selectedSekolah.id}`;
      if (filterTahunAjaran) {
        url += `&tahunAjaranId=${filterTahunAjaran}`;
      }
      
      const res = await fetch(url);
      const data = await res.json();
      
      if (data.success) {
        setKelasList(data.data);
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Gagal memuat data kelas' });
    } finally {
      setIsLoadingKelas(false);
    }
  };
  
  const openAddKelasForm = () => {
    setKelasFormMode('add');
    setKelasFormData({
      nama: '',
      tingkatId: tingkatList[0]?.id || '',
      waliKelas: '',
      tahunAjaranId: filterTahunAjaran || '',
      isActive: true
    });
    setShowKelasDialog(true);
  };
  
  const openEditKelasForm = (k: KelasData) => {
    setKelasFormMode('edit');
    setSelectedKelas(k);
    setKelasFormData({
      nama: k.nama,
      tingkatId: k.tingkatId || '',
      waliKelas: k.waliKelas || '',
      tahunAjaranId: k.tahunAjaranId || '',
      isActive: k.isActive
    });
    setShowKelasDialog(true);
  };
  
  const handleKelasSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedSekolah) return;
    
    setIsSubmittingKelas(true);
    
    try {
      if (kelasFormMode === 'add') {
        const res = await fetch('/api/kelas', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...kelasFormData,
            sekolahId: selectedSekolah.id
          })
        });
        
        const data = await res.json();
        
        if (data.success) {
          toast({ title: 'Berhasil', description: 'Kelas berhasil ditambahkan' });
          setShowKelasDialog(false);
          fetchKelas();
        } else {
          toast({ variant: 'destructive', title: 'Gagal', description: data.message || 'Terjadi kesalahan' });
        }
      } else {
        const res = await fetch(`/api/kelas/${selectedKelas?.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(kelasFormData)
        });
        
        const data = await res.json();
        
        if (data.success) {
          toast({ title: 'Berhasil', description: 'Kelas berhasil diperbarui' });
          setShowKelasDialog(false);
          fetchKelas();
        } else {
          toast({ variant: 'destructive', title: 'Gagal', description: data.message || 'Terjadi kesalahan' });
        }
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Terjadi kesalahan' });
    } finally {
      setIsSubmittingKelas(false);
    }
  };
  
  const handleKelasDelete = async () => {
    if (!selectedKelas) return;
    
    setIsSubmittingKelas(true);
    
    try {
      const res = await fetch(`/api/kelas/${selectedKelas.id}`, { method: 'DELETE' });
      const data = await res.json();
      
      if (data.success) {
        toast({ title: 'Berhasil', description: 'Kelas berhasil dihapus' });
        setShowKelasDeleteDialog(false);
        fetchKelas();
      } else {
        toast({ variant: 'destructive', title: 'Gagal', description: data.message || 'Terjadi kesalahan' });
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Terjadi kesalahan' });
    } finally {
      setIsSubmittingKelas(false);
    }
  };
  
  // ========== Tingkat Functions ==========
  const fetchTingkat = async () => {
    if (!selectedSekolah) return;
    
    setIsLoadingTingkat(true);
    try {
      const res = await fetch(`/api/tingkat?sekolahId=${selectedSekolah.id}`);
      const data = await res.json();
      
      if (data.success) {
        setTingkatList(data.data);
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Gagal memuat data tingkat' });
    } finally {
      setIsLoadingTingkat(false);
    }
  };
  
  const openAddTingkatForm = () => {
    setTingkatFormMode('add');
    setTingkatFormData({
      nama: '',
      urutan: tingkatList.length + 1,
      keterangan: '',
      isActive: true
    });
    setShowTingkatDialog(true);
  };
  
  const openEditTingkatForm = (t: TingkatData) => {
    setTingkatFormMode('edit');
    setSelectedTingkat(t);
    setTingkatFormData({
      nama: t.nama,
      urutan: t.urutan,
      keterangan: t.keterangan || '',
      isActive: t.isActive
    });
    setShowTingkatDialog(true);
  };
  
  const handleTingkatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedSekolah) return;
    
    setIsSubmittingTingkat(true);
    
    try {
      if (tingkatFormMode === 'add') {
        const res = await fetch('/api/tingkat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...tingkatFormData,
            sekolahId: selectedSekolah.id
          })
        });
        
        const data = await res.json();
        
        if (data.success) {
          toast({ title: 'Berhasil', description: 'Tingkat berhasil ditambahkan' });
          setShowTingkatDialog(false);
          fetchTingkat();
        } else {
          toast({ variant: 'destructive', title: 'Gagal', description: data.message || 'Terjadi kesalahan' });
        }
      } else {
        const res = await fetch(`/api/tingkat/${selectedTingkat?.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(tingkatFormData)
        });
        
        const data = await res.json();
        
        if (data.success) {
          toast({ title: 'Berhasil', description: 'Tingkat berhasil diperbarui' });
          setShowTingkatDialog(false);
          fetchTingkat();
        } else {
          toast({ variant: 'destructive', title: 'Gagal', description: data.message || 'Terjadi kesalahan' });
        }
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Terjadi kesalahan' });
    } finally {
      setIsSubmittingTingkat(false);
    }
  };
  
  const handleTingkatDelete = async () => {
    if (!selectedTingkat) return;
    
    setIsSubmittingTingkat(true);
    
    try {
      const res = await fetch(`/api/tingkat/${selectedTingkat.id}`, { method: 'DELETE' });
      const data = await res.json();
      
      if (data.success) {
        toast({ title: 'Berhasil', description: 'Tingkat berhasil dihapus' });
        setShowTingkatDeleteDialog(false);
        fetchTingkat();
      } else {
        toast({ variant: 'destructive', title: 'Gagal', description: data.message || 'Terjadi kesalahan' });
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Terjadi kesalahan' });
    } finally {
      setIsSubmittingTingkat(false);
    }
  };
  
  if (!selectedSekolah) {
    return (
      <div className="flex items-center justify-center h-64">
        <AlertCircle className="w-8 h-8 text-amber-500 mr-3" />
        <p className="text-slate-400">Pilih sekolah terlebih dahulu</p>
      </div>
    );
  }
  
  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Pengaturan Akademik</h2>
          <p className="text-slate-400">{selectedSekolah.nama}</p>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-slate-800 border border-slate-700">
          <TabsTrigger value="tahun-ajaran" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
            <Calendar className="w-4 h-4 mr-2" />
            Tahun Ajaran
          </TabsTrigger>
          <TabsTrigger value="tingkat" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
            <GraduationCap className="w-4 h-4 mr-2" />
            Tingkat
          </TabsTrigger>
          <TabsTrigger value="kelas" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
            <BookOpen className="w-4 h-4 mr-2" />
            Kelas
          </TabsTrigger>
        </TabsList>
        
        {/* Tab Tahun Ajaran */}
        <TabsContent value="tahun-ajaran" className="space-y-4 mt-4">
          <div className="flex justify-end">
            <Button
              onClick={openAddTAForm}
              className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Tambah Tahun Ajaran
            </Button>
          </div>
          
          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
            <CardContent className="p-0">
              {isLoadingTA ? (
                <div className="p-6 space-y-4">
                  {[1, 2, 3].map((i) => (<Skeleton key={i} className="h-16 rounded-xl" />))}
                </div>
              ) : (
                <ScrollArea className="h-[calc(100vh-350px)]">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-slate-700 hover:bg-slate-700/30">
                        <TableHead className="text-slate-400">Nama</TableHead>
                        <TableHead className="text-slate-400">Semester</TableHead>
                        <TableHead className="text-slate-400">Tanggal Mulai</TableHead>
                        <TableHead className="text-slate-400">Tanggal Selesai</TableHead>
                        <TableHead className="text-slate-400">Status</TableHead>
                        <TableHead className="text-slate-400">Kelas</TableHead>
                        <TableHead className="text-slate-400 text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {tahunAjaranList.map((ta) => (
                        <TableRow key={ta.id} className="border-slate-700 hover:bg-slate-700/30">
                          <TableCell className="font-medium text-white">
                            <div className="flex items-center gap-2">
                              {ta.nama}
                              {ta.isCurrent && (
                                <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Aktif</Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-slate-300">{ta.semester === 1 ? 'Ganjil' : 'Genap'}</TableCell>
                          <TableCell className="text-slate-300">{format(new Date(ta.tanggalMulai), 'dd MMM yyyy', { locale: id })}</TableCell>
                          <TableCell className="text-slate-300">{format(new Date(ta.tanggalSelesai), 'dd MMM yyyy', { locale: id })}</TableCell>
                          <TableCell>
                            <Badge className={ta.isActive ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' : 'bg-slate-500/20 text-slate-400 border-slate-500/30'}>
                              {ta.isActive ? 'Aktif' : 'Nonaktif'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-slate-300">{ta._count?.kelas || 0} kelas</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              {!ta.isCurrent && (
                                <Button size="sm" variant="outline" onClick={() => setAsCurrent(ta)} className="bg-slate-700/50 border-slate-600 text-white hover:bg-emerald-500/20 hover:text-emerald-400" title="Tetapkan sebagai aktif">
                                  <CheckCircle className="w-4 h-4" />
                                </Button>
                              )}
                              <Button size="sm" variant="outline" onClick={() => openEditTAForm(ta)} className="bg-slate-700/50 border-slate-600 text-white hover:bg-blue-500/20 hover:text-blue-400" title="Edit">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => { setSelectedTA(ta); setShowTADeleteDialog(true); }} className="bg-slate-700/50 border-slate-600 text-white hover:bg-red-500/20 hover:text-red-400" title="Hapus">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                      {tahunAjaranList.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center text-slate-400 py-8">Belum ada data tahun ajaran</TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Tab Tingkat */}
        <TabsContent value="tingkat" className="space-y-4 mt-4">
          <div className="flex justify-end">
            <Button
              onClick={openAddTingkatForm}
              className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Tambah Tingkat
            </Button>
          </div>
          
          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
            <CardContent className="p-0">
              {isLoadingTingkat ? (
                <div className="p-6 space-y-4">
                  {[1, 2, 3].map((i) => (<Skeleton key={i} className="h-16 rounded-xl" />))}
                </div>
              ) : (
                <ScrollArea className="h-[calc(100vh-350px)]">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-slate-700 hover:bg-slate-700/30">
                        <TableHead className="text-slate-400">Nama</TableHead>
                        <TableHead className="text-slate-400">Urutan</TableHead>
                        <TableHead className="text-slate-400">Keterangan</TableHead>
                        <TableHead className="text-slate-400">Kelas</TableHead>
                        <TableHead className="text-slate-400">Status</TableHead>
                        <TableHead className="text-slate-400 text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {tingkatList.map((t) => (
                        <TableRow key={t.id} className="border-slate-700 hover:bg-slate-700/30">
                          <TableCell className="font-medium text-white">{t.nama}</TableCell>
                          <TableCell className="text-slate-300">{t.urutan}</TableCell>
                          <TableCell className="text-slate-300">{t.keterangan || '-'}</TableCell>
                          <TableCell className="text-slate-300">{t._count?.kelas || 0} kelas</TableCell>
                          <TableCell>
                            <Badge className={t.isActive ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' : 'bg-slate-500/20 text-slate-400 border-slate-500/30'}>
                              {t.isActive ? 'Aktif' : 'Nonaktif'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="outline" onClick={() => openEditTingkatForm(t)} className="bg-slate-700/50 border-slate-600 text-white hover:bg-blue-500/20 hover:text-blue-400" title="Edit">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => { setSelectedTingkat(t); setShowTingkatDeleteDialog(true); }} className="bg-slate-700/50 border-slate-600 text-white hover:bg-red-500/20 hover:text-red-400" title="Hapus">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                      {tingkatList.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-slate-400 py-8">Belum ada data tingkat</TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Tab Kelas */}
        <TabsContent value="kelas" className="space-y-4 mt-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <Select value={filterTahunAjaran || 'all'} onValueChange={(v) => setFilterTahunAjaran(v === 'all' ? '' : v)}>
              <SelectTrigger className="w-64 bg-slate-700/50 border-slate-600 text-white">
                <SelectValue placeholder="Filter Tahun Ajaran" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="all" className="text-white">Semua Tahun Ajaran</SelectItem>
                {tahunAjaranList.map((ta) => (
                  <SelectItem key={ta.id} value={ta.id} className="text-white">{ta.nama}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button onClick={openAddKelasForm} className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700">
              <Plus className="w-4 h-4 mr-2" />
              Tambah Kelas
            </Button>
          </div>
          
          <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
            <CardContent className="p-0">
              {isLoadingKelas ? (
                <div className="p-6 space-y-4">
                  {[1, 2, 3].map((i) => (<Skeleton key={i} className="h-16 rounded-xl" />))}
                </div>
              ) : (
                <ScrollArea className="h-[calc(100vh-350px)]">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-slate-700 hover:bg-slate-700/30">
                        <TableHead className="text-slate-400">Nama Kelas</TableHead>
                        <TableHead className="text-slate-400">Tingkat</TableHead>
                        <TableHead className="text-slate-400">Wali Kelas</TableHead>
                        <TableHead className="text-slate-400">Tahun Ajaran</TableHead>
                        <TableHead className="text-slate-400">Siswa</TableHead>
                        <TableHead className="text-slate-400">Status</TableHead>
                        <TableHead className="text-slate-400 text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {kelasList.map((k) => (
                        <TableRow key={k.id} className="border-slate-700 hover:bg-slate-700/30">
                          <TableCell className="font-medium text-white">{k.nama}</TableCell>
                          <TableCell className="text-slate-300">{k.tingkat?.nama || '-'}</TableCell>
                          <TableCell className="text-slate-300">{k.waliKelas || '-'}</TableCell>
                          <TableCell className="text-slate-300">{k.tahunAjaran?.nama || '-'}</TableCell>
                          <TableCell className="text-slate-300">{k._count?.siswa || 0} siswa</TableCell>
                          <TableCell>
                            <Badge className={k.isActive ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' : 'bg-slate-500/20 text-slate-400 border-slate-500/30'}>
                              {k.isActive ? 'Aktif' : 'Nonaktif'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="outline" onClick={() => openEditKelasForm(k)} className="bg-slate-700/50 border-slate-600 text-white hover:bg-blue-500/20 hover:text-blue-400" title="Edit">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => { setSelectedKelas(k); setShowKelasDeleteDialog(true); }} className="bg-slate-700/50 border-slate-600 text-white hover:bg-red-500/20 hover:text-red-400" title="Hapus">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                      {kelasList.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center text-slate-400 py-8">Belum ada data kelas</TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Dialog Tahun Ajaran */}
      <Dialog open={showTADialog} onOpenChange={setShowTADialog}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>{taFormMode === 'add' ? 'Tambah Tahun Ajaran' : 'Edit Tahun Ajaran'}</DialogTitle>
            <DialogDescription className="text-slate-400">{taFormMode === 'add' ? 'Isi data tahun ajaran baru' : 'Perbarui data tahun ajaran'}</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleTASubmit} className="space-y-4">
            <div className="space-y-1">
              <Label className="text-slate-300">Nama Tahun Ajaran *</Label>
              <Input value={taFormData.nama} onChange={(e) => setTAFormData({...taFormData, nama: e.target.value})} placeholder="Contoh: 2024/2025" className="bg-slate-700/50 border-slate-600 text-white" required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-slate-300">Tanggal Mulai *</Label>
                <Input type="date" value={taFormData.tanggalMulai} onChange={(e) => setTAFormData({...taFormData, tanggalMulai: e.target.value})} className="bg-slate-700/50 border-slate-600 text-white" required />
              </div>
              <div className="space-y-1">
                <Label className="text-slate-300">Tanggal Selesai *</Label>
                <Input type="date" value={taFormData.tanggalSelesai} onChange={(e) => setTAFormData({...taFormData, tanggalSelesai: e.target.value})} className="bg-slate-700/50 border-slate-600 text-white" required />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-slate-300">Semester</Label>
              <Select value={taFormData.semester.toString()} onValueChange={(v) => setTAFormData({...taFormData, semester: parseInt(v) as 1 | 2})}>
                <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="1" className="text-white">Ganjil</SelectItem>
                  <SelectItem value="2" className="text-white">Genap</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Checkbox id="taIsActive" checked={taFormData.isActive} onCheckedChange={(checked) => setTAFormData({...taFormData, isActive: checked as boolean})} />
                <Label htmlFor="taIsActive" className="text-slate-300 text-sm">Aktif</Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox id="taIsCurrent" checked={taFormData.isCurrent} onCheckedChange={(checked) => setTAFormData({...taFormData, isCurrent: checked as boolean})} />
                <Label htmlFor="taIsCurrent" className="text-slate-300 text-sm">Tahun Ajaran Berjalan</Label>
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setShowTADialog(false)} className="bg-slate-700/50 border-slate-600 text-white">Batal</Button>
              <Button type="submit" disabled={isSubmittingTA} className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700">
                {isSubmittingTA ? (<><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Menyimpan...</>) : 'Simpan'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Tahun Ajaran Dialog */}
      <Dialog open={showTADeleteDialog} onOpenChange={setShowTADeleteDialog}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-red-400">Hapus Tahun Ajaran</DialogTitle>
            <DialogDescription className="text-slate-400">Apakah Anda yakin ingin menghapus tahun ajaran <strong className="text-white">{selectedTA?.nama}</strong>? Tindakan ini tidak dapat dibatalkan.</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => setShowTADeleteDialog(false)} className="bg-slate-700/50 border-slate-600 text-white">Batal</Button>
            <Button onClick={handleTADelete} disabled={isSubmittingTA} className="bg-red-500 hover:bg-red-600">
              {isSubmittingTA ? (<><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Menghapus...</>) : (<><Trash2 className="w-4 h-4 mr-2" />Hapus</>)}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Dialog Kelas */}
      <Dialog open={showKelasDialog} onOpenChange={setShowKelasDialog}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>{kelasFormMode === 'add' ? 'Tambah Kelas' : 'Edit Kelas'}</DialogTitle>
            <DialogDescription className="text-slate-400">{kelasFormMode === 'add' ? 'Isi data kelas baru' : 'Perbarui data kelas'}</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleKelasSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-slate-300">Nama Kelas *</Label>
                <Input value={kelasFormData.nama} onChange={(e) => setKelasFormData({...kelasFormData, nama: e.target.value})} placeholder="Contoh: 1A" className="bg-slate-700/50 border-slate-600 text-white" required />
              </div>
              <div className="space-y-1">
                <Label className="text-slate-300">Tingkat *</Label>
                <Select value={kelasFormData.tingkatId} onValueChange={(v) => setKelasFormData({...kelasFormData, tingkatId: v})}>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white"><SelectValue placeholder="Pilih Tingkat" /></SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {tingkatList.map((t) => (<SelectItem key={t.id} value={t.id} className="text-white">{t.nama}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-slate-300">Wali Kelas</Label>
              <Input value={kelasFormData.waliKelas} onChange={(e) => setKelasFormData({...kelasFormData, waliKelas: e.target.value})} placeholder="Nama wali kelas" className="bg-slate-700/50 border-slate-600 text-white" />
            </div>
            <div className="space-y-1">
              <Label className="text-slate-300">Tahun Ajaran</Label>
              <Select value={kelasFormData.tahunAjaranId || 'none'} onValueChange={(v) => setKelasFormData({...kelasFormData, tahunAjaranId: v === 'none' ? '' : v})}>
                <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white"><SelectValue placeholder="Pilih Tahun Ajaran" /></SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="none" className="text-white">Tidak ada</SelectItem>
                  {tahunAjaranList.map((ta) => (<SelectItem key={ta.id} value={ta.id} className="text-white">{ta.nama}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox id="kelasIsActive" checked={kelasFormData.isActive} onCheckedChange={(checked) => setKelasFormData({...kelasFormData, isActive: checked as boolean})} />
              <Label htmlFor="kelasIsActive" className="text-slate-300 text-sm">Aktif</Label>
            </div>
            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setShowKelasDialog(false)} className="bg-slate-700/50 border-slate-600 text-white">Batal</Button>
              <Button type="submit" disabled={isSubmittingKelas} className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700">
                {isSubmittingKelas ? (<><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Menyimpan...</>) : 'Simpan'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Kelas Dialog */}
      <Dialog open={showKelasDeleteDialog} onOpenChange={setShowKelasDeleteDialog}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-red-400">Hapus Kelas</DialogTitle>
            <DialogDescription className="text-slate-400">Apakah Anda yakin ingin menghapus kelas <strong className="text-white">{selectedKelas?.nama}</strong>? Tindakan ini tidak dapat dibatalkan.</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => setShowKelasDeleteDialog(false)} className="bg-slate-700/50 border-slate-600 text-white">Batal</Button>
            <Button onClick={handleKelasDelete} disabled={isSubmittingKelas} className="bg-red-500 hover:bg-red-600">
              {isSubmittingKelas ? (<><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Menghapus...</>) : (<><Trash2 className="w-4 h-4 mr-2" />Hapus</>)}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Dialog Tingkat */}
      <Dialog open={showTingkatDialog} onOpenChange={setShowTingkatDialog}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>{tingkatFormMode === 'add' ? 'Tambah Tingkat' : 'Edit Tingkat'}</DialogTitle>
            <DialogDescription className="text-slate-400">{tingkatFormMode === 'add' ? 'Isi data tingkat baru' : 'Perbarui data tingkat'}</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleTingkatSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-slate-300">Nama Tingkat *</Label>
                <Input value={tingkatFormData.nama} onChange={(e) => setTingkatFormData({...tingkatFormData, nama: e.target.value})} placeholder="Contoh: 1 atau X" className="bg-slate-700/50 border-slate-600 text-white" required />
              </div>
              <div className="space-y-1">
                <Label className="text-slate-300">Urutan *</Label>
                <Input type="number" value={tingkatFormData.urutan} onChange={(e) => setTingkatFormData({...tingkatFormData, urutan: parseInt(e.target.value) || 1})} className="bg-slate-700/50 border-slate-600 text-white" required />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-slate-300">Keterangan</Label>
              <Input value={tingkatFormData.keterangan} onChange={(e) => setTingkatFormData({...tingkatFormData, keterangan: e.target.value})} placeholder="Contoh: Kelas 1 SD" className="bg-slate-700/50 border-slate-600 text-white" />
            </div>
            <div className="flex items-center gap-2">
              <Checkbox id="tingkatIsActive" checked={tingkatFormData.isActive} onCheckedChange={(checked) => setTingkatFormData({...tingkatFormData, isActive: checked as boolean})} />
              <Label htmlFor="tingkatIsActive" className="text-slate-300 text-sm">Aktif</Label>
            </div>
            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setShowTingkatDialog(false)} className="bg-slate-700/50 border-slate-600 text-white">Batal</Button>
              <Button type="submit" disabled={isSubmittingTingkat} className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700">
                {isSubmittingTingkat ? (<><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Menyimpan...</>) : 'Simpan'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Tingkat Dialog */}
      <Dialog open={showTingkatDeleteDialog} onOpenChange={setShowTingkatDeleteDialog}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-red-400">Hapus Tingkat</DialogTitle>
            <DialogDescription className="text-slate-400">Apakah Anda yakin ingin menghapus tingkat <strong className="text-white">{selectedTingkat?.nama}</strong>? Tindakan ini tidak dapat dibatalkan.</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => setShowTingkatDeleteDialog(false)} className="bg-slate-700/50 border-slate-600 text-white">Batal</Button>
            <Button onClick={handleTingkatDelete} disabled={isSubmittingTingkat} className="bg-red-500 hover:bg-red-600">
              {isSubmittingTingkat ? (<><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Menghapus...</>) : (<><Trash2 className="w-4 h-4 mr-2" />Hapus</>)}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
