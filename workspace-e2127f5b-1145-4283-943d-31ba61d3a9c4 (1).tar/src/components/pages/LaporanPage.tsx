'use client';

import { useState, useEffect } from 'react';
import { Sekolah, Kelas } from '@/lib/store';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { 
  Download, Printer, BarChart3, Calendar, List, RefreshCw, AlertCircle
} from 'lucide-react';

// ============== LAPORAN PAGE ==============
export function LaporanPage({ selectedSekolah, refreshKey }: { selectedSekolah: Sekolah | null; refreshKey?: number }) {
  const { toast } = useToast();
  const [absensiList, setAbsensiList] = useState<any[]>([]);
  const [rekapList, setRekapList] = useState<any[]>([]);
  const [kelasRekap, setKelasRekap] = useState<any[]>([]);
  const [kelasList, setKelasList] = useState<Kelas[]>([]);
  const [tahunAjaranList, setTahunAjaranList] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Filter states
  const [tipeLaporan, setTipeLaporan] = useState<'detail' | 'rekap'>('detail');
  const [periode, setPeriode] = useState<'harian' | 'bulanan' | 'semester'>('bulanan');
  const [tanggalHarian, setTanggalHarian] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [bulan, setBulan] = useState(format(new Date(), 'yyyy-MM'));
  const [selectedSemester, setSelectedSemester] = useState<string>('');
  const [selectedKelas, setSelectedKelas] = useState<string>('');
  const [status, setStatus] = useState<string>('');

  // Computed date range
  const getDateRange = (): { dari: string; sampai: string; label: string } => {
    if (periode === 'harian') {
      return { dari: tanggalHarian, sampai: tanggalHarian, label: format(new Date(tanggalHarian), 'dd MMMM yyyy', { locale: id }) };
    }
    if (periode === 'semester' && selectedSemester) {
      const ta = tahunAjaranList.find(t => t.id === selectedSemester);
      if (ta) {
        return {
          dari: format(new Date(ta.tanggalMulai), 'yyyy-MM-dd'),
          sampai: format(new Date(ta.tanggalSelesai), 'yyyy-MM-dd'),
          label: `${ta.nama} - Semester ${ta.semester}`
        };
      }
    }
    // Bulanan (default)
    const [y, m] = bulan.split('-').map(Number);
    const firstDay = new Date(y, m - 1, 1);
    const lastDay = new Date(y, m, 0);
    return {
      dari: format(firstDay, 'yyyy-MM-dd'),
      sampai: format(lastDay, 'yyyy-MM-dd'),
      label: format(firstDay, 'MMMM yyyy', { locale: id })
    };
  };

  // Fetch kelas & tahun ajaran when sekolah changes
  useEffect(() => {
    if (!selectedSekolah) return;
    Promise.all([
      fetch(`/api/kelas?sekolahId=${selectedSekolah.id}`).then(r => r.json()),
      fetch(`/api/tahun-ajaran?sekolahId=${selectedSekolah.id}`).then(r => r.json()),
    ]).then(([kelasData, taData]) => {
      if (kelasData.success) setKelasList(kelasData.data);
      if (taData.success) {
        setTahunAjaranList(taData.data);
        const current = taData.data.find((t: any) => t.isCurrent);
        if (current) setSelectedSemester(current.id);
      }
    }).catch(() => {});
  }, [selectedSekolah]);

  // Fetch data when filters change
  useEffect(() => {
    if (!selectedSekolah) return;
    const { dari, sampai } = getDateRange();
    fetchData(dari, sampai);
  }, [selectedSekolah, tipeLaporan, periode, tanggalHarian, bulan, selectedSemester, selectedKelas, status, refreshKey]);

  const fetchData = async (dari: string, sampai: string) => {
    setIsLoading(true);
    try {
      // Use tanggalDari/tanggalSampai for date range query; single tanggal for harian
      const isRange = dari !== sampai;
      let url = `/api/absensi?sekolahId=${selectedSekolah.id}&limit=5000`;
      if (isRange) {
        url += `&tanggalDari=${dari}&tanggalSampai=${sampai}`;
      } else {
        url += `&tanggal=${dari}`;
      }
      if (selectedKelas) url += `&kelasId=${selectedKelas}`;
      if (status) url += `&status=${status}`;

      const res = await fetch(url);
      const data = await res.json();

      if (data.success) {
        setAbsensiList(data.data);
        // Build rekap summary
        buildRekapSummary(data.data);
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Gagal memuat data' });
    } finally {
      setIsLoading(false);
    }
  };

  const buildRekapSummary = (data: any[]) => {
    const { dari, sampai } = getDateRange();
    const dariDate = new Date(dari + 'T00:00:00');
    const sampaiDate = new Date(sampai + 'T23:59:59');
    const totalHari = countSchoolDays(dariDate, sampaiDate);

    // Group by siswa
    const siswaMap: Record<string, any> = {};
    data.forEach((a: any) => {
      if (!siswaMap[a.siswaId]) {
        siswaMap[a.siswaId] = {
          siswaId: a.siswaId,
          nis: a.siswa?.nis || '-',
          nama: a.siswa?.nama || '-',
          kelas: a.siswa?.kelas?.nama || '-',
          hadir: 0, terlambat: 0, sakit: 0, izin: 0, alpa: 0,
        };
      }
      const s = siswaMap[a.siswaId];
      if (s[a.status?.toLowerCase()] !== undefined) {
        s[a.status?.toLowerCase()]++;
      }
    });

    const rekap = Object.values(siswaMap).map((s: any, i: number) => {
      const totalRecorded = s.hadir + s.terlambat + s.sakit + s.izin + s.alpa;
      const belumAbsen = Math.max(0, totalHari - totalRecorded);
      const persentase = totalHari > 0 ? Math.round(((s.hadir + s.terlambat) / totalHari) * 100) : 0;
      return { ...s, no: i + 1, belumAbsen, totalHari, persentase };
    });
    rekap.sort((a: any, b: any) => a.kelas.localeCompare(b.kelas) || a.nama.localeCompare(b.nama));
    setRekapList(rekap);

    // Per-kelas summary
    const kelasMap: Record<string, any> = {};
    rekap.forEach((s: any) => {
      if (!kelasMap[s.kelas]) kelasMap[s.kelas] = { kelas: s.kelas, jumlahSiswa: 0, hadir: 0, terlambat: 0, sakit: 0, izin: 0, alpa: 0, belumAbsen: 0 };
      const k = kelasMap[s.kelas];
      k.jumlahSiswa++;
      k.hadir += s.hadir; k.terlambat += s.terlambat; k.sakit += s.sakit; k.izin += s.izin; k.alpa += s.alpa; k.belumAbsen += s.belumAbsen;
    });
    setKelasRekap(Object.values(kelasMap).map((k: any) => ({
      ...k,
      persentase: totalHari > 0 && k.jumlahSiswa > 0 ? Math.round(((k.hadir + k.terlambat) / (k.jumlahSiswa * totalHari)) * 100) : 0
    })));
  };

  const countSchoolDays = (dari: Date, sampai: Date): number => {
    let count = 0;
    const current = new Date(dari);
    while (current <= sampai) {
      if (current.getDay() !== 0) count++;
      current.setDate(current.getDate() + 1);
    }
    return count;
  };

  const { dari, sampai, label } = getDateRange();

  const exportData = (fmt: 'excel' | 'pdf') => {
    if (!selectedSekolah) return;
    const params = new URLSearchParams({
      sekolahId: selectedSekolah.id,
      format: fmt,
      dari,
      sampai,
      tipe: tipeLaporan,
      periodeLabel: label,
    });
    if (selectedKelas) params.set('kelasId', selectedKelas);
    window.open(`/api/export?${params.toString()}`, '_blank');
  };

  const handlePrint = () => {
    if (!selectedSekolah) return;
    const params = new URLSearchParams({
      sekolahId: selectedSekolah.id,
      format: 'pdf',
      dari,
      sampai,
      tipe: tipeLaporan,
      periodeLabel: label,
    });
    if (selectedKelas) params.set('kelasId', selectedKelas);
    window.open(`/api/export?${params.toString()}`, '_blank');
  };

  // Grand totals for rekap
  const grandTotal = rekapList.reduce((acc, s: any) => ({
    hadir: acc.hadir + s.hadir, terlambat: acc.terlambat + s.terlambat,
    sakit: acc.sakit + s.sakit, izin: acc.izin + s.izin, alpa: acc.alpa + s.alpa, belumAbsen: acc.belumAbsen + s.belumAbsen,
  }), { hadir: 0, terlambat: 0, sakit: 0, izin: 0, alpa: 0, belumAbsen: 0 });

  if (!selectedSekolah) {
    return (
      <div className="flex items-center justify-center h-64">
        <AlertCircle className="w-8 h-8 text-amber-500 mr-3" />
        <p className="text-slate-400">Pilih sekolah terlebih dahulu</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Laporan Absensi</h2>
          <p className="text-slate-400">{selectedSekolah.nama}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button onClick={() => exportData('excel')} variant="outline" className="bg-slate-700/50 border-slate-600 text-white hover:bg-emerald-500/20">
            <Download className="w-4 h-4 mr-2" /> Excel
          </Button>
          <Button onClick={() => exportData('pdf')} variant="outline" className="bg-slate-700/50 border-slate-600 text-white hover:bg-red-500/20">
            <Download className="w-4 h-4 mr-2" /> PDF
          </Button>
          <Button onClick={handlePrint} className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white">
            <Printer className="w-4 h-4 mr-2" /> Cetak
          </Button>
        </div>
      </div>

      {/* Filter Card */}
      <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Tipe Laporan */}
            <div className="space-y-1.5">
              <Label className="text-xs text-slate-400">Tipe Laporan</Label>
              <div className="flex rounded-lg overflow-hidden border border-slate-600">
                <button onClick={() => setTipeLaporan('detail')} className={`flex-1 px-3 py-2 text-sm font-medium transition-colors ${tipeLaporan === 'detail' ? 'bg-emerald-500/20 text-emerald-400' : 'text-slate-400 hover:bg-slate-700'}`}>
                  <List className="w-4 h-4 inline mr-1" /> Detail
                </button>
                <button onClick={() => setTipeLaporan('rekap')} className={`flex-1 px-3 py-2 text-sm font-medium transition-colors ${tipeLaporan === 'rekap' ? 'bg-emerald-500/20 text-emerald-400' : 'text-slate-400 hover:bg-slate-700'}`}>
                  <BarChart3 className="w-4 h-4 inline mr-1" /> Rekap
                </button>
              </div>
            </div>

            {/* Periode */}
            <div className="space-y-1.5">
              <Label className="text-xs text-slate-400">Periode</Label>
              <Select value={periode} onValueChange={(v) => setPeriode(v as any)}>
                <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                  <Calendar className="w-4 h-4 mr-2 text-slate-400" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="harian" className="text-white">Harian</SelectItem>
                  <SelectItem value="bulanan" className="text-white">Bulanan</SelectItem>
                  <SelectItem value="semester" className="text-white">Per Semester</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Date input: changes based on periode */}
            <div className="space-y-1.5">
              <Label className="text-xs text-slate-400">
                {periode === 'harian' ? 'Tanggal' : periode === 'bulanan' ? 'Bulan' : 'Semester'}
              </Label>
              {periode === 'harian' && (
                <Input type="date" value={tanggalHarian} onChange={(e) => setTanggalHarian(e.target.value)} className="bg-slate-700/50 border-slate-600 text-white" />
              )}
              {periode === 'bulanan' && (
                <Input type="month" value={bulan} onChange={(e) => setBulan(e.target.value)} className="bg-slate-700/50 border-slate-600 text-white" />
              )}
              {periode === 'semester' && (
                <Select value={selectedSemester} onValueChange={setSelectedSemester}>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Pilih Semester" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {tahunAjaranList.map((ta: any) => (
                      <SelectItem key={ta.id} value={ta.id} className="text-white">
                        {ta.nama} - Sem {ta.semester}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>

            {/* Kelas */}
            <div className="space-y-1.5">
              <Label className="text-xs text-slate-400">Kelas</Label>
              <Select value={selectedKelas || "all"} onValueChange={(v) => setSelectedKelas(v === "all" ? "" : v)}>
                <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                  <SelectValue placeholder="Semua Kelas" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="all" className="text-white">Semua Kelas</SelectItem>
                  {kelasList.map((k) => (
                    <SelectItem key={k.id} value={k.id} className="text-white">{k.nama}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Status (only for detail) */}
            <div className="space-y-1.5">
              <Label className="text-xs text-slate-400">Status</Label>
              <Select value={status || "all"} onValueChange={(v) => setStatus(v === "all" ? "" : v)}>
                <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                  <SelectValue placeholder="Semua Status" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="all" className="text-white">Semua</SelectItem>
                  <SelectItem value="HADIR" className="text-white">Hadir</SelectItem>
                  <SelectItem value="TERLAMBAT" className="text-white">Terlambat</SelectItem>
                  <SelectItem value="SAKIT" className="text-white">Sakit</SelectItem>
                  <SelectItem value="IZIN" className="text-white">Izin</SelectItem>
                  <SelectItem value="ALPA" className="text-white">Alpa</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Periode info */}
          <div className="mt-3 flex items-center gap-2 text-xs text-slate-400">
            <Calendar className="w-3.5 h-3.5" />
            <span>Periode: <strong className="text-slate-300">{label}</strong></span>
            {tipeLaporan === 'rekap' && (
              <span className="ml-3">Total hari efektif: <strong className="text-slate-300">{countSchoolDays(new Date(dari + 'T00:00:00'), new Date(sampai + 'T23:59:59'))} hari</strong></span>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Rekap Summary Cards (only for rekap mode) */}
      {tipeLaporan === 'rekap' && (
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {[
            { label: 'Total Siswa', value: rekapList.length, color: 'text-blue-400', bg: 'bg-blue-500/10' },
            { label: 'Hadir', value: grandTotal.hadir, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
            { label: 'Terlambat', value: grandTotal.terlambat, color: 'text-amber-400', bg: 'bg-amber-500/10' },
            { label: 'Sakit', value: grandTotal.sakit, color: 'text-purple-400', bg: 'bg-purple-500/10' },
            { label: 'Izin', value: grandTotal.izin, color: 'text-sky-400', bg: 'bg-sky-500/10' },
            { label: 'Alpa', value: grandTotal.alpa, color: 'text-red-400', bg: 'bg-red-500/10' },
            { label: 'Belum Absen', value: grandTotal.belumAbsen, color: 'text-slate-400', bg: 'bg-slate-500/10' },
          ].map((s) => (
            <div key={s.label} className={`${s.bg} rounded-xl p-3 text-center`}>
              <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-xs text-slate-400">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Per-Kelas Rekap (only for rekap mode, when all classes selected) */}
      {tipeLaporan === 'rekap' && !selectedKelas && kelasRekap.length > 0 && (
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white">Ringkasan Per Kelas</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/30">
                    <TableHead className="text-slate-400 text-xs">Kelas</TableHead>
                    <TableHead className="text-slate-400 text-xs text-center">Siswa</TableHead>
                    <TableHead className="text-slate-400 text-xs text-center">Hadir</TableHead>
                    <TableHead className="text-slate-400 text-xs text-center">Terlambat</TableHead>
                    <TableHead className="text-slate-400 text-xs text-center">Sakit</TableHead>
                    <TableHead className="text-slate-400 text-xs text-center">Izin</TableHead>
                    <TableHead className="text-slate-400 text-xs text-center">Alpa</TableHead>
                    <TableHead className="text-slate-400 text-xs text-center">% Hadir</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {kelasRekap.map((k: any) => (
                    <TableRow key={k.kelas} className="border-slate-700 hover:bg-slate-700/30">
                      <TableCell className="font-medium text-white">{k.kelas}</TableCell>
                      <TableCell className="text-center text-slate-300">{k.jumlahSiswa}</TableCell>
                      <TableCell className="text-center text-emerald-400">{k.hadir}</TableCell>
                      <TableCell className="text-center text-amber-400">{k.terlambat}</TableCell>
                      <TableCell className="text-center text-purple-400">{k.sakit}</TableCell>
                      <TableCell className="text-center text-sky-400">{k.izin}</TableCell>
                      <TableCell className="text-center text-red-400">{k.alpa}</TableCell>
                      <TableCell className="text-center">
                        <span className={`font-medium ${k.persentase >= 75 ? 'text-emerald-400' : k.persentase >= 50 ? 'text-amber-400' : 'text-red-400'}`}>
                          {k.persentase}%
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Table */}
      <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-14 rounded-xl" />
              ))}
            </div>
          ) : tipeLaporan === 'detail' ? (
            /* ===== DETAIL TABLE ===== */
            <ScrollArea className="h-[calc(100vh-420px)]">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/30">
                    <TableHead className="text-slate-400 w-10">No</TableHead>
                    <TableHead className="text-slate-400">Tanggal</TableHead>
                    <TableHead className="text-slate-400">NIS</TableHead>
                    <TableHead className="text-slate-400">Nama</TableHead>
                    <TableHead className="text-slate-400">Kelas</TableHead>
                    <TableHead className="text-slate-400">Status</TableHead>
                    <TableHead className="text-slate-400">Jam Masuk</TableHead>
                    <TableHead className="text-slate-400">Jam Keluar</TableHead>
                    <TableHead className="text-slate-400">Metode</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {absensiList.map((a, i) => (
                    <TableRow key={a.id} className="border-slate-700 hover:bg-slate-700/30">
                      <TableCell className="text-slate-400">{i + 1}</TableCell>
                      <TableCell className="text-slate-300">{a.tanggal ? format(new Date(a.tanggal), 'dd/MM/yyyy') : '-'}</TableCell>
                      <TableCell className="text-slate-300">{a.siswa?.nis || '-'}</TableCell>
                      <TableCell className="font-medium text-white">{a.siswa?.nama}</TableCell>
                      <TableCell className="text-slate-300">{a.siswa?.kelas?.nama || '-'}</TableCell>
                      <TableCell>
                        <Badge className={
                          a.status === 'HADIR' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                          a.status === 'TERLAMBAT' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                          a.status === 'IZIN' ? 'bg-sky-500/20 text-sky-400 border-sky-500/30' :
                          a.status === 'SAKIT' ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' :
                          'bg-red-500/20 text-red-400 border-red-500/30'
                        }>
                          {a.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-slate-300">{a.jamMasuk ? format(new Date(a.jamMasuk), 'HH:mm') : '-'}</TableCell>
                      <TableCell className="text-slate-300">{a.jamKeluar ? format(new Date(a.jamKeluar), 'HH:mm') : '-'}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-slate-400">{a.metode}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                  {absensiList.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center text-slate-400 py-8">
                        Tidak ada data absensi untuk periode ini
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollArea>
          ) : (
            /* ===== REKAP TABLE ===== */
            <ScrollArea className="h-[calc(100vh-420px)]">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/30">
                    <TableHead className="text-slate-400 w-10">No</TableHead>
                    <TableHead className="text-slate-400">NIS</TableHead>
                    <TableHead className="text-slate-400">Nama Siswa</TableHead>
                    <TableHead className="text-slate-400">Kelas</TableHead>
                    <TableHead className="text-slate-400 text-center">H</TableHead>
                    <TableHead className="text-slate-400 text-center">T</TableHead>
                    <TableHead className="text-slate-400 text-center">S</TableHead>
                    <TableHead className="text-slate-400 text-center">I</TableHead>
                    <TableHead className="text-slate-400 text-center">A</TableHead>
                    <TableHead className="text-slate-400 text-center">BA</TableHead>
                    <TableHead className="text-slate-400 text-center">% Hadir</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rekapList.map((s: any) => (
                    <TableRow key={s.siswaId} className="border-slate-700 hover:bg-slate-700/30">
                      <TableCell className="text-slate-400">{s.no}</TableCell>
                      <TableCell className="text-slate-300">{s.nis}</TableCell>
                      <TableCell className="font-medium text-white">{s.nama}</TableCell>
                      <TableCell className="text-slate-300">{s.kelas}</TableCell>
                      <TableCell className="text-center text-emerald-400 font-medium">{s.hadir}</TableCell>
                      <TableCell className="text-center text-amber-400 font-medium">{s.terlambat}</TableCell>
                      <TableCell className="text-center text-purple-400 font-medium">{s.sakit}</TableCell>
                      <TableCell className="text-center text-sky-400 font-medium">{s.izin}</TableCell>
                      <TableCell className="text-center text-red-400 font-medium">{s.alpa}</TableCell>
                      <TableCell className="text-center text-slate-400">{s.belumAbsen}</TableCell>
                      <TableCell className="text-center">
                        <span className={`font-bold ${s.persentase >= 75 ? 'text-emerald-400' : s.persentase >= 50 ? 'text-amber-400' : 'text-red-400'}`}>
                          {s.persentase}%
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                  {rekapList.length > 0 && (
                    <TableRow className="border-slate-600 bg-slate-700/30 font-bold">
                      <TableCell className="text-slate-400" colSpan={4}>TOTAL</TableCell>
                      <TableCell className="text-center text-emerald-400">{grandTotal.hadir}</TableCell>
                      <TableCell className="text-center text-amber-400">{grandTotal.terlambat}</TableCell>
                      <TableCell className="text-center text-purple-400">{grandTotal.sakit}</TableCell>
                      <TableCell className="text-center text-sky-400">{grandTotal.izin}</TableCell>
                      <TableCell className="text-center text-red-400">{grandTotal.alpa}</TableCell>
                      <TableCell className="text-center text-slate-400">{grandTotal.belumAbsen}</TableCell>
                      <TableCell />
                    </TableRow>
                  )}
                  {rekapList.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={11} className="text-center text-slate-400 py-8">
                        Tidak ada data absensi untuk periode ini
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
              <div className="px-4 pb-3 text-xs text-slate-500">
                H = Hadir &middot; T = Terlambat &middot; S = Sakit &middot; I = Izin &middot; A = Alpa &middot; BA = Belum Absen
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
