'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { 
  Plus, Edit, Trash2, RefreshCw, Building2, LogIn, LogOut, CheckCircle, Users, BookOpen, MoreVertical 
} from 'lucide-react';

// ============== SEKOLAH PAGE ==============
interface SekolahData {
  id: string;
  nama: string;
  npsn: string | null;
  alamat: string | null;
  telepon: string | null;
  email: string | null;
  jenis: string;
  jamMasuk: string;
  jamToleransi: string;
  jamPulang: string;
  jamToleransiPulang: string;
  isActive: boolean;
  yayasan?: {
    id: string;
    nama: string;
  };
  _count?: {
    siswa: number;
    kelas: number;
  };
}

export function SekolahPage() {
  const { toast } = useToast();
  const [sekolahList, setSekolahList] = useState<SekolahData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  
  const [formData, setFormData] = useState({
    nama: '',
    npsn: '',
    alamat: '',
    telepon: '',
    email: '',
    jenis: 'SD' as 'SD' | 'SMP' | 'SMA' | 'SMK' | 'TK' | 'RA' | 'MI' | 'MTs' | 'MA',
    jamMasuk: '07:00',
    jamToleransi: '15',
    jamPulang: '15:00',
    jamToleransiPulang: '15',
    isActive: true
  });
  
  useEffect(() => {
    fetchSekolah();
  }, []);
  
  const fetchSekolah = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/sekolah');
      const data = await res.json();
      
      if (data.success) {
        setSekolahList(data.data);
      } else {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal memuat data sekolah',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const resetForm = () => {
    setFormData({
      nama: '',
      npsn: '',
      alamat: '',
      telepon: '',
      email: '',
      jenis: 'SD',
      jamMasuk: '07:00',
      jamToleransi: '15',
      jamPulang: '15:00',
      jamToleransiPulang: '15',
      isActive: true
    });
    setIsEditing(false);
    setEditingId(null);
  };
  
  const openAddDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };
  
  const openEditDialog = (sekolah: SekolahData) => {
    setIsEditing(true);
    setEditingId(sekolah.id);
    setFormData({
      nama: sekolah.nama,
      npsn: sekolah.npsn || '',
      alamat: sekolah.alamat || '',
      telepon: sekolah.telepon || '',
      email: sekolah.email || '',
      jenis: sekolah.jenis as any,
      jamMasuk: sekolah.jamMasuk,
      jamToleransi: sekolah.jamToleransi,
      jamPulang: sekolah.jamPulang,
      jamToleransiPulang: sekolah.jamToleransiPulang,
      isActive: sekolah.isActive
    });
    setIsDialogOpen(true);
  };
  
  const handleSave = async () => {
    if (!formData.nama.trim()) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Nama sekolah wajib diisi',
      });
      return;
    }
    
    setIsSaving(true);
    
    try {
      const yayasanId = sekolahList[0]?.yayasan?.id || 'default-yayasan';
      
      const url = isEditing ? `/api/sekolah/${editingId}` : '/api/sekolah';
      const method = isEditing ? 'PUT' : 'POST';
      
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          yayasanId
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({
          title: 'Berhasil',
          description: data.message || `Sekolah berhasil ${isEditing ? 'diperbarui' : 'ditambahkan'}`,
        });
        setIsDialogOpen(false);
        resetForm();
        fetchSekolah();
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan',
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleDelete = async (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus sekolah ini?')) return;
    
    try {
      const res = await fetch(`/api/sekolah/${id}`, {
        method: 'DELETE'
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({
          title: 'Berhasil',
          description: 'Sekolah berhasil dihapus',
        });
        fetchSekolah();
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan',
      });
    }
  };
  
  const getJenisBadge = (jenis: string) => {
    const colors: Record<string, string> = {
      'TK': 'bg-pink-500/20 text-pink-400 border-pink-500/30',
      'RA': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
      'SD': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      'MI': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
      'SMP': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      'MTs': 'bg-teal-500/20 text-teal-400 border-teal-500/30',
      'SMA': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      'MA': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
      'SMK': 'bg-red-500/20 text-red-400 border-red-500/30',
    };
    return colors[jenis] || 'bg-slate-500/20 text-slate-400 border-slate-500/30';
  };
  
  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Manajemen Sekolah</h2>
          <p className="text-slate-400">Kelola data sekolah dalam yayasan</p>
        </div>
        <Button 
          onClick={openAddDialog}
          className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Tambah Sekolah
        </Button>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-48 rounded-xl" />
          ))}
        </div>
      ) : sekolahList.length === 0 ? (
        <Card className="bg-slate-800/50 border-slate-700/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Building2 className="w-16 h-16 text-slate-600 mb-4" />
            <p className="text-slate-400 text-lg">Belum ada data sekolah</p>
            <p className="text-slate-500 text-sm">Klik tombol "Tambah Sekolah" untuk menambahkan</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sekolahList.map((sekolah) => (
            <Card 
              key={sekolah.id} 
              className={`bg-slate-800/50 border-slate-700/50 backdrop-blur-sm ${
                !sekolah.isActive ? 'opacity-60' : ''
              }`}
            >
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
                      <Building2 className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-white text-lg">{sekolah.nama}</CardTitle>
                      <Badge className={getJenisBadge(sekolah.jenis)}>
                        {sekolah.jenis}
                      </Badge>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                      <DropdownMenuItem 
                        onClick={() => openEditDialog(sekolah)}
                        className="text-slate-300 hover:text-white hover:bg-slate-700"
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleDelete(sekolah.id)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Hapus
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-slate-500">NPSN</span>
                    <p className="text-white">{sekolah.npsn || '-'}</p>
                  </div>
                  <div>
                    <span className="text-slate-500">Telepon</span>
                    <p className="text-white">{sekolah.telepon || '-'}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-2">
                    <LogIn className="w-4 h-4 text-emerald-400" />
                    <div>
                      <span className="text-slate-500 text-xs">Masuk</span>
                      <p className="text-white">{sekolah.jamMasuk} (±{sekolah.jamToleransi}m)</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <LogOut className="w-4 h-4 text-amber-400" />
                    <div>
                      <span className="text-slate-500 text-xs">Pulang</span>
                      <p className="text-white">{sekolah.jamPulang} (±{sekolah.jamToleransiPulang}m)</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between pt-2 border-t border-slate-700/50">
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-slate-400">
                      <Users className="w-4 h-4 inline mr-1" />
                      {sekolah._count?.siswa || 0} siswa
                    </span>
                    <span className="text-slate-400">
                      <BookOpen className="w-4 h-4 inline mr-1" />
                      {sekolah._count?.kelas || 0} kelas
                    </span>
                  </div>
                  {sekolah.isActive ? (
                    <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                      Aktif
                    </Badge>
                  ) : (
                    <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                      Nonaktif
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">
              {isEditing ? 'Edit Sekolah' : 'Tambah Sekolah Baru'}
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              {isEditing ? 'Perbarui informasi sekolah' : 'Masukkan informasi sekolah baru'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Nama Sekolah *</Label>
              <Input
                value={formData.nama}
                onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                placeholder="Nama sekolah"
                className="bg-slate-700/50 border-slate-600 text-white"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-slate-300">NPSN</Label>
              <Input
                value={formData.npsn}
                onChange={(e) => setFormData({ ...formData, npsn: e.target.value })}
                placeholder="Nomor Pokok Sekolah Nasional"
                className="bg-slate-700/50 border-slate-600 text-white"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-slate-300">Jenis Sekolah</Label>
              <Select 
                value={formData.jenis} 
                onValueChange={(value) => setFormData({ ...formData, jenis: value as any })}
              >
                <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  {['TK', 'RA', 'SD', 'MI', 'SMP', 'MTs', 'SMA', 'MA', 'SMK'].map((j) => (
                    <SelectItem key={j} value={j} className="text-white hover:bg-slate-700">
                      {j}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-slate-300">Telepon</Label>
              <Input
                value={formData.telepon}
                onChange={(e) => setFormData({ ...formData, telepon: e.target.value })}
                placeholder="Nomor telepon"
                className="bg-slate-700/50 border-slate-600 text-white"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-slate-300">Email</Label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="Email sekolah"
                className="bg-slate-700/50 border-slate-600 text-white"
              />
            </div>
            
            <div className="space-y-2 md:col-span-2">
              <Label className="text-slate-300">Alamat</Label>
              <Textarea
                value={formData.alamat}
                onChange={(e) => setFormData({ ...formData, alamat: e.target.value })}
                placeholder="Alamat lengkap sekolah"
                className="bg-slate-700/50 border-slate-600 text-white"
                rows={2}
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-slate-300 flex items-center gap-2">
                <LogIn className="w-4 h-4 text-emerald-400" />
                Jam Masuk
              </Label>
              <div className="flex gap-2">
                <Input
                  type="time"
                  value={formData.jamMasuk}
                  disabled
                  className="bg-slate-700/50 border-slate-600 text-slate-400 cursor-not-allowed"
                />
                <Input
                  type="number"
                  value={formData.jamToleransi}
                  onChange={(e) => setFormData({ ...formData, jamToleransi: e.target.value })}
                  placeholder="Toleransi (menit)"
                  className="bg-slate-700/50 border-slate-600 text-white w-32"
                />
                <span className="text-slate-400 self-center text-sm">menit</span>
              </div>
              <p className="text-xs text-emerald-400">Jam masuk diatur otomatis melalui menu Pengaturan</p>
            </div>
            
            <div className="space-y-2">
              <Label className="text-slate-300 flex items-center gap-2">
                <LogOut className="w-4 h-4 text-amber-400" />
                Jam Pulang
              </Label>
              <div className="flex gap-2">
                <Input
                  type="time"
                  value={formData.jamPulang}
                  disabled
                  className="bg-slate-700/50 border-slate-600 text-slate-400 cursor-not-allowed"
                />
                <Input
                  type="number"
                  value={formData.jamToleransiPulang}
                  onChange={(e) => setFormData({ ...formData, jamToleransiPulang: e.target.value })}
                  placeholder="Toleransi (menit)"
                  className="bg-slate-700/50 border-slate-600 text-white w-32"
                />
                <span className="text-slate-400 self-center text-sm">menit</span>
              </div>
              <p className="text-xs text-emerald-400">Jam pulang diatur otomatis melalui menu Pengaturan</p>
            </div>
            
            <div className="flex items-center gap-2 md:col-span-2">
              <Checkbox
                id="isActive"
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked as boolean })}
              />
              <Label htmlFor="isActive" className="text-slate-300">Sekolah Aktif</Label>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDialogOpen(false)}
              className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-700"
            >
              Batal
            </Button>
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Menyimpan...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  {isEditing ? 'Perbarui' : 'Simpan'}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
