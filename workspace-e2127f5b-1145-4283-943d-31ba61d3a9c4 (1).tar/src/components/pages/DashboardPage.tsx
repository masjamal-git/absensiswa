'use client';

import { useState, useEffect } from 'react';
import { Sekolah } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { 
  Users, BarChart3, CheckCircle, Clock, Heart, ShieldAlert, Ban, RefreshCw, AlertCircle
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';

export function DashboardPage({ selectedSekolah, refreshKey }: { selectedSekolah: Sekolah | null; refreshKey?: number }) {
  const { toast } = useToast();
  const [stats, setStats] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const fetchStats = async (showLoader = true) => {
    if (!selectedSekolah) return;
    
    if (showLoader) setIsLoading(true);
    try {
      const res = await fetch(`/api/dashboard?sekolahId=${selectedSekolah.id}`);
      const data = await res.json();
      
      if (data.success) {
        setStats(data.data);
      }
    } catch {
      // Don't show error toast on background refresh
      if (showLoader) {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: 'Gagal memuat data',
        });
      }
    } finally {
      if (showLoader) setIsLoading(false);
    }
  };
  
  // Initial fetch + refetch when sekolah changes
  useEffect(() => {
    if (selectedSekolah) {
      fetchStats();
    }
  }, [selectedSekolah]);
  
  // Refetch on refreshKey change (from socket event) - silent
  useEffect(() => {
    if (selectedSekolah && refreshKey && refreshKey > 0) {
      fetchStats(false);
    }
  }, [refreshKey]);
  
  // Auto-refresh every 15 seconds (silent - no loading spinner)
  useEffect(() => {
    if (!selectedSekolah) return;
    
    const interval = setInterval(() => {
      fetchStats(false);
    }, 15000);
    
    return () => clearInterval(interval);
  }, [selectedSekolah]);
  
  if (!selectedSekolah) {
    return (
      <div className="flex items-center justify-center h-64">
        <AlertCircle className="w-8 h-8 text-amber-500 mr-3" />
        <p className="text-slate-400">Pilih sekolah terlebih dahulu</p>
      </div>
    );
  }
  
  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-64 rounded-xl" />
        <Skeleton className="h-48 rounded-xl" />
      </div>
    );
  }
  
  const statCards = [
    { label: 'Total Siswa', value: stats?.today.totalSiswa || 0, icon: Users, color: 'from-blue-500 to-cyan-500' },
    { label: 'Hadir', value: stats?.today.hadir || 0, icon: CheckCircle, color: 'from-emerald-500 to-green-500' },
    { label: 'Terlambat', value: stats?.today.terlambat || 0, icon: Clock, color: 'from-amber-500 to-orange-500' },
    { label: 'Sakit', value: stats?.today.sakit || 0, icon: Heart, color: 'from-purple-500 to-violet-500' },
    { label: 'Izin', value: stats?.today.izin || 0, icon: ShieldAlert, color: 'from-sky-500 to-blue-500' },
    { label: 'Alpa', value: stats?.today.alpa || 0, icon: Ban, color: 'from-red-500 to-rose-500' },
    { label: 'Belum Absen', value: stats?.today.belumAbsen || 0, icon: AlertCircle, color: 'from-slate-500 to-slate-600' },
  ];
  
  const pieData = [
    { name: 'Hadir', value: stats?.today.hadir || 0, color: '#10b981' },
    { name: 'Terlambat', value: stats?.today.terlambat || 0, color: '#f59e0b' },
    { name: 'Izin', value: stats?.today.izin || 0, color: '#3b82f6' },
    { name: 'Sakit', value: stats?.today.sakit || 0, color: '#8b5cf6' },
    { name: 'Alpa', value: stats?.today.alpa || 0, color: '#ef4444' },
  ];
  
  const barData = stats?.perKelasStats?.map((k: any) => ({
    nama: k.nama,
    hadir: k.hadir,
    total: k.totalSiswa,
  })) || [];
  
  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Dashboard</h2>
          <p className="text-slate-400">{stats?.today.tanggal}</p>
        </div>
        <Button onClick={() => fetchStats(true)} variant="outline" className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-700">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>
      
      {/* Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-4">
        {statCards.map((stat, i) => (
          <Card key={i} className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-400">{stat.label}</p>
                  <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
                </div>
                <div className={`p-2 rounded-xl bg-gradient-to-br ${stat.color}`}>
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pie Chart */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">Status Kehadiran Hari Ini</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        {/* Bar Chart */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">Kehadiran Per Kelas</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="nama" stroke="#94a3b8" fontSize={12} />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Bar dataKey="hadir" fill="#10b981" radius={[4, 4, 0, 0]} name="Hadir" />
                <Bar dataKey="total" fill="#334155" radius={[4, 4, 0, 0]} name="Total" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Attendance */}
      <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white">Absensi Terbaru</CardTitle>
          <CardDescription className="text-slate-400">
            10 absensi terakhir hari ini
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-64">
            <Table>
              <TableHeader>
                <TableRow className="border-slate-700 hover:bg-slate-700/30">
                  <TableHead className="text-slate-400">Nama</TableHead>
                  <TableHead className="text-slate-400">Kelas</TableHead>
                  <TableHead className="text-slate-400">Jam</TableHead>
                  <TableHead className="text-slate-400">Status</TableHead>
                  <TableHead className="text-slate-400">Metode</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stats?.recentAttendance?.map((a: any) => (
                  <TableRow key={a.id} className="border-slate-700 hover:bg-slate-700/30">
                    <TableCell className="font-medium text-white">{a.nama}</TableCell>
                    <TableCell className="text-slate-300">{a.kelas}</TableCell>
                    <TableCell className="text-slate-300">{a.jam}</TableCell>
                    <TableCell>
                      <Badge className={
                        a.status === 'HADIR' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                        a.status === 'TERLAMBAT' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                        a.status === 'IZIN' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                        a.status === 'SAKIT' ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' :
                        'bg-red-500/20 text-red-400 border-red-500/30'
                      }>
                        {a.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-slate-300">
                        {a.metode}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
                {(!stats?.recentAttendance || stats.recentAttendance.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-slate-400 py-8">
                      Belum ada data absensi hari ini
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
