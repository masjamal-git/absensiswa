'use client';

import { useState, useEffect } from 'react';
import { Sekolah, Kelas } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';

import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import {
  Plus, Edit, Trash2, QrCode, Search, Download, IdCard,
  Printer, Upload, FileSpreadsheet, Settings, AlertCircle
} from 'lucide-react';

import { CardSettings, SiswaWithDetails } from './SiswaCard';
import { SiswaDialogs } from './SiswaDialogs';

// ============== SISWA PAGE ==============

export function SiswaPage({ selectedSekolah }: { selectedSekolah: Sekolah | null }) {
  const { toast } = useToast();
  const [siswaList, setSiswaList] = useState<SiswaWithDetails[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedKelas, setSelectedKelas] = useState<string>('');
  const [kelasList, setKelasList] = useState<Kelas[]>([]);
  const [selectedSiswa, setSelectedSiswa] = useState<SiswaWithDetails | null>(null);
  const [qrCode, setQrCode] = useState<string>('');

  // Dialog visibility state
  const [showQRDialog, setShowQRDialog] = useState(false);
  const [showFormDialog, setShowFormDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showCardDialog, setShowCardDialog] = useState(false);
  const [showBulkPrintDialog, setShowBulkPrintDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showCardSettingsDialog, setShowCardSettingsDialog] = useState(false);

  // Form mode (add/edit)
  const [formMode, setFormMode] = useState<'add' | 'edit'>('add');
  const [cardQrCode, setCardQrCode] = useState<string>('');

  // Bulk selection state
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);

  // Card settings state (shared between dialogs)
  const [cardSettings, setCardSettings] = useState<CardSettings>({
    warnaHeader: '#059669',
    warnaBackground: '#ffffff',
    tahunAjaran: '2024/2025',
    berlakuSampai: 'Juli 2025',
    namaKepalaSekolah: '',
    nipKepalaSekolah: '',
    showQR: true,
    showFoto: true,
    logoSekolah: null,
    kartuPerHalaman: 6,
  });

  useEffect(() => {
    if (selectedSekolah) {
      fetchSiswa();
      fetchKelas();
      fetchCardSettings();
    }
  }, [selectedSekolah, search, selectedKelas]);

  const fetchSiswa = async () => {
    if (!selectedSekolah) return;

    setIsLoading(true);
    try {
      let url = `/api/siswa?sekolahId=${selectedSekolah.id}`;
      if (search) url += `&search=${search}`;
      if (selectedKelas) url += `&kelasId=${selectedKelas}`;

      const res = await fetch(url);
      const data = await res.json();

      if (data.success) {
        setSiswaList(data.data);
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal memuat data siswa',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchKelas = async () => {
    if (!selectedSekolah) return;

    try {
      const res = await fetch(`/api/kelas?sekolahId=${selectedSekolah.id}`);
      const data = await res.json();

      if (data.success) {
        setKelasList(data.data);
      }
    } catch {
      // Silently fail
    }
  };

  const fetchCardSettings = async () => {
    if (!selectedSekolah) return;

    try {
      const res = await fetch(`/api/kartu-pengaturan?sekolahId=${selectedSekolah.id}`);
      const data = await res.json();

      if (data.success) {
        setCardSettings({
          warnaHeader: data.data.warnaHeader || '#059669',
          warnaBackground: data.data.warnaBackground || '#ffffff',
          tahunAjaran: data.data.tahunAjaran || '2024/2025',
          berlakuSampai: data.data.berlakuSampai || 'Juli 2025',
          namaKepalaSekolah: data.data.namaKepalaSekolah || '',
          nipKepalaSekolah: data.data.nipKepalaSekolah || '',
          showQR: data.data.showQR ?? true,
          showFoto: data.data.showFoto ?? true,
          logoSekolah: data.data.logoSekolah || null,
          kartuPerHalaman: data.data.kartuPerHalaman || 6
        });
      }
    } catch {
      // Use defaults
    }
  };

  const showQR = async (siswa: SiswaWithDetails) => {
    setSelectedSiswa(siswa);
    setShowQRDialog(true);

    try {
      const res = await fetch(`/api/qr?siswaId=${siswa.id}`);
      const data = await res.json();

      if (data.success) {
        setQrCode(data.data.qrCode);
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal memuat QR Code',
      });
    }
  };

  const showStudentCard = async (siswa: SiswaWithDetails) => {
    setSelectedSiswa(siswa);
    setShowCardDialog(true);

    try {
      const res = await fetch(`/api/qr?siswaId=${siswa.id}`);
      const data = await res.json();

      if (data.success) {
        setCardQrCode(data.data.qrCode);
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal memuat QR Code',
      });
    }
  };

  // Bulk selection handlers
  const toggleSelectAll = () => {
    if (selectedStudents.length === siswaList.length) {
      setSelectedStudents([]);
    } else {
      setSelectedStudents(siswaList.map(s => s.id));
    }
  };

  const toggleSelectStudent = (id: string) => {
    setSelectedStudents(prev =>
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  // Open bulk print dialog
  const openBulkPrintDialog = () => {
    if (selectedStudents.length === 0) {
      toast({
        variant: 'destructive',
        title: 'Peringatan',
        description: 'Pilih minimal satu siswa untuk dicetak',
      });
      return;
    }
    setShowBulkPrintDialog(true);
  };

  // Open add form
  const openAddForm = () => {
    setFormMode('add');
    setSelectedSiswa(null);
    setShowFormDialog(true);
  };

  // Open edit form
  const openEditForm = (siswa: SiswaWithDetails) => {
    setFormMode('edit');
    setSelectedSiswa(siswa);
    setShowFormDialog(true);
  };

  // Download template
  const downloadTemplate = async () => {
    if (!selectedSekolah) return;

    try {
      const res = await fetch(`/api/siswa/template?sekolahId=${selectedSekolah.id}`);
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'template_import_siswa.xlsx';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();

      toast({
        title: 'Berhasil',
        description: 'Template berhasil diunduh',
      });
    } catch {
      toast({
        variant: 'destructive',
        title: 'Gagal',
        description: 'Gagal mengunduh template',
      });
    }
  };

  if (!selectedSekolah) {
    return (
      <div className="flex items-center justify-center h-64">
        <AlertCircle className="w-8 h-8 text-amber-500 mr-3" />
        <p className="text-slate-400">Pilih sekolah terlebih dahulu</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Print styles */}
      <style jsx global>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .print-area, .print-area * {
            visibility: visible;
          }
          .print-area {
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            z-index: 99999;
          }
          .print-hidden {
            display: none !important;
          }
          .student-card {
            box-shadow: none !important;
            border: 1px solid #e5e7eb !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .student-card * {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .bulk-print-page {
            page-break-after: always;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .bulk-print-page * {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .bulk-print-page:last-child {
            page-break-after: auto;
          }
          @page {
            size: 210mm 330mm;
            margin: 0;
          }
        }
      `}</style>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 print-hidden">
        <div>
          <h2 className="text-2xl font-bold text-white">Data Siswa</h2>
          <p className="text-slate-400">{selectedSekolah.nama}</p>
        </div>

        <div className="flex gap-3 flex-wrap">
          {/* Bulk Actions */}
          {selectedStudents.length > 0 && (
            <Button
              onClick={openBulkPrintDialog}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              <Printer className="w-4 h-4 mr-2" />
              Cetak {selectedStudents.length} Kartu
            </Button>
          )}

          <Button
            onClick={() => setShowCardSettingsDialog(true)}
            variant="outline"
            className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600"
          >
            <Settings className="w-4 h-4 mr-2" />
            Pengaturan Kartu
          </Button>

          <Select value={selectedKelas || "all"} onValueChange={(v) => setSelectedKelas(v === "all" ? "" : v)}>
            <SelectTrigger className="w-36 bg-slate-700/50 border-slate-600 text-white">
              <SelectValue placeholder="Semua Kelas" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-700">
              <SelectItem value="all" className="text-white">Semua Kelas</SelectItem>
              {kelasList.map((k) => (
                <SelectItem key={k.id} value={k.id} className="text-white">{k.nama}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              type="text"
              placeholder="Cari siswa..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 w-48 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
            />
          </div>

          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-700"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Import/Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                <DropdownMenuItem
                  onClick={() => setShowImportDialog(true)}
                  className="text-slate-300 hover:text-white hover:bg-slate-700"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Import dari Excel
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={downloadTemplate}
                  className="text-slate-300 hover:text-white hover:bg-slate-700"
                >
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  Download Template
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              onClick={openAddForm}
              className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Tambah Siswa
            </Button>
          </div>
        </div>
      </div>

      <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm print-hidden">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-16 rounded-xl" />
              ))}
            </div>
          ) : (
            <ScrollArea className="h-[calc(100vh-280px)]">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/30">
                    <TableHead className="text-slate-400 w-12">
                      <Checkbox
                        checked={selectedStudents.length === siswaList.length && siswaList.length > 0}
                        onCheckedChange={toggleSelectAll}
                        className="border-slate-500 data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
                      />
                    </TableHead>
                    <TableHead className="text-slate-400">Nama</TableHead>
                    <TableHead className="text-slate-400">NIS</TableHead>
                    <TableHead className="text-slate-400">Kelas</TableHead>
                    <TableHead className="text-slate-400">JK</TableHead>
                    <TableHead className="text-slate-400">Kontak Ortu</TableHead>
                    <TableHead className="text-slate-400 text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {siswaList.map((siswa) => (
                    <TableRow key={siswa.id} className="border-slate-700 hover:bg-slate-700/30">
                      <TableCell>
                        <Checkbox
                          checked={selectedStudents.includes(siswa.id)}
                          onCheckedChange={() => toggleSelectStudent(siswa.id)}
                          className="border-slate-500 data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
                        />
                      </TableCell>
                      <TableCell className="font-medium text-white">
                        <div className="flex items-center gap-2">
                          {siswa.foto ? (
                            <img src={siswa.foto} alt={siswa.nama} className="w-8 h-8 rounded-full object-cover" />
                          ) : (
                            <Avatar className="w-8 h-8">
                              <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-xs">
                                {siswa.nama.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                          )}
                          {siswa.nama}
                        </div>
                      </TableCell>
                      <TableCell className="text-slate-300">{siswa.nis}</TableCell>
                      <TableCell className="text-slate-300">{siswa.kelas?.nama || '-'}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={
                          siswa.jenisKelamin === 'L'
                            ? 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                            : 'bg-pink-500/20 text-pink-400 border-pink-500/30'
                        }>
                          {siswa.jenisKelamin || '-'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-slate-300">
                        {siswa.phoneAyah || siswa.phoneIbu || '-'}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => showStudentCard(siswa)}
                            className="bg-slate-700/50 border-slate-600 text-white hover:bg-purple-500/20 hover:text-purple-400"
                            title="Cetak Kartu Pelajar"
                          >
                            <IdCard className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => showQR(siswa)}
                            className="bg-slate-700/50 border-slate-600 text-white hover:bg-emerald-500/20 hover:text-emerald-400"
                            title="Lihat QR Code"
                          >
                            <QrCode className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => openEditForm(siswa)}
                            className="bg-slate-700/50 border-slate-600 text-white hover:bg-blue-500/20 hover:text-blue-400"
                            title="Edit Siswa"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedSiswa(siswa);
                              setShowDeleteDialog(true);
                            }}
                            className="bg-slate-700/50 border-slate-600 text-white hover:bg-red-500/20 hover:text-red-400"
                            title="Hapus Siswa"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {siswaList.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center text-slate-400 py-8">
                        Tidak ada data siswa
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* All Dialog Components */}
      <SiswaDialogs
        selectedSekolah={selectedSekolah}
        kelasList={kelasList}
        siswaList={siswaList}
        selectedStudents={selectedStudents}
        selectedSiswa={selectedSiswa}
        qrCode={qrCode}
        cardQrCode={cardQrCode}
        cardSettings={cardSettings}
        setCardSettings={setCardSettings}
        formMode={formMode}
        showQRDialog={showQRDialog}
        showFormDialog={showFormDialog}
        showDeleteDialog={showDeleteDialog}
        showCardDialog={showCardDialog}
        showBulkPrintDialog={showBulkPrintDialog}
        showImportDialog={showImportDialog}
        showCardSettingsDialog={showCardSettingsDialog}
        setShowQRDialog={setShowQRDialog}
        setShowFormDialog={setShowFormDialog}
        setShowDeleteDialog={setShowDeleteDialog}
        setShowCardDialog={setShowCardDialog}
        setShowBulkPrintDialog={setShowBulkPrintDialog}
        setShowImportDialog={setShowImportDialog}
        setShowCardSettingsDialog={setShowCardSettingsDialog}
        fetchSiswa={fetchSiswa}
        downloadTemplate={downloadTemplate}
      />
    </div>
  );
}
