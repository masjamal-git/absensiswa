'use client';

import { Sekolah } from '@/lib/store';
import { StudentCard, getGridLayout, CardSettings, SiswaWithDetails } from './SiswaCard';

// Bulk Print Page Component (F4 Paper - 210mm x 330mm)
export function BulkPrintPage({ 
  students, 
  sekolah, 
  qrCodes, 
  settings,
  pageNumber,
}: { 
  students: SiswaWithDetails[]; 
  sekolah: Sekolah | null; 
  qrCodes: Record<string, string>;
  settings: CardSettings;
  pageNumber: number;
}) {
  const layout = getGridLayout(settings.kartuPerHalaman);
  const gridRows = Array(layout.rows).fill('1fr').join(' ');
  
  return (
    <div className="bulk-print-page" style={{ 
      width: '210mm', 
      height: '330mm', 
      padding: layout.padding,
      pageBreakAfter: 'always',
      boxSizing: 'border-box',
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: '#fff',
    }}>
      {/* Title row */}
      <div style={{ textAlign: 'center', marginBottom: '2mm' }}>
        <span style={{ fontSize: '9px', color: '#9ca3af' }}>
          Halaman {pageNumber} &mdash; {students.length} kartu
        </span>
      </div>
      
      {/* Card grid */}
      <div style={{ 
        flex: 1,
        display: 'grid', 
        gridTemplateColumns: `repeat(${layout.cols}, 1fr)`, 
        gridTemplateRows: gridRows,
        gap: layout.gap,
      }}>
        {students.map((siswa) => (
          <div key={siswa.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <StudentCard 
              siswa={siswa} 
              sekolah={sekolah} 
              qrCode={qrCodes[siswa.id] || ''} 
              settings={settings}
            />
          </div>
        ))}
        {/* Fill empty slots */}
        {students.length < settings.kartuPerHalaman && Array.from({ length: settings.kartuPerHalaman - students.length }).map((_, i) => (
          <div key={`empty-${i}`} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ width: '85.6mm', height: '53.98mm' }}></div>
          </div>
        ))}
      </div>
    </div>
  );
}
