'use client';

import { useState, useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, GraduationCap, Eye, EyeOff, RefreshCw, Database, LogIn } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

export function LoginPage() {
  const { setUser } = useAppStore();
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [needsInit, setNeedsInit] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);

  useEffect(() => {
    checkInit();
  }, []);

  const checkInit = async () => {
    try {
      const res = await fetch('/api/init');
      const data = await res.json();
      if (!data.initialized) {
        setNeedsInit(true);
      }
    } catch {
      setNeedsInit(true);
    }
  };

  const handleInit = async () => {
    setIsInitializing(true);
    try {
      const res = await fetch('/api/init', { method: 'POST' });
      const data = await res.json();
      
      if (data.success) {
        toast({
          title: 'Inisialisasi Berhasil',
          description: 'Database telah diisi dengan data contoh. Silakan login.',
        });
        setNeedsInit(false);
        setEmail('superadmin@nurulhuda.sch.id');
        setPassword('admin123');
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan',
      });
    } finally {
      setIsInitializing(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      
      const data = await res.json();
      
      if (data.success) {
        setUser(data.user);
        toast({
          title: 'Login Berhasil',
          description: `Selamat datang, ${data.user.nama}`,
        });
      } else {
        toast({
          variant: 'destructive',
          title: 'Login Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan saat login',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-40"></div>
      
      <Card className="w-full max-w-md relative z-10 border-0 shadow-2xl bg-slate-800/90 backdrop-blur-xl">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-emerald-500/30">
            <GraduationCap className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-white">Sistem Absensi Siswa</CardTitle>
          <CardDescription className="text-slate-400">
            Yayasan Pendidikan Multi Sekolah
          </CardDescription>
        </CardHeader>
        
        <CardContent className="pt-4">
          {needsInit ? (
            <div className="text-center py-6">
              <AlertCircle className="w-12 h-12 mx-auto text-amber-500 mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Database Belum Diinisialisasi</h3>
              <p className="text-slate-400 text-sm mb-4">
                Klik tombol di bawah untuk mengisi database dengan data contoh
              </p>
              <Button 
                onClick={handleInit} 
                disabled={isInitializing}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
              >
                {isInitializing ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Menginisialisasi...
                  </>
                ) : (
                  <>
                    <Database className="w-4 h-4 mr-2" />
                    Inisialisasi Database
                  </>
                )}
              </Button>
            </div>
          ) : (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-300">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="email@sekolah.sch.id"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 focus:border-emerald-500"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-300">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 focus:border-emerald-500 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Memproses...
                  </>
                ) : (
                  <>
                    <LogIn className="w-4 h-4 mr-2" />
                    Masuk
                  </>
                )}
              </Button>
              
              <div className="text-center text-xs text-slate-500 mt-4">
                <p>Demo Account:</p>
                <p className="text-slate-400">superadmin@nurulhuda.sch.id / admin123</p>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
