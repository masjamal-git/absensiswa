'use client';

import { useState, useEffect, useRef } from 'react';
import { Sekolah, Kelas } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import {
  Settings, X, ImagePlus, RefreshCw, Upload, CheckSquare, Printer,
  UserPlus, Trash2, AlertCircle, CheckCircle, IdCard, FileSpreadsheet
} from 'lucide-react';

import { StudentCard, getGridLayout, CardSettings, SiswaWithDetails } from './SiswaCard';
import { BulkPrintPage } from './BulkPrintPage';

// ============== TYPES ==============

type FormData = {
  nis: string;
  nisn: string;
  nama: string;
  jenisKelamin: 'L' | 'P';
  tempatLahir: string;
  tanggalLahir: string;
  alamat: string;
  kelasId: string;
  namaAyah: string;
  pekerjaanAyah: string;
  phoneAyah: string;
  namaIbu: string;
  pekerjaanIbu: string;
  phoneIbu: string;
  namaWali: string;
  phoneWali: string;
  foto: string;
};

type ImportResult = {
  success: number;
  failed: number;
  errors: { row: number; message: string }[];
};

// ============== QR CODE DIALOG ==============

interface QRCodeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  siswa: SiswaWithDetails | null;
  qrCode: string;
}

export function QRCodeDialog({ open, onOpenChange, siswa, qrCode }: QRCodeDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-800 border-slate-700 text-white">
        <DialogHeader>
          <DialogTitle>QR Code Siswa</DialogTitle>
          <DialogDescription className="text-slate-400">
            {siswa?.nama} - {siswa?.kelas?.nama}
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col items-center py-4">
          {qrCode ? (
            <img src={qrCode} alt="QR Code" className="w-64 h-64 rounded-xl" />
          ) : (
            <Skeleton className="w-64 h-64 rounded-xl" />
          )}
          <p className="text-slate-400 mt-4 text-sm">NIS: {siswa?.nis}</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============== CARD SETTINGS DIALOG ==============

interface CardSettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  cardSettings: CardSettings;
  setCardSettings: React.Dispatch<React.SetStateAction<CardSettings>>;
  selectedSekolah: Sekolah;
}

export function CardSettingsDialog({
  open,
  onOpenChange,
  cardSettings,
  setCardSettings,
  selectedSekolah,
}: CardSettingsDialogProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);

  const saveCardSettings = async () => {
    if (!selectedSekolah) return;

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/kartu-pengaturan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sekolahId: selectedSekolah.id,
          ...cardSettings
        })
      });

      const data = await res.json();

      if (data.success) {
        toast({
          title: 'Berhasil',
          description: 'Pengaturan kartu berhasil disimpan',
        });
        onOpenChange(false);
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message || 'Gagal menyimpan pengaturan',
        });
      }
    } catch (err) {
      console.error('Save card settings error:', err);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan saat menyimpan',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const uploadLogo = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedSekolah || !e.target.files?.[0]) return;

    const file = e.target.files[0];
    setIsUploadingLogo(true);

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('sekolahId', selectedSekolah.id);

      const res = await fetch('/api/upload-logo', {
        method: 'POST',
        body: formData
      });

      const data = await res.json();

      if (data.success) {
        setCardSettings(prev => ({ ...prev, logoSekolah: data.data.url }));
        toast({
          title: 'Berhasil',
          description: 'Logo berhasil diupload',
        });
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message || 'Gagal mengupload logo',
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan saat upload logo',
      });
    } finally {
      setIsUploadingLogo(false);
      // Reset file input
      e.target.value = '';
    }
  };

  const deleteLogo = async () => {
    if (!selectedSekolah) return;

    try {
      const res = await fetch(`/api/upload-logo?sekolahId=${selectedSekolah.id}`, {
        method: 'DELETE'
      });

      const data = await res.json();

      if (data.success) {
        setCardSettings(prev => ({ ...prev, logoSekolah: null }));
        toast({
          title: 'Berhasil',
          description: 'Logo berhasil dihapus',
        });
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal menghapus logo',
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-emerald-400" />
            Pengaturan Kartu Pelajar
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Konfigurasi tampilan kartu pelajar
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label className="text-slate-300">Warna Header</Label>
            <div className="flex gap-2 items-center">
              <Input
                type="color"
                value={cardSettings.warnaHeader}
                onChange={(e) => setCardSettings(prev => ({ ...prev, warnaHeader: e.target.value }))}
                className="w-12 h-10 p-1 bg-slate-700/50 border-slate-600"
              />
              <Input
                value={cardSettings.warnaHeader}
                onChange={(e) => setCardSettings(prev => ({ ...prev, warnaHeader: e.target.value }))}
                className="flex-1 bg-slate-700/50 border-slate-600 text-white"
                placeholder="#059669"
              />
            </div>
          </div>

          {/* Logo Upload */}
          <div className="space-y-2">
            <Label className="text-slate-300">Logo Sekolah</Label>
            <div className="flex items-center gap-3">
              {cardSettings.logoSekolah ? (
                <div className="relative group">
                  <img
                    src={cardSettings.logoSekolah}
                    alt="Logo Sekolah"
                    className="w-16 h-16 rounded-lg object-contain border border-slate-600 bg-white p-1"
                  />
                  <button
                    onClick={deleteLogo}
                    disabled={isUploadingLogo}
                    className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-white hover:bg-red-600 transition-colors"
                    title="Hapus logo"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <div className="w-16 h-16 rounded-lg border-2 border-dashed border-slate-600 flex items-center justify-center bg-slate-700/30">
                  <ImagePlus className="w-6 h-6 text-slate-500" />
                </div>
              )}
              <div className="flex-1">
                <label className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg border border-slate-600 text-slate-300 hover:bg-slate-700/50 hover:text-white cursor-pointer transition-colors text-sm">
                  {isUploadingLogo ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Mengupload...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4" />
                      {cardSettings.logoSekolah ? 'Ganti Logo' : 'Upload Logo'}
                    </>
                  )}
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/jpg,image/svg+xml,image/webp"
                    onChange={uploadLogo}
                    disabled={isUploadingLogo}
                    className="hidden"
                  />
                </label>
                <p className="text-[10px] text-slate-500 mt-1">PNG, JPG, SVG, WebP (maks. 2MB)</p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-slate-300">Tahun Ajaran</Label>
            <Input
              value={cardSettings.tahunAjaran}
              onChange={(e) => setCardSettings(prev => ({ ...prev, tahunAjaran: e.target.value }))}
              className="bg-slate-700/50 border-slate-600 text-white"
              placeholder="2024/2025"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-slate-300">Berlaku Sampai</Label>
            <Input
              value={cardSettings.berlakuSampai}
              onChange={(e) => setCardSettings(prev => ({ ...prev, berlakuSampai: e.target.value }))}
              className="bg-slate-700/50 border-slate-600 text-white"
              placeholder="Juli 2025"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-slate-300">Nama Kepala Sekolah</Label>
            <Input
              value={cardSettings.namaKepalaSekolah}
              onChange={(e) => setCardSettings(prev => ({ ...prev, namaKepalaSekolah: e.target.value }))}
              className="bg-slate-700/50 border-slate-600 text-white"
              placeholder="Nama Kepala Sekolah"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-slate-300">NIP Kepala Sekolah</Label>
            <Input
              value={cardSettings.nipKepalaSekolah}
              onChange={(e) => setCardSettings(prev => ({ ...prev, nipKepalaSekolah: e.target.value }))}
              className="bg-slate-700/50 border-slate-600 text-white"
              placeholder="NIP Kepala Sekolah"
            />
          </div>

          <div className="flex items-center gap-4 pt-2">
            <label className="flex items-center gap-2 text-slate-300">
              <Checkbox
                checked={cardSettings.showQR}
                onCheckedChange={(checked) => setCardSettings(prev => ({ ...prev, showQR: !!checked }))}
                className="border-slate-500 data-[state=checked]:bg-emerald-500"
              />
              Tampilkan QR Code
            </label>
            <label className="flex items-center gap-2 text-slate-300">
              <Checkbox
                checked={cardSettings.showFoto}
                onCheckedChange={(checked) => setCardSettings(prev => ({ ...prev, showFoto: !!checked }))}
                className="border-slate-500 data-[state=checked]:bg-emerald-500"
              />
              Tampilkan Foto
            </label>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="bg-slate-700/50 border-slate-600 text-white"
          >
            Batal
          </Button>
          <Button
            onClick={saveCardSettings}
            disabled={isSubmitting}
            className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Menyimpan...
              </>
            ) : 'Simpan'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============== STUDENT CARD DIALOG ==============

interface StudentCardDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  siswa: SiswaWithDetails | null;
  sekolah: Sekolah;
  qrCode: string;
  cardSettings: CardSettings;
}

export function StudentCardDialog({ open, onOpenChange, siswa, sekolah, qrCode, cardSettings }: StudentCardDialogProps) {
  const printStudentCard = () => {
    window.print();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <IdCard className="w-5 h-5 text-purple-400" />
            Kartu Pelajar
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Preview kartu pelajar - klik cetak untuk mencetak
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col items-center gap-4">
          {/* Student Card Preview */}
          <div className="print-area">
            <StudentCard
              siswa={siswa!}
              sekolah={sekolah}
              qrCode={qrCode}
              settings={cardSettings}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 print-hidden">
            <Button
              onClick={printStudentCard}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              <Printer className="w-4 h-4 mr-2" />
              Cetak Kartu
            </Button>
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="bg-slate-700/50 border-slate-600 text-white"
            >
              Tutup
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============== BULK PRINT DIALOG ==============

interface BulkPrintDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  siswaList: SiswaWithDetails[];
  selectedStudentIds: string[];
  sekolah: Sekolah;
  cardSettings: CardSettings;
  setCardSettings: React.Dispatch<React.SetStateAction<CardSettings>>;
}

export function BulkPrintDialog({
  open,
  onOpenChange,
  siswaList,
  selectedStudentIds,
  sekolah,
  cardSettings,
  setCardSettings,
}: BulkPrintDialogProps) {
  const { toast } = useToast();
  const [isGeneratingQr, setIsGeneratingQr] = useState(false);
  const [bulkQrCodes, setBulkQrCodes] = useState<Record<string, string>>({});
  const [bulkPreviewPage, setBulkPreviewPage] = useState(1);

  const totalPrintPages = Math.ceil(selectedStudentIds.length / cardSettings.kartuPerHalaman);

  const getSelectedStudentsData = () => {
    return siswaList.filter(s => selectedStudentIds.includes(s.id));
  };

  const groupStudentsForPrint = (students: SiswaWithDetails[], perPage?: number) => {
    const per = perPage || cardSettings.kartuPerHalaman;
    const pages: SiswaWithDetails[][] = [];
    for (let i = 0; i < students.length; i += per) {
      pages.push(students.slice(i, i + per));
    }
    return pages;
  };

  // Helper for logo HTML in print
  const settings_logoHtml = (settings: CardSettings) => {
    if (settings.logoSekolah) {
      return `<img src="${settings.logoSekolah}" style="width:28px;height:28px;border-radius:50%;object-fit:contain;flex-shrink:0;background:#fff;padding:2px;" />`;
    }
    return `<div style="width:28px;height:28px;background:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${settings.warnaHeader || '#059669'}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 6 3 6 3s3 0 6-3v-5"/></svg></div>`;
  };

  // Fetch QR codes when dialog opens
  useEffect(() => {
    if (!open || selectedStudentIds.length === 0) return;
    let cancelled = false;
    (async () => {
      setIsGeneratingQr(true);
      try {
        const qrPromises = selectedStudentIds.map(async (id) => {
          const res = await fetch(`/api/qr?siswaId=${id}`);
          const data = await res.json();
          return { id, qrCode: data.success ? data.data.qrCode : '' };
        });

        const results = await Promise.all(qrPromises);
        if (cancelled) return;
        const qrMap: Record<string, string> = {};
        results.forEach(r => {
          qrMap[r.id] = r.qrCode;
        });
        setBulkQrCodes(qrMap);
      } catch {
        if (!cancelled) {
          toast({
            variant: 'destructive',
            title: 'Error',
            description: 'Gagal memuat QR Code',
          });
        }
      } finally {
        if (!cancelled) {
          setIsGeneratingQr(false);
        }
      }
    })();
    return () => { cancelled = true; };
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  // Reset preview page when dialog opens or kartuPerHalaman changes
  useEffect(() => {
    if (open) {
      setBulkPreviewPage(1);
    }
  }, [open, cardSettings.kartuPerHalaman]);

  // Auto-scale bulk print preview to maximize paper in available area
  useEffect(() => {
    if (!open || isGeneratingQr) return;

    const scalePreview = () => {
      const wrapper = document.getElementById('bulk-print-preview-wrapper');
      const container = document.getElementById('bulk-print-container');
      if (!wrapper || !container) return;

      const ww = wrapper.clientWidth;
      const wh = wrapper.clientHeight;
      const cw = container.scrollWidth;
      const ch = container.scrollHeight;

      if (cw > 0 && ch > 0 && ww > 0 && wh > 0) {
        const scaleX = (ww * 0.96) / cw;
        const scaleY = (wh * 0.96) / ch;
        const scale = Math.min(1, scaleX, scaleY);
        const inner = container.parentElement;
        if (inner) {
          inner.style.transform = `scale(${scale})`;
          inner.style.transformOrigin = 'center center';
          inner.style.width = `${cw}px`;
          inner.style.height = `${ch}px`;
          inner.style.display = 'flex';
          inner.style.alignItems = 'center';
          inner.style.justifyContent = 'center';
        }
      }
    };

    const timer = setTimeout(scalePreview, 100);
    const timer2 = setTimeout(scalePreview, 300);
    const timer3 = setTimeout(scalePreview, 600);

    window.addEventListener('resize', scalePreview);

    return () => {
      clearTimeout(timer);
      clearTimeout(timer2);
      clearTimeout(timer3);
      window.removeEventListener('resize', scalePreview);
    };
  }, [open, isGeneratingQr, bulkPreviewPage, cardSettings.kartuPerHalaman]);

  const printBulkCards = () => {
    const students = getSelectedStudentsData();
    const perPage = cardSettings.kartuPerHalaman;
    const pages = groupStudentsForPrint(students, perPage);
    const totalPages = pages.length;
    const layout = getGridLayout(perPage);
    const gridRows = Array(layout.rows).fill('1fr').join(' ');

    // Build cards HTML
    let pagesHtml = '';
    pages.forEach((pageStudents, pageIndex) => {
      pagesHtml += `<div class="bulk-print-page" style="width:210mm;height:330mm;padding:${layout.padding};box-sizing:border-box;display:flex;flex-direction:column;background:#fff;page-break-after:${pageIndex < totalPages - 1 ? 'always' : 'auto'};">`;
      pagesHtml += `<div style="text-align:center;margin-bottom:2mm;"><span style="font-size:9px;color:#9ca3af;">Halaman ${pageIndex + 1} &mdash; ${pageStudents.length} kartu</span></div>`;
      pagesHtml += `<div style="flex:1;display:grid;grid-template-columns:repeat(${layout.cols}, 1fr);grid-template-rows:${gridRows};gap:${layout.gap};">`;

      pageStudents.forEach(siswa => {
        const qr = bulkQrCodes[siswa.id] || '';
        const foto = siswa.foto && cardSettings.showFoto
          ? `<img src="${siswa.foto}" style="width:23mm;height:30mm;object-fit:cover;border-radius:4px;border:1px solid #e5e7eb;" />`
          : `<div style="width:23mm;height:30mm;background:#f3f4f6;border-radius:4px;border:1px solid #e5e7eb;display:flex;align-items:center;justify-content:center;color:#9ca3af;"><span style="font-size:6px;">FOTO 3x4</span></div>`;

        const qrHtml = cardSettings.showQR
          ? (qr
            ? `<div style="display:flex;flex-direction:column;align-items:center;flex-shrink:0;"><img src="${qr}" style="width:12mm;height:12mm;" /><span style="font-size:4px;color:#9ca3af;margin-top:1px;">Scan</span></div>`
            : `<div style="width:12mm;height:12mm;background:#f3f4f6;border-radius:4px;display:flex;align-items:center;justify-content:center;color:#d1d5db;">QR</div>`)
          : '';

        const logo = settings_logoHtml(cardSettings);
        const formatDate_ = siswa.tanggalLahir ? new Date(siswa.tanggalLahir).toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '-';

        pagesHtml += `
        <div style="display:flex;align-items:center;justify-content:center;">
          <div class="student-card" style="width:85.6mm;height:53.98mm;background:${cardSettings.warnaBackground || '#fff'};border-radius:6px;overflow:hidden;border:1px solid #e5e7eb;-webkit-print-color-adjust:exact;print-color-adjust:exact;">
            <div style="padding:4px 6px;text-align:center;color:#fff;background:${cardSettings.warnaHeader || '#059669'};-webkit-print-color-adjust:exact;print-color-adjust:exact;">
              <div style="display:flex;align-items:center;justify-content:center;gap:6px;">${logo}<div><div style="font-weight:700;font-size:8px;line-height:1.2;">KARTU PELAJAR</div><div style="font-size:6px;opacity:0.9;line-height:1.2;">${sekolah?.nama || 'Nama Sekolah'}</div></div></div>
            </div>
            <div style="padding:6px 8px;display:flex;gap:6px;">
              ${foto}
              <div style="flex:1;font-size:7px;">
                <table style="width:100%;border-collapse:collapse;">
                  <tr><td style="color:#6b7280;padding:2px 0;width:40px;">Nama</td><td style="color:#111827;font-weight:500;padding:2px 0;">: ${siswa.nama}</td></tr>
                  <tr><td style="color:#6b7280;padding:2px 0;">NIS</td><td style="color:#111827;padding:2px 0;">: ${siswa.nis}</td></tr>
                  <tr><td style="color:#6b7280;padding:2px 0;">NISN</td><td style="color:#111827;padding:2px 0;">: ${siswa.nisn || '-'}</td></tr>
                  <tr><td style="color:#6b7280;padding:2px 0;">Kelas</td><td style="color:#111827;padding:2px 0;">: ${siswa.kelas?.nama || '-'}</td></tr>
                  <tr><td style="color:#6b7280;padding:2px 0;">TTL</td><td style="color:#111827;padding:2px 0;">: ${siswa.tempatLahir || '-'}, ${formatDate_}</td></tr>
                  <tr><td style="color:#6b7280;padding:2px 0;">Alamat</td><td style="color:#111827;padding:2px 0;max-width:40mm;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">: ${siswa.alamat || '-'}</td></tr>
                </table>
              </div>
              ${qrHtml}
            </div>
            <div style="padding:2px 8px 6px;">
              <div style="display:flex;justify-content:space-between;align-items:flex-end;border-top:1px solid #e5e7eb;padding-top:4px;">
                <div style="font-size:6px;color:#6b7280;"><div>TA: ${cardSettings.tahunAjaran || '2024/2025'}</div><div>Berlaku: ${cardSettings.berlakuSampai || 'Juli 2025'}</div></div>
                <div style="text-align:center;"><div style="font-size:6px;color:#6b7280;">Kepala Sekolah</div><div style="height:12mm;"></div><div style="font-size:7px;font-weight:500;color:#111827;">${cardSettings.namaKepalaSekolah || '________________'}</div><div style="font-size:5px;color:#6b7280;">${cardSettings.nipKepalaSekolah ? 'NIP. ' + cardSettings.nipKepalaSekolah : ''}</div></div>
              </div>
            </div>
          </div>
        </div>`;
      });

      // Empty slots
      if (pageStudents.length < perPage) {
        for (let i = pageStudents.length; i < perPage; i++) {
          pagesHtml += `<div style="display:flex;align-items:center;justify-content:center;"><div style="width:85.6mm;height:53.98mm;"></div></div>`;
        }
      }

      pagesHtml += `</div></div>`;
    });

    // Open new window with print content
    const printWindow = window.open('', '_blank', 'width=900,height=700');
    if (!printWindow) {
      toast({ variant: 'destructive', title: 'Error', description: 'Pop-up diblokir. Izinkan pop-up untuk mencetak.' });
      return;
    }

    printWindow.document.write(`<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8"/>
  <title>Cetak Kartu Pelajar</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { background: #f8fafc; }
    .bulk-print-page {
      margin: 0 auto 10px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .student-card, .student-card * {
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    @media print {
      body { background: none; }
      .bulk-print-page {
        margin: 0;
        box-shadow: none;
        page-break-after: always;
      }
      .bulk-print-page:last-child {
        page-break-after: auto;
      }
      @page { size: 210mm 330mm; margin: 0; }
    }
    @media screen {
      .bulk-print-page {
        transform-origin: top center;
      }
    }
  </style>
</head>
<body>
  ${pagesHtml}
  <script>
    // Auto-scale pages on screen
    function scalePages() {
      const pages = document.querySelectorAll('.bulk-print-page');
      pages.forEach(page => {
        const vw = window.innerWidth - 40;
        const pw = 210 * 3.7795275591; // mm to px
        const scale = Math.min(1, vw / pw);
        page.style.transform = 'scale(' + scale + ')';
        page.style.transformOrigin = 'top center';
        page.style.width = (210 * 3.7795275591 * scale) + 'px';
      });
    }
    window.addEventListener('resize', scalePages);
    scalePages();
    window.onload = function() {
      scalePages();
      setTimeout(() => window.print(), 600);
    };
  </script>
</body>
</html>`);
    printWindow.document.close();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900 border-slate-700 text-white w-[96vw] max-w-[96vw] h-[96vh] max-h-[96vh] flex flex-col p-0 overflow-hidden gap-0">
        {/* Compact Header with VisuallyHidden Title for accessibility */}
        <DialogTitle className="sr-only">Cetak Massal Kartu Pelajar</DialogTitle>
        <div className="flex-shrink-0 flex items-center justify-between px-5 py-2.5 border-b border-slate-700">
          <div className="flex items-center gap-2">
            <CheckSquare className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-semibold text-white">Cetak Massal Kartu Pelajar</span>
            <span className="text-xs text-slate-500 ml-2">
              {selectedStudentIds.length} kartu &middot; F4 ({cardSettings.kartuPerHalaman}/hal) &middot; {totalPrintPages} hal
            </span>
          </div>
          <div className="flex items-center gap-4">
            {/* Kartu per halaman toggle */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-slate-500">Kartu/hal:</span>
              <div className="flex bg-slate-800 rounded-md p-0.5">
                {([6, 8, 10] as const).map((num) => (
                  <button
                    key={num}
                    onClick={() => setCardSettings(prev => ({ ...prev, kartuPerHalaman: num }))}
                    className={`px-2.5 py-1 text-xs font-medium rounded transition-all ${
                      cardSettings.kartuPerHalaman === num
                        ? 'bg-emerald-500 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white hover:bg-slate-700'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {isGeneratingQr ? (
          <div className="flex flex-col items-center py-12">
            <RefreshCw className="w-12 h-12 animate-spin text-emerald-500 mb-4" />
            <p className="text-slate-400">Mempersiapkan QR Code...</p>
          </div>
        ) : (
          <>
            {/* Preview area - maximized */}
            <div
              className="flex-1 flex items-center justify-center overflow-hidden relative"
              id="bulk-print-preview-wrapper"
              style={{ background: '#1e293b', padding: '12px' }}
            >
              <div style={{ transformOrigin: 'center center' }}>
                <div id="bulk-print-container" style={{ boxShadow: '0 4px 24px rgba(0,0,0,0.4)', borderRadius: '2px' }}>
                  {(() => {
                    const pages = groupStudentsForPrint(getSelectedStudentsData());
                    const currentPage = pages[bulkPreviewPage - 1];
                    if (!currentPage) return null;
                    return (
                      <BulkPrintPage
                        students={currentPage}
                        sekolah={sekolah}
                        qrCodes={bulkQrCodes}
                        settings={cardSettings}
                        pageNumber={bulkPreviewPage}
                      />
                    );
                  })()}
                </div>
              </div>
            </div>

            {/* Page Navigation & Action Buttons - compact */}
            <div className="flex items-center justify-between px-5 py-2.5 border-t border-slate-700 flex-shrink-0">
              {/* Page Navigation */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setBulkPreviewPage(p => Math.max(1, p - 1))}
                  disabled={bulkPreviewPage <= 1}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-md bg-slate-800 border border-slate-600 text-slate-300 hover:text-white hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                  ← Prev
                </button>
                <span className="text-xs text-slate-400 min-w-[60px] text-center">
                  Hal {bulkPreviewPage} / {totalPrintPages}
                </span>
                <button
                  onClick={() => setBulkPreviewPage(p => Math.min(totalPrintPages, p + 1))}
                  disabled={bulkPreviewPage >= totalPrintPages}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-md bg-slate-800 border border-slate-600 text-slate-300 hover:text-white hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                  Next →
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button
                  onClick={printBulkCards}
                  size="sm"
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
                >
                  <Printer className="w-4 h-4 mr-2" />
                  Cetak {selectedStudentIds.length} Kartu
                </Button>
                <Button
                  variant="outline"
                  onClick={() => onOpenChange(false)}
                  className="bg-slate-700/50 border-slate-600 text-white"
                >
                  Tutup
                </Button>
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ============== SISWA FORM DIALOG ==============

interface SiswaFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: 'add' | 'edit';
  siswa: SiswaWithDetails | null;
  kelasList: Kelas[];
  selectedSekolah: Sekolah;
  onSuccess: () => void;
}

export function SiswaFormDialog({
  open,
  onOpenChange,
  mode,
  siswa,
  kelasList,
  selectedSekolah,
  onSuccess,
}: SiswaFormDialogProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState<FormData>({
    nis: '',
    nisn: '',
    nama: '',
    jenisKelamin: 'L',
    tempatLahir: '',
    tanggalLahir: '',
    alamat: '',
    kelasId: '',
    namaAyah: '',
    pekerjaanAyah: '',
    phoneAyah: '',
    namaIbu: '',
    pekerjaanIbu: '',
    phoneIbu: '',
    namaWali: '',
    phoneWali: '',
    foto: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);

  // Populate form when dialog opens
  useEffect(() => {
    if (open) {
      if (mode === 'add') {
        setFormData({
          nis: '',
          nisn: '',
          nama: '',
          jenisKelamin: 'L',
          tempatLahir: '',
          tanggalLahir: '',
          alamat: '',
          kelasId: kelasList[0]?.id || '',
          namaAyah: '',
          pekerjaanAyah: '',
          phoneAyah: '',
          namaIbu: '',
          pekerjaanIbu: '',
          phoneIbu: '',
          namaWali: '',
          phoneWali: '',
          foto: ''
        });
      } else if (siswa) {
        setFormData({
          nis: siswa.nis || '',
          nisn: siswa.nisn || '',
          nama: siswa.nama || '',
          jenisKelamin: (siswa.jenisKelamin as 'L' | 'P') || 'L',
          tempatLahir: siswa.tempatLahir || '',
          tanggalLahir: siswa.tanggalLahir ? new Date(siswa.tanggalLahir).toISOString().split('T')[0] : '',
          alamat: siswa.alamat || '',
          kelasId: siswa.kelas?.id || '',
          namaAyah: (siswa as any).namaAyah || '',
          pekerjaanAyah: (siswa as any).pekerjaanAyah || '',
          phoneAyah: siswa.phoneAyah || '',
          namaIbu: (siswa as any).namaIbu || '',
          pekerjaanIbu: (siswa as any).pekerjaanIbu || '',
          phoneIbu: siswa.phoneIbu || '',
          namaWali: (siswa as any).namaWali || '',
          phoneWali: siswa.phoneWali || '',
          foto: siswa.foto || ''
        });
      }
    }
  }, [open, mode, siswa]); // eslint-disable-line react-hooks/exhaustive-deps

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, foto: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedSekolah) return;

    setIsSubmitting(true);

    try {
      if (mode === 'add') {
        const res = await fetch('/api/siswa', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...formData,
            sekolahId: selectedSekolah.id
          })
        });

        const data = await res.json();

        if (data.success) {
          toast({
            title: 'Berhasil',
            description: 'Siswa berhasil ditambahkan',
          });
          onOpenChange(false);
          onSuccess();
        } else {
          toast({
            variant: 'destructive',
            title: 'Gagal',
            description: data.message || 'Terjadi kesalahan',
          });
        }
      } else {
        // Edit mode
        const res = await fetch(`/api/siswa/${siswa?.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });

        const data = await res.json();

        if (data.success) {
          toast({
            title: 'Berhasil',
            description: 'Data siswa berhasil diperbarui',
          });
          onOpenChange(false);
          onSuccess();
        } else {
          toast({
            variant: 'destructive',
            title: 'Gagal',
            description: data.message || 'Terjadi kesalahan',
          });
        }
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Tambah Siswa Baru' : 'Edit Data Siswa'}</DialogTitle>
          <DialogDescription className="text-slate-400">
            {mode === 'add' ? 'Isi data siswa baru' : 'Perbarui data siswa'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Data Pribadi */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-emerald-400">Data Pribadi</h4>

            {/* Photo Upload */}
            <div className="space-y-2">
              <Label className="text-slate-300">Foto Siswa</Label>
              <div className="flex items-center gap-4">
                {formData.foto ? (
                  <div className="relative">
                    <img
                      src={formData.foto}
                      alt="Preview"
                      className="w-24 h-32 object-cover rounded-lg border-2 border-slate-600"
                    />
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() => setFormData(prev => ({ ...prev, foto: '' }))}
                      className="absolute -top-2 -right-2 w-6 h-6 p-0 bg-red-500 border-red-500 text-white hover:bg-red-600"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => photoInputRef.current?.click()}
                    className="w-24 h-32 border-2 border-dashed border-slate-600 rounded-lg flex flex-col items-center justify-center text-slate-400 hover:border-emerald-500 hover:text-emerald-400 transition-colors"
                  >
                    <ImagePlus className="w-8 h-8 mb-1" />
                    <span className="text-xs">Upload Foto</span>
                  </button>
                )}
                <input
                  ref={photoInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
                <div className="text-xs text-slate-400">
                  <p>Format: JPG, PNG</p>
                  <p>Ukuran: Maks 2MB</p>
                  <p>Resolusi: 3x4 (disarankan)</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-slate-300">NIS *</Label>
                <Input
                  value={formData.nis}
                  onChange={(e) => setFormData({...formData, nis: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white"
                  required
                />
              </div>
              <div className="space-y-1">
                <Label className="text-slate-300">NISN</Label>
                <Input
                  value={formData.nisn}
                  onChange={(e) => setFormData({...formData, nisn: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-slate-300">Nama Lengkap *</Label>
              <Input
                value={formData.nama}
                onChange={(e) => setFormData({...formData, nama: e.target.value})}
                className="bg-slate-700/50 border-slate-600 text-white"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-slate-300">Jenis Kelamin</Label>
                <Select
                  value={formData.jenisKelamin}
                  onValueChange={(v) => setFormData({...formData, jenisKelamin: v as 'L' | 'P'})}
                >
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="L" className="text-white">Laki-laki</SelectItem>
                    <SelectItem value="P" className="text-white">Perempuan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-slate-300">Kelas *</Label>
                <Select
                  value={formData.kelasId}
                  onValueChange={(v) => setFormData({...formData, kelasId: v})}
                >
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Pilih kelas" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {kelasList.map((k) => (
                      <SelectItem key={k.id} value={k.id} className="text-white">{k.nama}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-slate-300">Tempat Lahir</Label>
                <Input
                  value={formData.tempatLahir}
                  onChange={(e) => setFormData({...formData, tempatLahir: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-slate-300">Tanggal Lahir</Label>
                <Input
                  type="date"
                  value={formData.tanggalLahir}
                  onChange={(e) => setFormData({...formData, tanggalLahir: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-slate-300">Alamat</Label>
              <Input
                value={formData.alamat}
                onChange={(e) => setFormData({...formData, alamat: e.target.value})}
                className="bg-slate-700/50 border-slate-600 text-white"
              />
            </div>
          </div>

          {/* Data Orang Tua */}
          <div className="space-y-3 pt-2 border-t border-slate-700">
            <h4 className="text-sm font-semibold text-emerald-400">Data Ayah</h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-slate-300">Nama Ayah</Label>
                <Input
                  value={formData.namaAyah}
                  onChange={(e) => setFormData({...formData, namaAyah: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-slate-300">Pekerjaan</Label>
                <Input
                  value={formData.pekerjaanAyah}
                  onChange={(e) => setFormData({...formData, pekerjaanAyah: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-slate-300">No. HP Ayah</Label>
              <Input
                value={formData.phoneAyah}
                onChange={(e) => setFormData({...formData, phoneAyah: e.target.value})}
                className="bg-slate-700/50 border-slate-600 text-white"
                placeholder="08xxxxxxxxxx"
              />
            </div>
          </div>

          <div className="space-y-3 pt-2 border-t border-slate-700">
            <h4 className="text-sm font-semibold text-emerald-400">Data Ibu</h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-slate-300">Nama Ibu</Label>
                <Input
                  value={formData.namaIbu}
                  onChange={(e) => setFormData({...formData, namaIbu: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-slate-300">Pekerjaan</Label>
                <Input
                  value={formData.pekerjaanIbu}
                  onChange={(e) => setFormData({...formData, pekerjaanIbu: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-slate-300">No. HP Ibu</Label>
              <Input
                value={formData.phoneIbu}
                onChange={(e) => setFormData({...formData, phoneIbu: e.target.value})}
                className="bg-slate-700/50 border-slate-600 text-white"
                placeholder="08xxxxxxxxxx"
              />
            </div>
          </div>

          <div className="space-y-3 pt-2 border-t border-slate-700">
            <h4 className="text-sm font-semibold text-emerald-400">Data Wali (Opsional)</h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-slate-300">Nama Wali</Label>
                <Input
                  value={formData.namaWali}
                  onChange={(e) => setFormData({...formData, namaWali: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-slate-300">No. HP Wali</Label>
                <Input
                  value={formData.phoneWali}
                  onChange={(e) => setFormData({...formData, phoneWali: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white"
                  placeholder="08xxxxxxxxxx"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="bg-slate-700/50 border-slate-600 text-white"
            >
              Batal
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Menyimpan...
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4 mr-2" />
                  {mode === 'add' ? 'Tambah' : 'Simpan'}
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ============== DELETE SISWA DIALOG ==============

interface DeleteSiswaDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  siswa: SiswaWithDetails | null;
  onSuccess: () => void;
}

export function DeleteSiswaDialog({ open, onOpenChange, siswa, onSuccess }: DeleteSiswaDialogProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleDelete = async () => {
    if (!siswa) return;

    setIsSubmitting(true);

    try {
      const res = await fetch(`/api/siswa/${siswa.id}`, {
        method: 'DELETE'
      });

      const data = await res.json();

      if (data.success) {
        toast({
          title: 'Berhasil',
          description: 'Siswa berhasil dihapus',
        });
        onOpenChange(false);
        onSuccess();
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message || 'Terjadi kesalahan',
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-800 border-slate-700 text-white">
        <DialogHeader>
          <DialogTitle className="text-red-400">Hapus Siswa</DialogTitle>
          <DialogDescription className="text-slate-400">
            Apakah Anda yakin ingin menghapus siswa <strong className="text-white">{siswa?.nama}</strong>?
            Semua data absensi terkait juga akan dihapus. Tindakan ini tidak dapat dibatalkan.
          </DialogDescription>
        </DialogHeader>
        <div className="flex justify-end gap-3 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="bg-slate-700/50 border-slate-600 text-white"
          >
            Batal
          </Button>
          <Button
            onClick={handleDelete}
            disabled={isSubmitting}
            className="bg-red-500 hover:bg-red-600"
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Menghapus...
              </>
            ) : (
              <>
                <Trash2 className="w-4 h-4 mr-2" />
                Hapus
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============== IMPORT SISWA DIALOG ==============

interface ImportSiswaDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedSekolah: Sekolah;
  onSuccess: () => void;
  downloadTemplate: () => void;
}

export function ImportSiswaDialog({
  open,
  onOpenChange,
  selectedSekolah,
  onSuccess,
  downloadTemplate,
}: ImportSiswaDialogProps) {
  const { toast } = useToast();
  const [importFile, setImportFile] = useState<File | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);

  const handleImport = async () => {
    if (!importFile || !selectedSekolah) return;

    setIsImporting(true);
    setImportResult(null);

    try {
      const formData = new FormData();
      formData.append('file', importFile);
      formData.append('sekolahId', selectedSekolah.id);

      const res = await fetch('/api/siswa/import', {
        method: 'POST',
        body: formData
      });

      const data = await res.json();

      if (data.success) {
        setImportResult(data.data);
        onSuccess();

        if (data.data.failed === 0) {
          toast({
            title: 'Import Berhasil',
            description: `${data.data.success} data siswa berhasil diimport`,
          });
        }
      } else {
        toast({
          variant: 'destructive',
          title: 'Import Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan saat import',
      });
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => {
      if (!v) {
        setImportFile(null);
        setImportResult(null);
      }
      onOpenChange(v);
    }}>
      <DialogContent className="bg-slate-800 border-slate-700 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Upload className="w-5 h-5 text-emerald-400" />
            Import Data Siswa
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Import data siswa dari file Excel (.xlsx)
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 bg-slate-700/30 rounded-xl space-y-3">
            <p className="text-sm text-slate-300 font-medium">Petunjuk:</p>
            <ol className="text-sm text-slate-400 space-y-1 list-decimal list-inside">
              <li>Download template terlebih dahulu</li>
              <li>Isi data siswa sesuai format template</li>
              <li>Hapus baris contoh sebelum upload</li>
              <li>Pastikan nama Kelas sudah sesuai</li>
            </ol>

            <Button
              variant="outline"
              size="sm"
              onClick={downloadTemplate}
              className="w-full bg-slate-700/50 border-slate-600 text-emerald-400 hover:text-emerald-300 hover:bg-slate-700"
            >
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Download Template Excel
            </Button>
          </div>

          <div className="space-y-2">
            <Label className="text-slate-300">Pilih File Excel</Label>
            <div className="border-2 border-dashed border-slate-600 rounded-xl p-6 text-center">
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    setImportFile(file);
                    setImportResult(null);
                  }
                }}
                className="hidden"
                id="import-file"
              />
              <label
                htmlFor="import-file"
                className="cursor-pointer flex flex-col items-center gap-2"
              >
                <Upload className="w-10 h-10 text-slate-500" />
                {importFile ? (
                  <span className="text-sm text-emerald-400">{importFile.name}</span>
                ) : (
                  <span className="text-sm text-slate-400">Klik untuk memilih file</span>
                )}
                <span className="text-xs text-slate-500">Format: .xlsx, .xls</span>
              </label>
            </div>
          </div>

          {/* Import Result */}
          {importResult && (
            <div className={`p-4 rounded-xl ${importResult.failed > 0 ? 'bg-amber-500/20 border border-amber-500/30' : 'bg-emerald-500/20 border border-emerald-500/30'}`}>
              <div className="flex items-center gap-2 mb-2">
                {importResult.failed > 0 ? (
                  <AlertCircle className="w-5 h-5 text-amber-400" />
                ) : (
                  <CheckCircle className="w-5 h-5 text-emerald-400" />
                )}
                <span className={`font-medium ${importResult.failed > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  Import Selesai
                </span>
              </div>
              <p className="text-sm text-slate-300 mb-2">
                Berhasil: {importResult.success} | Gagal: {importResult.failed}
              </p>
              {importResult.errors.length > 0 && (
                <div className="max-h-32 overflow-y-auto space-y-1">
                  {importResult.errors.slice(0, 10).map((err, idx) => (
                    <p key={idx} className="text-xs text-red-400">
                      Baris {err.row}: {err.message}
                    </p>
                  ))}
                  {importResult.errors.length > 10 && (
                    <p className="text-xs text-slate-400">
                      ...dan {importResult.errors.length - 10} error lainnya
                    </p>
                  )}
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-700"
            >
              Tutup
            </Button>
            <Button
              onClick={handleImport}
              disabled={!importFile || isImporting}
              className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
            >
              {isImporting ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Mengimport...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Import
                </>
              )}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============== SISWA DIALOGS (WRAPPER) ==============

interface SiswaDialogsProps {
  selectedSekolah: Sekolah;
  kelasList: Kelas[];
  siswaList: SiswaWithDetails[];
  selectedStudents: string[];
  selectedSiswa: SiswaWithDetails | null;
  qrCode: string;
  cardQrCode: string;
  cardSettings: CardSettings;
  setCardSettings: React.Dispatch<React.SetStateAction<CardSettings>>;
  formMode: 'add' | 'edit';
  showQRDialog: boolean;
  showFormDialog: boolean;
  showDeleteDialog: boolean;
  showCardDialog: boolean;
  showBulkPrintDialog: boolean;
  showImportDialog: boolean;
  showCardSettingsDialog: boolean;
  setShowQRDialog: (v: boolean) => void;
  setShowFormDialog: (v: boolean) => void;
  setShowDeleteDialog: (v: boolean) => void;
  setShowCardDialog: (v: boolean) => void;
  setShowBulkPrintDialog: (v: boolean) => void;
  setShowImportDialog: (v: boolean) => void;
  setShowCardSettingsDialog: (v: boolean) => void;
  fetchSiswa: () => void;
  downloadTemplate: () => void;
}

export function SiswaDialogs({
  selectedSekolah,
  kelasList,
  siswaList,
  selectedStudents,
  selectedSiswa,
  qrCode,
  cardQrCode,
  cardSettings,
  setCardSettings,
  formMode,
  showQRDialog,
  showFormDialog,
  showDeleteDialog,
  showCardDialog,
  showBulkPrintDialog,
  showImportDialog,
  showCardSettingsDialog,
  setShowQRDialog,
  setShowFormDialog,
  setShowDeleteDialog,
  setShowCardDialog,
  setShowBulkPrintDialog,
  setShowImportDialog,
  setShowCardSettingsDialog,
  fetchSiswa,
  downloadTemplate,
}: SiswaDialogsProps) {
  return (
    <>
      <QRCodeDialog
        open={showQRDialog}
        onOpenChange={setShowQRDialog}
        siswa={selectedSiswa}
        qrCode={qrCode}
      />
      <CardSettingsDialog
        open={showCardSettingsDialog}
        onOpenChange={setShowCardSettingsDialog}
        cardSettings={cardSettings}
        setCardSettings={setCardSettings}
        selectedSekolah={selectedSekolah}
      />
      <StudentCardDialog
        open={showCardDialog}
        onOpenChange={setShowCardDialog}
        siswa={selectedSiswa}
        sekolah={selectedSekolah}
        qrCode={cardQrCode}
        cardSettings={cardSettings}
      />
      <BulkPrintDialog
        open={showBulkPrintDialog}
        onOpenChange={setShowBulkPrintDialog}
        siswaList={siswaList}
        selectedStudentIds={selectedStudents}
        sekolah={selectedSekolah}
        cardSettings={cardSettings}
        setCardSettings={setCardSettings}
      />
      <SiswaFormDialog
        open={showFormDialog}
        onOpenChange={setShowFormDialog}
        mode={formMode}
        siswa={selectedSiswa}
        kelasList={kelasList}
        selectedSekolah={selectedSekolah}
        onSuccess={fetchSiswa}
      />
      <DeleteSiswaDialog
        open={showDeleteDialog}
        onOpenChange={setShowDeleteDialog}
        siswa={selectedSiswa}
        onSuccess={fetchSiswa}
      />
      <ImportSiswaDialog
        open={showImportDialog}
        onOpenChange={setShowImportDialog}
        selectedSekolah={selectedSekolah}
        onSuccess={fetchSiswa}
        downloadTemplate={downloadTemplate}
      />
    </>
  );
}
