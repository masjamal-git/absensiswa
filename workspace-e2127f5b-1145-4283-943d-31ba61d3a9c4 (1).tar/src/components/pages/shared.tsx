'use client';

// Sound utility
const playSound = (type: 'success' | 'error') => {
  if (typeof window === 'undefined') return;
  
  const sounds = {
    success: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdH2JkY2Jgn15dHx9gISFhYSAfnl0e3x+gIKEhIODgX54c3p7foCCg4SEg4F+eHN6e36AgYOEhIOBfnhzenp9f4CCg4SDgX543t3e3x/gIGCg4OCf3h2eHl7foCBgoODgn94dXh5e36AgYKCgoJ/eHR4eXt+gIGCgoKCf3h0eHl7foCBgoKCgn94dHh5e36AgYKCgoJ/eHR4eXt+gIGCgoKCf3h0eHl7foCBgoKCgn94dHh5e36AgYKCgoJ/eHR4eXt+gIGCgoKCf3h0d3l6fH+BgoKCgX93dHh5eny/gYKCgoF/d3R4eXp8v4GCgoKBf3d0eHl6fL+BgoKCgX93dHh5eny/gYKCgoF/d3R4eXp8v4GCgoKBf3d0eHl6fL+BgoKCgX93dHh5eny/gYKCgoF/d3R4eXp8v4GCgoKBf3d0d3l6fH+BgoKBgX52dHh5eny/gYKCgYF+dnR4eXp8v4GCgoGBfnZ0eHl6fL+BgoKBgX52dHh5eny/gYKCgYF+dnR4eXp8v4GCgoGBfnZ0eHl6fL+BgoKBgX52dHh5eny/gYKCgYF+dnR4eXp8v4GCgoGBfnZ0eHl6fH6BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fH6BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fL+BgoGBgX51c3h5eny/gYKBgYF+dXN4eXp8v4GCgYGBfnVzeHl6fA==',
    error: 'data:audio/wav;base64,UklGRl9vT19teleVm1BBTEFURVh0ZWxldGVsZW1lbnRlbGVtZW50ZWxlbWVudGVsZW1lbnRlbGVtZW50ZWxlbWVudA=='
  };
  
  const audio = new Audio(sounds[type]);
  audio.volume = 0.5;
  audio.play().catch(() => {});
};

export { playSound };
