'use client';

import { useState, useEffect } from 'react';
import { Sekolah, Kelas } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { 
  AlertCircle, CheckCircle, Clock, Heart, ShieldAlert, Ban, Users 
} from 'lucide-react';

export function KehadiranPage({ selectedSekolah }: { selectedSekolah: Sekolah | null }) {
  const { toast } = useToast();
  const [kelasList, setKelasList] = useState<Kelas[]>([]);
  const [selectedKelas, setSelectedKelas] = useState<string>('');
  const [siswaList, setSiswaList] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [tanggal, setTanggal] = useState(() => {
    const d = new Date();
    return d.toISOString().split('T')[0];
  });

  // Fetch kelas list
  useEffect(() => {
    if (!selectedSekolah) return;
    fetch(`/api/kelas?sekolahId=${selectedSekolah.id}`)
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          setKelasList(data.data);
          if (data.data.length > 0) setSelectedKelas(data.data[0].id);
        }
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, [selectedSekolah]);

  // Fetch siswa & their attendance when kelas/tanggal changes
  useEffect(() => {
    if (!selectedSekolah || !selectedKelas || !tanggal) return;
    setIsLoading(true);
    Promise.all([
      fetch(`/api/siswa?sekolahId=${selectedSekolah.id}&kelasId=${selectedKelas}&limit=100`).then(r => r.json()),
      fetch(`/api/absensi?sekolahId=${selectedSekolah.id}&tanggal=${tanggal}&kelasId=${selectedKelas}`).then(r => r.json()),
    ]).then(([siswaData, absensiData]) => {
      if (siswaData.success) {
        const absensiMap: Record<string, any> = {};
        if (absensiData.success) {
          absensiData.data.forEach((a: any) => { absensiMap[a.siswaId] = a; });
        }
        const list = siswaData.data.map((s: any) => ({
          ...s,
          absensi: absensiMap[s.id] || null,
        }));
        setSiswaList(list);
      }
    }).catch(() => {}).finally(() => setIsLoading(false));
  }, [selectedSekolah, selectedKelas, tanggal]);

  const updateStatus = async (siswaId: string, status: string, keterangan?: string) => {
    setIsSaving(true);
    try {
      const res = await fetch('/api/absensi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'manual',
          siswaId,
          sekolahId: selectedSekolah?.id,
          status,
          mode: 'masuk',
          keterangan,
        }),
      });
      const data = await res.json();
      if (data.success) {
        toast({ title: 'Berhasil', description: data.message });
        // Refresh data
        const absensiRes = await fetch(`/api/absensi?sekolahId=${selectedSekolah?.id}&tanggal=${tanggal}&kelasId=${selectedKelas}`);
        const absensiData = await absensiRes.json();
        if (absensiData.success) {
          const absensiMap: Record<string, any> = {};
          absensiData.data.forEach((a: any) => { absensiMap[a.siswaId] = a; });
          setSiswaList(prev => prev.map(s => ({ ...s, absensi: absensiMap[s.id] || null })));
        }
      } else {
        toast({ variant: 'destructive', title: 'Gagal', description: data.message });
      }
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Terjadi kesalahan' });
    } finally {
      setIsSaving(false);
    }
  };

  const statusOptions = [
    { value: 'HADIR', label: 'Hadir', icon: CheckCircle, bg: 'bg-emerald-500/10 border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/20' },
    { value: 'TERLAMBAT', label: 'Terlambat', icon: Clock, bg: 'bg-amber-500/10 border-amber-500/50 text-amber-400 hover:bg-amber-500/20' },
    { value: 'SAKIT', label: 'Sakit', icon: Heart, bg: 'bg-purple-500/10 border-purple-500/50 text-purple-400 hover:bg-purple-500/20' },
    { value: 'IZIN', label: 'Izin', icon: ShieldAlert, bg: 'bg-sky-500/10 border-sky-500/50 text-sky-400 hover:bg-sky-500/20' },
    { value: 'ALPA', label: 'Alpa', icon: Ban, bg: 'bg-red-500/10 border-red-500/50 text-red-400 hover:bg-red-500/20' },
  ];

  // Count stats
  const stats = siswaList.reduce((acc: any, s) => {
    const st = s.absensi?.status || 'BELUM';
    acc[st] = (acc[st] || 0) + 1;
    return acc;
  }, {});

  if (!selectedSekolah) {
    return (
      <div className="flex items-center justify-center h-64">
        <AlertCircle className="w-8 h-8 text-amber-500 mr-3" />
        <p className="text-slate-400">Pilih sekolah terlebih dahulu</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Catat Kehadiran</h2>
          <p className="text-slate-400">Rekap dan catat kehadiran siswa per kelas</p>
        </div>
        <div className="flex items-center gap-3">
          <Input
            type="date"
            value={tanggal}
            onChange={(e) => setTanggal(e.target.value)}
            className="bg-slate-700/50 border-slate-600 text-white w-44"
          />
        </div>
      </div>

      {/* Kelas Selector */}
      <div className="flex flex-wrap gap-2">
        {kelasList.map((k) => (
          <Button
            key={k.id}
            onClick={() => setSelectedKelas(k.id)}
            variant="outline"
            className={selectedKelas === k.id
              ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
              : 'bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-700'
            }
          >
            {k.nama}
          </Button>
        ))}
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
        {[
          { label: 'Total', val: siswaList.length, color: 'text-blue-400', bg: 'bg-blue-500/10' },
          { label: 'Hadir', val: stats.HADIR || 0, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
          { label: 'Terlambat', val: stats.TERLAMBAT || 0, color: 'text-amber-400', bg: 'bg-amber-500/10' },
          { label: 'Sakit', val: stats.SAKIT || 0, color: 'text-purple-400', bg: 'bg-purple-500/10' },
          { label: 'Izin', val: stats.IZIN || 0, color: 'text-sky-400', bg: 'bg-sky-500/10' },
          { label: 'Alpa', val: stats.ALPA || 0, color: 'text-red-400', bg: 'bg-red-500/10' },
        ].map((s) => (
          <div key={s.label} className={`${s.bg} rounded-xl p-3 text-center`}>
            <p className={`text-xl font-bold ${s.color}`}>{s.val}</p>
            <p className="text-xs text-slate-400">{s.label}</p>
          </div>
        ))}
        <div className="bg-slate-700/30 rounded-xl p-3 text-center col-span-3 sm:col-span-6">
          <p className="text-xl font-bold text-slate-400">{stats.BELUM || 0}</p>
          <p className="text-xs text-slate-500">Belum Absen</p>
        </div>
      </div>

      {/* Siswa List */}
      {isLoading ? (
        <div className="space-y-3">
          {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-16 rounded-xl" />)}
        </div>
      ) : siswaList.length === 0 ? (
        <div className="text-center py-12 text-slate-400">
          <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Tidak ada data siswa</p>
        </div>
      ) : (
        <ScrollArea className="max-h-[calc(100vh-360px)]">
          <div className="space-y-2">
            {siswaList.map((siswa) => {
              const currentStatus = siswa.absensi?.status || null;
              return (
                <Card key={siswa.id} className="bg-slate-800/50 border-slate-700/50">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-white truncate">{siswa.nama}</p>
                        <p className="text-xs text-slate-400">{siswa.nis}</p>
                      </div>
                      <div className="flex gap-1.5 flex-shrink-0">
                        {statusOptions.map((opt) => {
                          const isActive = currentStatus === opt.value;
                          const Icon = opt.icon;
                          return (
                            <button
                              key={opt.value}
                              onClick={() => updateStatus(siswa.id, opt.value)}
                              disabled={isSaving}
                              className={`p-2 rounded-lg border transition-all ${isActive ? opt.bg + ' border-opacity-100' : 'border-slate-700/50 text-slate-500 hover:text-slate-300 hover:border-slate-600'}`}
                              title={opt.label}
                            >
                              <Icon className="w-4 h-4" />
                            </button>
                          );
                        })}
                      </div>
                      <Badge className={`text-xs flex-shrink-0 min-w-[80px] justify-center ${
                        currentStatus === 'HADIR' ? 'bg-emerald-500/20 text-emerald-400' :
                        currentStatus === 'TERLAMBAT' ? 'bg-amber-500/20 text-amber-400' :
                        currentStatus === 'SAKIT' ? 'bg-purple-500/20 text-purple-400' :
                        currentStatus === 'IZIN' ? 'bg-sky-500/20 text-sky-400' :
                        currentStatus === 'ALPA' ? 'bg-red-500/20 text-red-400' :
                        'bg-slate-700/50 text-slate-500'
                      }`}>
                        {currentStatus || 'Belum'}
                      </Badge>
                    </div>
                    {siswa.absensi?.keterangan && (
                      <p className="text-xs text-slate-500 mt-1.5 ml-1">Keterangan: {siswa.absensi.keterangan}</p>
                    )}
                    {siswa.absensi?.jamMasuk && (
                      <p className="text-xs text-slate-500 ml-1">
                        Jam: {new Date(siswa.absensi.jamMasuk).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} • {siswa.absensi.metode}
                      </p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
