'use client';

import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { 
  Search, UserPlus, Users, Edit, Trash2, RefreshCw, MoreVertical, 
  Eye, EyeOff, UserCheck, KeyRound 
} from 'lucide-react';

// ============== USERS PAGE ==============
interface UserData {
  id: string;
  email: string;
  nama: string;
  role: string;
  phone: string | null;
  avatar: string | null;
  isActive: boolean;
  lastLogin: string | null;
  createdAt: string;
  yayasanId: string | null;
  sekolahId: string | null;
  yayasan: { id: string; nama: string } | null;
  sekolah: { id: string; nama: string } | null;
}

export function PenggunaPage() {
  const { toast } = useToast();
  const [users, setUsers] = useState<UserData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [showDialog, setShowDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showResetPasswordDialog, setShowResetPasswordDialog] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formMode, setFormMode] = useState<'add' | 'edit'>('add');
  const [selectedUser, setSelectedUser] = useState<UserData | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    nama: '',
    role: 'OPERATOR',
    phone: '',
    yayasanId: '',
    sekolahId: '',
    isActive: true
  });
  
  const [sekolahList, setSekolahList] = useState<{id: string; nama: string}[]>([]);
  
  useEffect(() => {
    fetchUsers();
    fetchSekolah();
  }, []);
  
  const fetchUsers = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/user');
      const data = await res.json();
      
      if (data.success) {
        setUsers(data.data);
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal memuat data user',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const fetchSekolah = async () => {
    try {
      const res = await fetch('/api/sekolah');
      const data = await res.json();
      
      if (data.success) {
        setSekolahList(data.data.map((s: any) => ({ id: s.id, nama: s.nama })));
      }
    } catch {
      console.error('Failed to load sekolah');
    }
  };
  
  const openAddDialog = () => {
    setFormMode('add');
    setFormData({
      email: '',
      password: '',
      nama: '',
      role: 'OPERATOR',
      phone: '',
      yayasanId: '',
      sekolahId: '',
      isActive: true
    });
    setShowPassword(false);
    setShowDialog(true);
  };
  
  const openEditDialog = (user: UserData) => {
    setFormMode('edit');
    setSelectedUser(user);
    setFormData({
      email: user.email,
      password: '',
      nama: user.nama,
      role: user.role,
      phone: user.phone || '',
      yayasanId: user.yayasanId || '',
      sekolahId: user.sekolahId || '',
      isActive: user.isActive
    });
    setShowPassword(false);
    setShowDialog(true);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const url = formMode === 'add' ? '/api/user' : `/api/user/${selectedUser?.id}`;
      const method = formMode === 'add' ? 'POST' : 'PUT';
      
      const body: any = {
        email: formData.email,
        nama: formData.nama,
        role: formData.role,
        phone: formData.phone || null,
        isActive: formData.isActive
      };
      
      if (formData.password) {
        body.password = formData.password;
      }
      
      if (formData.role === 'ADMIN_SEKOLAH' || formData.role === 'GURU' || formData.role === 'OPERATOR') {
        body.sekolahId = formData.sekolahId || null;
      }
      
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({
          title: 'Berhasil',
          description: formMode === 'add' ? 'User berhasil ditambahkan' : 'User berhasil diperbarui',
        });
        setShowDialog(false);
        fetchUsers();
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan',
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleDelete = async () => {
    if (!selectedUser) return;
    
    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/user/${selectedUser.id}`, {
        method: 'DELETE'
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({
          title: 'Berhasil',
          description: 'User berhasil dihapus',
        });
        setShowDeleteDialog(false);
        fetchUsers();
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan',
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleResetPassword = async () => {
    if (!selectedUser || !newPassword) return;
    
    if (newPassword.length < 6) {
      toast({
        variant: 'destructive',
        title: 'Gagal',
        description: 'Password minimal 6 karakter',
      });
      return;
    }
    
    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/user/${selectedUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: newPassword })
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({
          title: 'Berhasil',
          description: `Password ${selectedUser.nama} berhasil direset`,
        });
        setShowResetPasswordDialog(false);
        setNewPassword('');
        setSelectedUser(null);
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan',
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const openResetPasswordDialog = (user: UserData) => {
    setSelectedUser(user);
    setNewPassword('');
    setShowNewPassword(false);
    setShowResetPasswordDialog(true);
  };
  
  const getRoleBadge = (role: string) => {
    const colors: Record<string, string> = {
      'SUPER_ADMIN': 'bg-red-500/20 text-red-400 border-red-500/30',
      'ADMIN_SEKOLAH': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
      'GURU': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      'OPERATOR': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
    };
    return colors[role] || 'bg-slate-500/20 text-slate-400 border-slate-500/30';
  };
  
  const getRoleLabel = (role: string) => {
    const labels: Record<string, string> = {
      'SUPER_ADMIN': 'Super Admin',
      'ADMIN_SEKOLAH': 'Admin Sekolah',
      'GURU': 'Guru',
      'OPERATOR': 'Operator'
    };
    return labels[role] || role;
  };
  
  const filteredUsers = users.filter(user => {
    const matchesSearch = user.nama.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    return matchesSearch && matchesRole;
  });
  
  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Manajemen User</h2>
          <p className="text-slate-400">Kelola username login dan hak akses</p>
        </div>
        <Button 
          onClick={openAddDialog}
          className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
        >
          <UserPlus className="w-4 h-4 mr-2" />
          Tambah User
        </Button>
      </div>
      
      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            type="text"
            placeholder="Cari nama atau email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
          />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-full md:w-48 bg-slate-800/50 border-slate-700 text-white">
            <SelectValue placeholder="Filter Role" />
          </SelectTrigger>
          <SelectContent className="bg-slate-800 border-slate-700">
            <SelectItem value="all" className="text-white hover:bg-slate-700">Semua Role</SelectItem>
            <SelectItem value="SUPER_ADMIN" className="text-white hover:bg-slate-700">Super Admin</SelectItem>
            <SelectItem value="ADMIN_SEKOLAH" className="text-white hover:bg-slate-700">Admin Sekolah</SelectItem>
            <SelectItem value="GURU" className="text-white hover:bg-slate-700">Guru</SelectItem>
            <SelectItem value="OPERATOR" className="text-white hover:bg-slate-700">Operator</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {/* Users Table */}
      <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-16 rounded-xl" />
              ))}
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Users className="w-16 h-16 text-slate-600 mb-4" />
              <p className="text-slate-400 text-lg">Tidak ada data user</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-slate-700 hover:bg-slate-700/30">
                  <TableHead className="text-slate-400">User</TableHead>
                  <TableHead className="text-slate-400">Role</TableHead>
                  <TableHead className="text-slate-400">Sekolah</TableHead>
                  <TableHead className="text-slate-400">Status</TableHead>
                  <TableHead className="text-slate-400">Terakhir Login</TableHead>
                  <TableHead className="text-slate-400 text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id} className="border-slate-700 hover:bg-slate-700/30">
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                            {user.nama.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-white">{user.nama}</p>
                          <p className="text-sm text-slate-400">{user.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getRoleBadge(user.role)}>
                        {getRoleLabel(user.role)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-slate-300">
                      {user.sekolah?.nama || (user.role === 'SUPER_ADMIN' ? 'Semua Sekolah' : '-')}
                    </TableCell>
                    <TableCell>
                      {user.isActive ? (
                        <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                          Aktif
                        </Badge>
                      ) : (
                        <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                          Nonaktif
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-slate-400">
                      {user.lastLogin ? format(new Date(user.lastLogin), 'dd MMM yyyy, HH:mm', { locale: id }) : 'Belum pernah'}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                          <DropdownMenuItem 
                            onClick={() => openEditDialog(user)}
                            className="text-slate-300 hover:text-white hover:bg-slate-700"
                          >
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => openResetPasswordDialog(user)}
                            className="text-amber-400 hover:text-amber-300 hover:bg-amber-500/10"
                          >
                            <KeyRound className="w-4 h-4 mr-2" />
                            Reset Password
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => { setSelectedUser(user); setShowDeleteDialog(true); }}
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      
      {/* Role Info Card */}
      <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-emerald-400" />
            Keterangan Hak Akses
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-slate-700/30 rounded-xl">
              <Badge className="bg-red-500/20 text-red-400 border-red-500/30 mb-2">Super Admin</Badge>
              <p className="text-sm text-slate-400">Akses penuh ke semua fitur, semua sekolah, dan manajemen user</p>
            </div>
            <div className="p-4 bg-slate-700/30 rounded-xl">
              <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 mb-2">Admin Sekolah</Badge>
              <p className="text-sm text-slate-400">Kelola data sekolah, tahun ajaran, siswa, dan laporan</p>
            </div>
            <div className="p-4 bg-slate-700/30 rounded-xl">
              <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 mb-2">Guru</Badge>
              <p className="text-sm text-slate-400">Dashboard, scan QR masuk/pulang, data siswa, dan laporan</p>
            </div>
            <div className="p-4 bg-slate-700/30 rounded-xl">
              <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 mb-2">Operator</Badge>
              <p className="text-sm text-slate-400">Dashboard, scan QR, data siswa, dan cetak laporan</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Add/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-slate-800 border-slate-700 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">
              {formMode === 'add' ? 'Tambah User Baru' : 'Edit User'}
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              {formMode === 'add' ? 'Masukkan data user baru' : 'Perbarui data user'}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Nama Lengkap</Label>
              <Input
                value={formData.nama}
                onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                placeholder="Nama lengkap"
                required
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-slate-300">Email</Label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="email@sekolah.sch.id"
                required
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-slate-300">
                Password {formMode === 'edit' && '(kosongkan jika tidak diubah)'}
              </Label>
              <div className="relative">
                <Input
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="••••••••"
                  required={formMode === 'add'}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-slate-300">Role</Label>
              <Select 
                value={formData.role} 
                onValueChange={(value) => setFormData({ ...formData, role: value })}
              >
                <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                  <SelectValue placeholder="Pilih role" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="SUPER_ADMIN" className="text-white hover:bg-slate-700">Super Admin</SelectItem>
                  <SelectItem value="ADMIN_SEKOLAH" className="text-white hover:bg-slate-700">Admin Sekolah</SelectItem>
                  <SelectItem value="GURU" className="text-white hover:bg-slate-700">Guru</SelectItem>
                  <SelectItem value="OPERATOR" className="text-white hover:bg-slate-700">Operator</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {(formData.role === 'ADMIN_SEKOLAH' || formData.role === 'GURU' || formData.role === 'OPERATOR') && (
              <div className="space-y-2">
                <Label className="text-slate-300">Sekolah</Label>
                <Select 
                  value={formData.sekolahId} 
                  onValueChange={(value) => setFormData({ ...formData, sekolahId: value })}
                >
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Pilih sekolah" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {sekolahList.map((s) => (
                      <SelectItem key={s.id} value={s.id} className="text-white hover:bg-slate-700">
                        {s.nama}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div className="space-y-2">
              <Label className="text-slate-300">No. Telepon</Label>
              <Input
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="08xxxxxxxxxx"
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Checkbox
                id="isActive"
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked as boolean })}
              />
              <Label htmlFor="isActive" className="text-slate-300">User aktif</Label>
            </div>
            
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowDialog(false)}
                className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-700"
              >
                Batal
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Menyimpan...
                  </>
                ) : (
                  'Simpan'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white">Hapus User</DialogTitle>
            <DialogDescription className="text-slate-400">
              Apakah Anda yakin ingin menghapus user "{selectedUser?.nama}"? 
              Tindakan ini tidak dapat dibatalkan.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowDeleteDialog(false)}
              className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-700"
            >
              Batal
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Menghapus...
                </>
              ) : (
                'Hapus'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Reset Password Dialog */}
      <Dialog open={showResetPasswordDialog} onOpenChange={setShowResetPasswordDialog}>
        <DialogContent className="bg-slate-800 border-slate-700 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-amber-400" />
              Reset Password
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Reset password untuk user "{selectedUser?.nama}"
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Password Baru</Label>
              <div className="relative">
                <Input
                  type={showNewPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Minimal 6 karakter"
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowResetPasswordDialog(false)}
                className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-700"
              >
                Batal
              </Button>
              <Button
                onClick={handleResetPassword}
                disabled={isSubmitting || !newPassword || newPassword.length < 6}
                className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Menyimpan...
                  </>
                ) : (
                  <>
                    <KeyRound className="w-4 h-4 mr-2" />
                    Reset Password
                  </>
                )}
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
