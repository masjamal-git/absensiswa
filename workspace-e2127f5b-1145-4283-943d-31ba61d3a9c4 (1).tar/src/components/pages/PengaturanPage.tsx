'use client';

import { useState, useEffect } from 'react';
import { Sekolah } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';

import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { 
  LogIn, LogOut, Clock, CheckCircle, RefreshCw, Phone, Globe, 
  Eye, EyeOff, Send, BookOpen, FileSpreadsheet, X, AlertCircle 
} from 'lucide-react';

// ============== PENGATURAN PAGE ==============
export function PengaturanPage({ selectedSekolah, setSelectedSekolah }: { 
  selectedSekolah: Sekolah | null;
  setSelectedSekolah: (sekolah: Sekolah | null) => void;
}) {
  const { toast } = useToast();
  const [whatsappSettings, setWhatsappSettings] = useState<{
    provider: string;
    apiKey: string;
    hasApiKey: boolean;
    isActive: boolean;
    notifMasuk: boolean;
    notifPulang: boolean;
    isConfigured: boolean;
  } | null>(null);
  const [testPhone, setTestPhone] = useState('');
  const [isSendingTest, setIsSendingTest] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [notifMasuk, setNotifMasuk] = useState(true);
  const [notifPulang, setNotifPulang] = useState(true);
  
  // Template pesan WhatsApp state
  const [templateMasuk, setTemplateMasuk] = useState('');
  const [templatePulang, setTemplatePulang] = useState('');
  const [templateLoading, setTemplateLoading] = useState(false);
  const [templateSaving, setTemplateSaving] = useState(false);
  const [showPreviewMasuk, setShowPreviewMasuk] = useState(false);
  const [showPreviewPulang, setShowPreviewPulang] = useState(false);
  
  // Attendance time settings state
  const [jamBukaAbsen, setJamBukaAbsen] = useState('06:30');
  const [jamTutupAbsen, setJamTutupAbsen] = useState('12:00');
  const [jamBukaAbsenPulang, setJamBukaAbsenPulang] = useState('12:00');
  const [jamTutupAbsenPulang, setJamTutupAbsenPulang] = useState('18:00');
  const [jamToleransi, setJamToleransi] = useState('15');
  const [jamToleransiPulang, setJamToleransiPulang] = useState('15');
  const [absensiAktif, setAbsensiAktif] = useState(true);
  const [isSavingAbsensi, setIsSavingAbsensi] = useState(false);
  const [timezone, setTimezone] = useState('Asia/Jakarta');
  
  useEffect(() => {
    if (selectedSekolah) {
      fetchWhatsappSettings();
      fetchAbsensiSettings();
      fetchTemplatePesan();
    }
  }, [selectedSekolah]);
  
  const fetchAbsensiSettings = async () => {
    if (!selectedSekolah) return;
    try {
      const res = await fetch(`/api/sekolah/absensi-settings?sekolahId=${selectedSekolah.id}`);
      const data = await res.json();
      if (data.success) {
        setJamBukaAbsen(data.data.jamBukaAbsen || '06:30');
        setJamTutupAbsen(data.data.jamTutupAbsen || '12:00');
        setJamBukaAbsenPulang(data.data.jamBukaAbsenPulang || '12:00');
        setJamTutupAbsenPulang(data.data.jamTutupAbsenPulang || '18:00');
        setJamToleransi(data.data.jamToleransi || '15');
        setJamToleransiPulang(data.data.jamToleransiPulang || '15');
        setAbsensiAktif(data.data.absensiAktif ?? true);
        setTimezone(data.data.timezone || 'Asia/Jakarta');
      }
    } catch {
      console.error('Failed to fetch attendance settings');
    }
  };
  
  const handleSaveAbsensiSettings = async () => {
    if (!selectedSekolah) return;
    
    setIsSavingAbsensi(true);
    try {
      const res = await fetch('/api/sekolah/absensi-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sekolahId: selectedSekolah.id,
          jamBukaAbsen,
          jamTutupAbsen,
          jamBukaAbsenPulang,
          jamTutupAbsenPulang,
          jamToleransi,
          jamToleransiPulang,
          absensiAktif,
          timezone
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        // Update the selectedSekolah in store with new times
        setSelectedSekolah({
          ...selectedSekolah,
          jamMasuk: jamBukaAbsen,
          jamPulang: jamBukaAbsenPulang,
          jamBukaAbsen,
          jamTutupAbsen,
          jamBukaAbsenPulang,
          jamTutupAbsenPulang,
          absensiAktif
        });
        toast({
          title: 'Berhasil',
          description: 'Pengaturan waktu absensi berhasil disimpan. Jam masuk dan pulang sekolah telah diperbarui.',
        });
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal menyimpan pengaturan',
      });
    } finally {
      setIsSavingAbsensi(false);
    }
  };
  
  const fetchWhatsappSettings = async () => {
    if (!selectedSekolah) return;
    try {
      const res = await fetch(`/api/whatsapp/settings?sekolahId=${selectedSekolah.id}`);
      const data = await res.json();
      if (data.success) {
        setWhatsappSettings(data.data);
        setIsActive(data.data.isActive);
        setNotifMasuk(data.data.notifMasuk);
        setNotifPulang(data.data.notifPulang);
        setApiKeyInput(data.data.hasApiKey ? '******' : '');
      }
    } catch {
      console.error('Failed to fetch WhatsApp settings');
    }
  };
  
  const handleSaveSettings = async () => {
    if (!selectedSekolah) return;
    
    setIsSaving(true);
    try {
      const res = await fetch('/api/whatsapp/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sekolahId: selectedSekolah.id,
          provider: 'fonnte',
          apiKey: apiKeyInput,
          isActive,
          notifMasuk,
          notifPulang
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({
          title: 'Berhasil',
          description: 'Pengaturan WhatsApp berhasil disimpan',
        });
        fetchWhatsappSettings();
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal menyimpan pengaturan',
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  const fetchTemplatePesan = async () => {
    if (!selectedSekolah) return;
    setTemplateLoading(true);
    try {
      const res = await fetch(`/api/whatsapp-template?sekolahId=${selectedSekolah.id}`);
      const data = await res.json();
      if (data.success) {
        setTemplateMasuk(data.data.templateMasuk);
        setTemplatePulang(data.data.templatePulang);
      }
    } catch {
      console.error('Failed to fetch template pesan');
    } finally {
      setTemplateLoading(false);
    }
  };

  const handleSaveTemplate = async () => {
    if (!selectedSekolah) return;
    setTemplateSaving(true);
    try {
      const res = await fetch('/api/whatsapp-template', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sekolahId: selectedSekolah.id,
          templateMasuk,
          templatePulang,
        })
      });
      const data = await res.json();
      if (data.success) {
        toast({
          title: 'Berhasil',
          description: 'Template pesan WhatsApp berhasil disimpan',
        });
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal menyimpan template pesan',
      });
    } finally {
      setTemplateSaving(false);
    }
  };

  const previewTemplate = (template: string) => {
    return template
      .replaceAll('{{nama_siswa}}', 'Ahmad Fauzan')
      .replaceAll('{{nis}}', '2024001')
      .replaceAll('{{kelas}}', 'X-A')
      .replaceAll('{{sekolah}}', selectedSekolah?.nama || 'SMA Nurul Huda')
      .replaceAll('{{tanggal}}', 'Senin, 28 Maret 2025')
      .replaceAll('{{jam}}', '06:45')
      .replaceAll('{{jam_masuk}}', '06:45')
      .replaceAll('{{jam_keluar}}', '14:30')
      .replaceAll('{{status}}', 'hadir')
      .replaceAll('{{metode}}', 'QR')
      .replaceAll('{{keterangan}}', '-');
  };

  const handleTestWhatsapp = async () => {
    if (!testPhone || !selectedSekolah) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Masukkan nomor HP untuk test',
      });
      return;
    }
    
    setIsSendingTest(true);
    try {
      const res = await fetch('/api/whatsapp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          phone: testPhone,
          sekolahId: selectedSekolah.id
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({
          title: 'Berhasil',
          description: 'Pesan test berhasil dikirim ke ' + testPhone,
        });
      } else {
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Gagal mengirim pesan test',
      });
    } finally {
      setIsSendingTest(false);
    }
  };
  
  if (!selectedSekolah) {
    return (
      <div className="flex items-center justify-center h-64">
        <AlertCircle className="w-8 h-8 text-amber-500 mr-3" />
        <p className="text-slate-400">Pilih sekolah terlebih dahulu</p>
      </div>
    );
  }
  
  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white">Pengaturan</h2>
        <p className="text-slate-400">{selectedSekolah.nama}</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Jam Masuk */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <LogIn className="w-5 h-5 text-emerald-400" />
              Jam Masuk Sekolah
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Jam Masuk</span>
                <span className="text-white font-bold">{jamBukaAbsen}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Toleransi Keterlambatan</span>
                <span className="text-white font-bold">{selectedSekolah.jamToleransi} menit</span>
              </div>
              <p className="text-xs text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                Otomatis mengikuti Jam Buka Absen Masuk
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* Jam Pulang */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <LogOut className="w-5 h-5 text-amber-400" />
              Jam Pulang Sekolah
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Jam Pulang</span>
                <span className="text-white font-bold">{jamBukaAbsenPulang}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Toleransi</span>
                <span className="text-white font-bold">{selectedSekolah.jamToleransiPulang || '15'} menit</span>
              </div>
              <p className="text-xs text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                Otomatis mengikuti Jam Buka Absen Pulang
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* Pengaturan Waktu Absensi */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm md:col-span-2">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-emerald-400" />
              Pengaturan Waktu Absensi
            </CardTitle>
            <CardDescription className="text-slate-400">
              Atur jam buka dan tutup sistem absensi - Absensi hanya bisa dilakukan pada waktu yang ditentukan
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Status Aktif */}
            <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-xl">
              <div>
                <p className="text-white font-medium">Status Sistem Absensi</p>
                <p className="text-sm text-slate-400">Aktifkan atau nonaktifkan sistem absensi</p>
              </div>
              <div className="flex items-center gap-3">
                <Badge className={absensiAktif 
                  ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" 
                  : "bg-red-500/20 text-red-400 border-red-500/30"}>
                  {absensiAktif ? 'Aktif' : 'Nonaktif'}
                </Badge>
                <Checkbox 
                  checked={absensiAktif}
                  onCheckedChange={(checked) => setAbsensiAktif(checked as boolean)}
                />
              </div>
            </div>
            
            {/* Zona Waktu */}
            <div className="p-4 bg-slate-700/20 rounded-xl border border-slate-700/50">
              <div className="flex items-center gap-2 mb-3">
                <Globe className="w-4 h-4 text-blue-400" />
                <h4 className="text-white font-medium">Zona Waktu</h4>
              </div>
              <p className="text-sm text-slate-400 mb-3">Sesuaikan zona waktu sistem absensi dengan lokasi sekolah Anda</p>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: 'Asia/Jakarta', label: 'WIB', desc: 'Barat (UTC+7)' },
                  { value: 'Asia/Makassar', label: 'WITA', desc: 'Tengah (UTC+8)' },
                  { value: 'Asia/Jayapura', label: 'WIT', desc: 'Timur (UTC+9)' },
                ].map(opt => (
                  <button
                    key={opt.value}
                    onClick={() => setTimezone(opt.value)}
                    className={`p-3 rounded-xl border-2 text-center transition-all ${
                      timezone === opt.value
                        ? 'border-emerald-500 bg-emerald-500/15 text-white'
                        : 'border-slate-600 bg-slate-700/30 text-slate-400 hover:border-slate-500'
                    }`}
                  >
                    <div className="text-lg font-bold">{opt.label}</div>
                    <div className="text-xs mt-1 opacity-70">{opt.desc}</div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* Time Settings Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Absen Masuk */}
              <div className="p-4 bg-slate-700/20 rounded-xl space-y-4 border border-slate-700/50">
                <h4 className="text-white font-medium flex items-center gap-2">
                  <LogIn className="w-4 h-4 text-emerald-400" />
                  Waktu Absen Masuk
                </h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-slate-300">Jam Buka</Label>
                    <Input
                      type="time"
                      value={jamBukaAbsen}
                      onChange={(e) => setJamBukaAbsen(e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">Jam Tutup</Label>
                    <Input
                      type="time"
                      value={jamTutupAbsen}
                      onChange={(e) => setJamTutupAbsen(e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">
                      Toleransi Terlambat
                      <span className="block text-xs text-slate-500 font-normal">(menit)</span>
                    </Label>
                    <Input
                      type="number"
                      min="0"
                      max="120"
                      value={jamToleransi}
                      onChange={(e) => setJamToleransi(e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white"
                    />
                  </div>
                </div>
                <p className="text-xs text-slate-500">
                  Absen masuk: {jamBukaAbsen} - {jamTutupAbsen} &bull; Terlambat jika masuk setelah {jamBukaAbsen} + {jamToleransi} menit
                </p>
              </div>
              
              {/* Absen Pulang */}
              <div className="p-4 bg-slate-700/20 rounded-xl space-y-4 border border-slate-700/50">
                <h4 className="text-white font-medium flex items-center gap-2">
                  <LogOut className="w-4 h-4 text-amber-400" />
                  Waktu Absen Pulang
                </h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-slate-300">Jam Buka</Label>
                    <Input
                      type="time"
                      value={jamBukaAbsenPulang}
                      onChange={(e) => setJamBukaAbsenPulang(e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">Jam Tutup</Label>
                    <Input
                      type="time"
                      value={jamTutupAbsenPulang}
                      onChange={(e) => setJamTutupAbsenPulang(e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">
                      Toleransi Terlambat
                      <span className="block text-xs text-slate-500 font-normal">(menit)</span>
                    </Label>
                    <Input
                      type="number"
                      min="0"
                      max="120"
                      value={jamToleransiPulang}
                      onChange={(e) => setJamToleransiPulang(e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white"
                    />
                  </div>
                </div>
                <p className="text-xs text-slate-500">
                  Absen pulang: {jamBukaAbsenPulang} - {jamTutupAbsenPulang} &bull; Toleransi terlambat {jamToleransiPulang} menit
                </p>
              </div>
            </div>
            
            {/* Save Button */}
            <Button
              onClick={handleSaveAbsensiSettings}
              disabled={isSavingAbsensi}
              className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
            >
              {isSavingAbsensi ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Menyimpan...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Simpan Pengaturan Waktu
                </>
              )}
            </Button>
            
            {/* Info */}
            <div className="p-4 bg-amber-500/10 rounded-xl border border-amber-500/30">
              <h4 className="text-amber-400 font-medium mb-2">Perhatian</h4>
              <ul className="text-sm text-slate-300 space-y-1">
                <li>• Di luar jam yang ditentukan, sistem absensi tidak dapat digunakan</li>
                <li>• Pastikan jam tutup masuk tidak melebihi jam buka pulang</li>
                <li>• Siswa yang tidak absen dalam waktu yang ditentukan dianggap alpa</li>
                <li>• <strong className="text-emerald-400">Toleransi Terlambat</strong> adalah batas waktu kelonggaran setelah jam buka absen. Siswa yang absen melebihi jam buka + toleransi akan dianggap <strong className="text-amber-400">TERLAMBAT</strong></li>
                <li>• Contoh: Jam buka 07:00, toleransi 15 menit → siswa yang hadir hingga 07:15 dianggap tepat waktu, setelah itu terlambat</li>
                <li>• <strong className="text-emerald-400">Jam Masuk Sekolah</strong> akan otomatis mengikuti <strong className="text-emerald-400">Jam Buka Absen Masuk</strong></li>
                <li>• <strong className="text-emerald-400">Jam Pulang Sekolah</strong> akan otomatis mengikuti <strong className="text-emerald-400">Jam Buka Absen Pulang</strong></li>
              </ul>
            </div>
          </CardContent>
        </Card>
        
        {/* WhatsApp Settings */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm md:col-span-2">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Phone className="w-5 h-5 text-emerald-400" />
              Notifikasi WhatsApp (Fonnte)
            </CardTitle>
            <CardDescription className="text-slate-400">
              Notifikasi otomatis ke orang tua saat absensi - Konfigurasi API Key Fonnte Anda
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Status */}
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-slate-400">Status:</span>
                {whatsappSettings?.isConfigured ? (
                  <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                    Aktif
                  </Badge>
                ) : (
                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                    Tidak Aktif
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-400">Provider:</span>
                <span className="text-white font-medium capitalize">
                  {whatsappSettings?.provider || 'fonnte'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-400">API Key:</span>
                <span className="text-white font-medium">
                  {whatsappSettings?.hasApiKey ? '********' : 'Belum diset'}
                </span>
              </div>
            </div>
            
            {/* Configuration Form */}
            <div className="p-4 bg-slate-700/30 rounded-xl space-y-4">
              <h4 className="text-white font-medium">Konfigurasi Fonnte</h4>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Label className="text-slate-300">Aktifkan Notifikasi</Label>
                  </div>
                  <Checkbox 
                    checked={isActive}
                    onCheckedChange={(checked) => setIsActive(checked as boolean)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-slate-300">API Key Fonnte</Label>
                  <div className="relative">
                    <Input
                      type={showApiKey ? 'text' : 'password'}
                      placeholder="Masukkan API Key dari Fonnte"
                      value={apiKeyInput}
                      onChange={(e) => setApiKeyInput(e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-xs text-slate-500">
                    Dapatkan API Key di <span className="text-emerald-400">dashboard.fonnte.com</span>
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                    <Label className="text-slate-300 text-sm">Notif Masuk</Label>
                    <Checkbox 
                      checked={notifMasuk}
                      onCheckedChange={(checked) => setNotifMasuk(checked as boolean)}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                    <Label className="text-slate-300 text-sm">Notif Pulang</Label>
                    <Checkbox 
                      checked={notifPulang}
                      onCheckedChange={(checked) => setNotifPulang(checked as boolean)}
                    />
                  </div>
                </div>
              </div>
              
              <Button
                onClick={handleSaveSettings}
                disabled={isSaving}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Menyimpan...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Simpan Pengaturan
                  </>
                )}
              </Button>
            </div>
            
            {/* Test WhatsApp */}
            <div className="p-4 bg-slate-700/20 rounded-xl space-y-4 border border-slate-700/50">
              <h4 className="text-white font-medium">Test Kirim Pesan</h4>
              <div className="flex gap-3">
                <Input
                  type="text"
                  placeholder="Masukkan nomor HP (08xxx)"
                  value={testPhone}
                  onChange={(e) => setTestPhone(e.target.value)}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
                />
                <Button
                  onClick={handleTestWhatsapp}
                  disabled={isSendingTest || !whatsappSettings?.hasApiKey}
                  className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                >
                  {isSendingTest ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Kirim Test
                    </>
                  )}
                </Button>
              </div>
              {!whatsappSettings?.hasApiKey && (
                <p className="text-xs text-amber-400">
                  Simpan API Key terlebih dahulu untuk mengirim test
                </p>
              )}
            </div>
            
            {/* Info */}
            <div className="p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/30">
              <h4 className="text-emerald-400 font-medium mb-2">Informasi Fonnte</h4>
              <ul className="text-sm text-slate-300 space-y-1">
                <li>• Daftar di <span className="text-emerald-400">fonnte.com</span> (rekomendasi untuk Indonesia)</li>
                <li>• Verifikasi nomor WhatsApp yang akan digunakan</li>
                <li>• Copy API Key dari dashboard Fonnte</li>
                <li>• Biaya mulai Rp 75.000/bulan untuk 500 pesan</li>
              </ul>
            </div>
          </CardContent>
        </Card>
        
        {/* Template Pesan WhatsApp */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm md:col-span-2">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
              Template Pesan WhatsApp
            </CardTitle>
            <CardDescription className="text-slate-400">
              Atur template pesan yang dikirim ke orang tua saat absensi masuk dan pulang
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {templateLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-40 w-full rounded-xl" />
                <Skeleton className="h-40 w-full rounded-xl" />
              </div>
            ) : (
              <>
                {/* Daftar Variabel */}
                <div className="p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/30">
                  <h4 className="text-emerald-400 font-medium mb-3 flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    Variabel yang Tersedia
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { key: '{{nama_siswa}}', label: 'Nama Siswa' },
                      { key: '{{nis}}', label: 'NIS' },
                      { key: '{{kelas}}', label: 'Kelas' },
                      { key: '{{sekolah}}', label: 'Sekolah' },
                      { key: '{{tanggal}}', label: 'Tanggal' },
                      { key: '{{jam}}', label: 'Jam' },
                      { key: '{{jam_masuk}}', label: 'Jam Masuk' },
                      { key: '{{jam_keluar}}', label: 'Jam Keluar' },
                      { key: '{{status}}', label: 'Status' },
                      { key: '{{metode}}', label: 'Metode' },
                      { key: '{{keterangan}}', label: 'Keterangan' },
                    ].map((v) => (
                      <Badge
                        key={v.key}
                        variant="outline"
                        className="bg-slate-700/50 border-slate-600 text-emerald-300 hover:bg-slate-600/50 cursor-pointer transition-colors"
                        onClick={() => {
                          navigator.clipboard.writeText(v.key);
                          toast({ title: 'Disalin', description: `${v.key} disalin ke clipboard` });
                        }}
                      >
                        {v.key}
                        <span className="text-slate-500 ml-1">({v.label})</span>
                      </Badge>
                    ))}
                  </div>
                  <p className="text-xs text-slate-500 mt-2">Klik variabel untuk menyalin ke clipboard</p>
                </div>

                {/* Template Masuk */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <LogIn className="w-4 h-4 text-emerald-400" />
                      <Label className="text-white font-medium">Template Pesan Masuk (Hadir / Terlambat)</Label>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-700"
                      onClick={() => setShowPreviewMasuk(!showPreviewMasuk)}
                    >
                      {showPreviewMasuk ? (
                        <>
                          <EyeOff className="w-3 h-3 mr-1" /> Sembunyikan Preview
                        </>
                      ) : (
                        <>
                          <Eye className="w-3 h-3 mr-1" /> Lihat Preview
                        </>
                      )}
                    </Button>
                  </div>
                  <Textarea
                    value={templateMasuk}
                    onChange={(e) => setTemplateMasuk(e.target.value)}
                    rows={6}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 font-mono text-sm resize-y"
                    placeholder="Masukkan template pesan masuk..."
                  />
                  {showPreviewMasuk && (
                    <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-700/50">
                      <p className="text-xs text-slate-500 mb-2 font-medium">Preview Pesan Masuk:</p>
                      <pre className="text-sm text-slate-300 whitespace-pre-wrap font-mono leading-relaxed">
                        {previewTemplate(templateMasuk)}
                      </pre>
                    </div>
                  )}
                </div>

                {/* Template Pulang */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <LogOut className="w-4 h-4 text-amber-400" />
                      <Label className="text-white font-medium">Template Pesan Pulang</Label>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-700"
                      onClick={() => setShowPreviewPulang(!showPreviewPulang)}
                    >
                      {showPreviewPulang ? (
                        <>
                          <EyeOff className="w-3 h-3 mr-1" /> Sembunyikan Preview
                        </>
                      ) : (
                        <>
                          <Eye className="w-3 h-3 mr-1" /> Lihat Preview
                        </>
                      )}
                    </Button>
                  </div>
                  <Textarea
                    value={templatePulang}
                    onChange={(e) => setTemplatePulang(e.target.value)}
                    rows={6}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 font-mono text-sm resize-y"
                    placeholder="Masukkan template pesan pulang..."
                  />
                  {showPreviewPulang && (
                    <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-700/50">
                      <p className="text-xs text-slate-500 mb-2 font-medium">Preview Pesan Pulang:</p>
                      <pre className="text-sm text-slate-300 whitespace-pre-wrap font-mono leading-relaxed">
                        {previewTemplate(templatePulang)}
                      </pre>
                    </div>
                  )}
                </div>

                {/* Kembalikan ke Default */}
                <div className="flex items-center gap-3">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setTemplateMasuk('✅ *NOTIFIKASI ABSENSI*\n\nSekolah: {{sekolah}}\nTanggal: {{tanggal}}\n\nAnanda *{{nama_siswa}}* (Kelas {{kelas}}) telah {{status}} pada pukul *{{jam}}*.\n\n_Status: {{status}}_\n\n---\nPesan ini dikirim otomatis oleh Sistem Absensi Digital.\n_Jika ini adalah kesalahan, silakan hubungi pihak sekolah._');
                      setTemplatePulang('🏃 *NOTIFIKASI ABSENSI - PULANG*\n\nSekolah: {{sekolah}}\nTanggal: {{tanggal}}\n\nAnanda *{{nama_siswa}}* (Kelas {{kelas}}) telah *PULANG* pada pukul *{{jam}}*.\n\n---\nPesan ini dikirim otomatis oleh Sistem Absensi Digital.');
                      toast({ title: 'Reset', description: 'Template dikembalikan ke default' });
                    }}
                    className="bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-700"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Kembalikan ke Default
                  </Button>
                  
                  <Button
                    onClick={handleSaveTemplate}
                    disabled={templateSaving}
                    className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                  >
                    {templateSaving ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        Menyimpan...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Simpan Template
                      </>
                    )}
                  </Button>
                </div>

                {/* Info */}
                <div className="p-4 bg-amber-500/10 rounded-xl border border-amber-500/30">
                  <h4 className="text-amber-400 font-medium mb-2">Tips Format Pesan</h4>
                  <ul className="text-sm text-slate-300 space-y-1">
                    <li>• Gunakan <code className="text-emerald-400 bg-slate-700/50 px-1 rounded">*teks*</code> untuk <strong>bold</strong> di WhatsApp</li>
                    <li>• Gunakan <code className="text-emerald-400 bg-slate-700/50 px-1 rounded">_teks_</code> untuk <em>italic</em> di WhatsApp</li>
                    <li>• Gunakan <code className="text-emerald-400 bg-slate-700/50 px-1 rounded">~teks~</code> untuk <s>strikethrough</s> di WhatsApp</li>
                    <li>• Gunakan <code className="text-emerald-400 bg-slate-700/50 px-1 rounded">```teks```</code> untuk <code>monospace</code></li>
                    <li>• Variabel akan otomatis diganti saat pesan dikirim</li>
                  </ul>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* API Documentation */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm md:col-span-2">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-400" />
              Dokumentasi API
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="p-3 bg-slate-700/30 rounded-lg">
                <p className="text-emerald-400 font-mono">POST /api/auth/login</p>
                <p className="text-slate-400 mt-1">Login user</p>
              </div>
              <div className="p-3 bg-slate-700/30 rounded-lg">
                <p className="text-emerald-400 font-mono">POST /api/absensi</p>
                <p className="text-slate-400 mt-1">Record attendance</p>
              </div>
              <div className="p-3 bg-slate-700/30 rounded-lg">
                <p className="text-emerald-400 font-mono">GET /api/dashboard</p>
                <p className="text-slate-400 mt-1">Dashboard stats</p>
              </div>
              <div className="p-3 bg-slate-700/30 rounded-lg">
                <p className="text-emerald-400 font-mono">GET /api/siswa</p>
                <p className="text-slate-400 mt-1">List students</p>
              </div>
              <div className="p-3 bg-slate-700/30 rounded-lg">
                <p className="text-emerald-400 font-mono">GET /api/qr</p>
                <p className="text-slate-400 mt-1">Get QR code</p>
              </div>
              <div className="p-3 bg-slate-700/30 rounded-lg">
                <p className="text-emerald-400 font-mono">GET /api/export</p>
                <p className="text-slate-400 mt-1">Export reports</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
