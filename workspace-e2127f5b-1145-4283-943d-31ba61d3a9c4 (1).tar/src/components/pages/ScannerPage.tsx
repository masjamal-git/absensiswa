'use client';

import { useState, useEffect, useRef } from 'react';
import { Sekolah, Siswa } from '@/lib/store';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';
import { Html5Qrcode } from 'html5-qrcode';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { playSound } from './shared';
import { 
  AlertCircle, CheckCircle, Clock, Heart, ShieldAlert, Ban, XCircle,
  Search, RefreshCw, LogIn, LogOut, Users, QrCode, X 
} from 'lucide-react';

export function ScannerPage({ selectedSekolah }: { selectedSekolah: Sekolah | null }) {
  const { toast } = useToast();
  const [isScanning, setIsScanning] = useState(false);
  const [lastScan, setLastScan] = useState<any>(null);
  const [manualNIS, setManualNIS] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const isMountedRef = useRef(true);
  const onScanCallbackRef = useRef<(text: string) => void>(null);
  const [searchResults, setSearchResults] = useState<Siswa[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [scanMode, setScanMode] = useState<'masuk' | 'pulang'>('masuk');
  const [manualStatus, setManualStatus] = useState<'HADIR' | 'SAKIT' | 'IZIN' | 'ALPA'>('HADIR');
  const [manualKeterangan, setManualKeterangan] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [scannerError, setScannerError] = useState<string | null>(null);
  const [absensiSettings, setAbsensiSettings] = useState<{
    jamBukaAbsen: string;
    jamTutupAbsen: string;
    jamBukaAbsenPulang: string;
    jamTutupAbsenPulang: string;
    absensiAktif: boolean;
  } | null>(null);
  
  // Fetch attendance settings
  useEffect(() => {
    if (selectedSekolah) {
      fetchAbsensiSettings();
    }
  }, [selectedSekolah]);
  
  const fetchAbsensiSettings = async () => {
    if (!selectedSekolah) return;
    try {
      const res = await fetch(`/api/sekolah/absensi-settings?sekolahId=${selectedSekolah.id}`);
      const data = await res.json();
      if (data.success) {
        setAbsensiSettings({
          jamBukaAbsen: data.data.jamBukaAbsen || '06:30',
          jamTutupAbsen: data.data.jamTutupAbsen || '12:00',
          jamBukaAbsenPulang: data.data.jamBukaAbsenPulang || '12:00',
          jamTutupAbsenPulang: data.data.jamTutupAbsenPulang || '18:00',
          absensiAktif: data.data.absensiAktif ?? true
        });
      }
    } catch {
      console.error('Failed to fetch attendance settings');
    }
  };
  
  // Check if current time is within attendance window
  // Uses device's local time
  const isWithinTime = (jamBuka: string, jamTutup: string): boolean => {
    const [bukaJam, bukaMenit] = jamBuka.split(':').map(Number);
    const [tutupJam, tutupMenit] = jamTutup.split(':').map(Number);
    
    // Use device's local time
    const currentHours = currentTime.getHours();
    const currentMinutes = currentTime.getHours() * 60 + currentTime.getMinutes();
    
    const bukaMinutes = bukaJam * 60 + bukaMenit;
    const tutupMinutes = tutupJam * 60 + tutupMenit;
    
    return currentMinutes >= bukaMinutes && currentMinutes <= tutupMinutes;
  };
  
  // Get attendance status
  const getAttendanceStatus = () => {
    if (!absensiSettings) return { isAvailable: true, message: 'Memuat...' };
    
    if (!absensiSettings.absensiAktif) {
      return { isAvailable: false, message: 'Sistem absensi sedang tidak aktif' };
    }
    
    const jamBuka = scanMode === 'masuk' ? absensiSettings.jamBukaAbsen : absensiSettings.jamBukaAbsenPulang;
    const jamTutup = scanMode === 'masuk' ? absensiSettings.jamTutupAbsen : absensiSettings.jamTutupAbsenPulang;
    
    if (isWithinTime(jamBuka, jamTutup)) {
      return { 
        isAvailable: true, 
        message: `Absen ${scanMode} tersedia (${jamBuka} - ${jamTutup})` 
      };
    } else {
      // Use device's local time
      const currentMinutes = currentTime.getHours() * 60 + currentTime.getMinutes();
      const [bukaJam, bukaMenit] = jamBuka.split(':').map(Number);
      const bukaMinutes = bukaJam * 60 + bukaMenit;
      
      if (currentMinutes < bukaMinutes) {
        return { 
          isAvailable: false, 
          message: `Absen ${scanMode} belum dibuka. Buka pukul ${jamBuka}` 
        };
      } else {
        return { 
          isAvailable: false, 
          message: `Absen ${scanMode} sudah ditutup. Tutup pukul ${jamTutup}` 
        };
      }
    }
  };
  
  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);
  

  
  // Track mounted state
  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);
  
  const startScanner = async () => {
    if (!isMountedRef.current) return;
    
    // Fully stop and destroy existing scanner first
    if (scannerRef.current) {
      try {
        const state = scannerRef.current.getState();
        // State 2 = SCANNING, 1 = PAUSED — both need stop before clear
        if (state === 2 || state === 1) {
          try { await scannerRef.current.stop(); } catch {}
        }
        try { await scannerRef.current.clear(); } catch {}
      } catch {}
      scannerRef.current = null;
    }
    
    setScannerError(null);
    
    try {
      // Always create a fresh Html5Qrcode instance
      scannerRef.current = new Html5Qrcode('qr-reader', {
        formatsToSupport: [0], // QR_CODE
      });
      
      await scannerRef.current.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 250, height: 250 },
          aspectRatio: 1.0,
        },
        (decodedText) => {
          // Use ref callback to avoid stale closure
          if (onScanCallbackRef.current) {
            onScanCallbackRef.current(decodedText);
          }
        },
        () => {
          // QR not found in frame - silent, ignore
        }
      );
      
      if (isMountedRef.current) {
        setIsScanning(true);
      }
    } catch (error: any) {
      console.error('Failed to start scanner:', error);
      // Clean up failed instance
      if (scannerRef.current) {
        try { await scannerRef.current.clear(); } catch {}
        scannerRef.current = null;
      }
      if (isMountedRef.current) {
        setIsScanning(false);
        if (error?.toString().includes('NotAllowedError') || error?.toString().includes('Permission')) {
          setScannerError('Akses kamera ditolak. Silakan izinkan akses kamera di browser Anda dan refresh halaman.');
        } else if (error?.toString().includes('NotFoundError') || error?.toString().includes('Requested device not found')) {
          setScannerError('Kamera tidak ditemukan. Pastikan perangkat memiliki kamera.');
        } else if (error?.toString().includes('NotReadableError') || error?.toString().includes('Could not start video')) {
          setScannerError('Kamera sedang digunakan aplikasi lain atau tidak tersedia.');
        } else {
          setScannerError('Gagal mengaktifkan kamera. Pastikan izin kamera telah diberikan.');
        }
      }
    }
  };
  
  const stopScanner = async () => {
    if (scannerRef.current) {
      try {
        const state = scannerRef.current.getState();
        if (state === 2 || state === 1) {
          try { await scannerRef.current.stop(); } catch {}
        }
        try { await scannerRef.current.clear(); } catch {}
      } catch {}
      scannerRef.current = null;
    }
    if (isMountedRef.current) {
      setIsScanning(false);
      setScannerError(null);
    }
  };
  
  // Auto-start scanner when school is selected
  useEffect(() => {
    if (selectedSekolah) {
      startScanner();
    } else {
      stopScanner();
    }
    
    return () => {
      // Cleanup on unmount
      if (scannerRef.current) {
        try {
          const state = scannerRef.current.getState();
          if (state === 2 || state === 1) {
            scannerRef.current.stop().catch(() => {});
          }
          scannerRef.current.clear().catch(() => {});
        } catch {}
        scannerRef.current = null;
      }
    };
  }, [selectedSekolah?.id]);
  
  const handleScanSuccess = async (decodedText: string) => {
    // Stop scanning while processing
    if (scannerRef.current) {
      try {
        const state = scannerRef.current.getState();
        if (state === 2 || state === 1) {
          try { await scannerRef.current.stop(); } catch {}
        }
      } catch {}
    }
    setIsProcessing(true);
    await processAttendance(decodedText, 'qr');
    // Auto-resume scanning after processing (with small delay)
    setTimeout(() => {
      if (isMountedRef.current && selectedSekolah) {
        startScanner();
      }
    }, 1500);
  };
  
  // Keep scan callback ref updated
  useEffect(() => {
    onScanCallbackRef.current = handleScanSuccess;
  });
  
  const processAttendance = async (tokenOrId: string, method: 'qr' | 'manual') => {
    if (!selectedSekolah) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Pilih sekolah terlebih dahulu',
      });
      return;
    }
    
    setIsProcessing(true);
    
    try {
      const body = method === 'qr' 
        ? { type: 'qr', qrToken: tokenOrId, sekolahId: selectedSekolah.id, mode: scanMode }
        : { 
            type: 'manual', 
            siswaId: tokenOrId, 
            sekolahId: selectedSekolah.id, 
            status: manualStatus, 
            mode: manualStatus === 'HADIR' ? scanMode : 'masuk',
            keterangan: manualKeterangan || undefined
          };
      
      const res = await fetch('/api/absensi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      
      const data = await res.json();
      
      if (data.success) {
        playSound('success');
        setLastScan(data.data);
        toast({
          title: 'Berhasil',
          description: data.message,
        });
      } else {
        playSound('error');
        toast({
          variant: 'destructive',
          title: 'Gagal',
          description: data.message,
        });
        if (data.data) {
          setLastScan(data.data);
        }
      }
    } catch {
      playSound('error');
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Terjadi kesalahan',
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const searchSiswa = async (query: string) => {
    if (!selectedSekolah || query.length < 2) {
      setSearchResults([]);
      return;
    }
    
    setIsSearching(true);
    
    try {
      const res = await fetch(`/api/siswa?sekolahId=${selectedSekolah.id}&search=${query}&limit=10`);
      const data = await res.json();
      
      if (data.success) {
        setSearchResults(data.data);
      }
    } catch {
      console.error('Search error');
    } finally {
      setIsSearching(false);
    }
  };

  if (!selectedSekolah) {
    return (
      <div className="flex items-center justify-center h-64">
        <AlertCircle className="w-8 h-8 text-amber-500 mr-3" />
        <p className="text-slate-400">Pilih sekolah terlebih dahulu</p>
      </div>
    );
  }
  
  return (
    <div className="p-6 space-y-6">
      {/* Clock & Date Display */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Scanner QR Code</h2>
          <p className="text-slate-400">
            {selectedSekolah.nama} - Jam Masuk: {selectedSekolah.jamMasuk} | Jam Pulang: {selectedSekolah.jamPulang || '15:00'}
          </p>
        </div>
        
        {/* Digital Clock */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold font-mono text-white tracking-wider">
                {format(currentTime, 'HH:mm:ss')}
              </div>
              <div className="text-sm md:text-base text-slate-400 mt-1">
                {format(currentTime, 'EEEE, d MMMM yyyy', { locale: id })}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Attendance Status */}
      {(() => {
        const status = getAttendanceStatus();
        return (
          <Alert className={`${status.isAvailable 
            ? 'bg-emerald-500/10 border-emerald-500/30' 
            : 'bg-red-500/10 border-red-500/30'}`}>
            {status.isAvailable ? (
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-400" />
            )}
            <AlertDescription className={`${status.isAvailable ? 'text-emerald-400' : 'text-red-400'} font-medium`}>
              {status.message}
            </AlertDescription>
          </Alert>
        );
      })()}
      
      {/* Scan Mode Tabs */}
      <div className="flex gap-2">
        <Button
          onClick={() => setScanMode('masuk')}
          className={`flex-1 ${scanMode === 'masuk' 
            ? 'bg-gradient-to-r from-emerald-500 to-teal-600' 
            : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'}`}
        >
          <LogIn className="w-4 h-4 mr-2" />
          Absen Masuk
        </Button>
        <Button
          onClick={() => setScanMode('pulang')}
          className={`flex-1 ${scanMode === 'pulang' 
            ? 'bg-gradient-to-r from-amber-500 to-orange-600' 
            : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'}`}
        >
          <LogOut className="w-4 h-4 mr-2" />
          Absen Pulang
        </Button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Scanner Section */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              {scanMode === 'masuk' ? (
                <>
                  <LogIn className="w-5 h-5 text-emerald-400" />
                  Scan Masuk
                </>
              ) : (
                <>
                  <LogOut className="w-5 h-5 text-amber-400" />
                  Scan Pulang
                </>
              )}
            </CardTitle>
            <CardDescription className="text-slate-400">
              {scanMode === 'masuk' 
                ? `Arahkan kamera ke QR Code siswa untuk absen masuk (batas terlambat: ${selectedSekolah.jamMasuk || '07:00'} + ${selectedSekolah.jamToleransi || '15'} menit)`
                : `Arahkan kamera ke QR Code siswa untuk absen pulang (mulai: ${selectedSekolah.jamPulang || '15:00'})`}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* QR Reader Container - always present for Html5Qrcode */}
            <div className="relative">
              <div id="qr-reader" className="rounded-xl overflow-hidden" style={{ minHeight: isScanning ? 'auto' : '300px' }}></div>
              
              {/* Camera loading overlay */}
              {!isScanning && !scannerError && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/80 rounded-xl">
                  <RefreshCw className="w-10 h-10 animate-spin text-emerald-500 mb-3" />
                  <p className="text-slate-300 text-sm">Mengaktifkan kamera...</p>
                </div>
              )}
              
              {/* Scanner Error Message */}
              {scannerError && !isScanning && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/90 rounded-xl p-4">
                  <AlertCircle className="w-10 h-10 text-red-400 mb-3" />
                  <p className="text-red-400 text-sm text-center mb-4">{scannerError}</p>
                  <Button 
                    onClick={startScanner}
                    size="sm"
                    className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Coba Lagi
                  </Button>
                </div>
              )}
            </div>
            
            {/* Scanner Controls */}
            {isScanning && (
              <div className="space-y-3">
                {/* Status indicator */}
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="text-emerald-400">Kamera aktif - Siap scan QR Code</span>
                </div>
                <Button 
                  onClick={stopScanner}
                  variant="outline"
                  className="w-full bg-slate-700/50 border-slate-600 text-white hover:bg-red-500/20 hover:text-red-400"
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Matikan Kamera
                </Button>
              </div>
            )}
            
            {isProcessing && (
              <div className="flex items-center justify-center py-4">
                <RefreshCw className="w-6 h-6 animate-spin text-emerald-500 mr-2" />
                <span className="text-slate-400">Memproses absensi...</span>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Manual Input Section */}
        <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">Input Manual</CardTitle>
            <CardDescription className="text-slate-400">
              Cari siswa berdasarkan nama atau NIS, lalu pilih status kehadiran
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Status Selector */}
            <div className="grid grid-cols-4 gap-2">
              {([
                { value: 'HADIR' as const, label: 'Hadir', icon: CheckCircle, color: 'border-emerald-500/50 bg-emerald-500/10 text-emerald-400' },
                { value: 'SAKIT' as const, label: 'Sakit', icon: Heart, color: 'border-purple-500/50 bg-purple-500/10 text-purple-400' },
                { value: 'IZIN' as const, label: 'Izin', icon: ShieldAlert, color: 'border-sky-500/50 bg-sky-500/10 text-sky-400' },
                { value: 'ALPA' as const, label: 'Alpa', icon: Ban, color: 'border-red-500/50 bg-red-500/10 text-red-400' },
              ]).map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => { setManualStatus(opt.value); setManualKeterangan(''); }}
                  className={`flex flex-col items-center gap-1 p-3 rounded-xl border-2 transition-all ${
                    manualStatus === opt.value ? opt.color + ' ring-2 ring-offset-1 ring-offset-slate-800' : 'border-slate-600/50 bg-slate-700/30 text-slate-400 hover:border-slate-500'
                  }`}
                >
                  <opt.icon className="w-5 h-5" />
                  <span className="text-xs font-medium">{opt.label}</span>
                </button>
              ))}
            </div>
            
            {/* Keterangan (for SAKIT/IZIN/ALPA) */}
            {manualStatus !== 'HADIR' && (
              <div>
                <Label className="text-slate-300 text-sm mb-1.5 block">Keterangan (opsional)</Label>
                <Textarea
                  placeholder={manualStatus === 'SAKIT' ? 'Contoh: Demam, flu, dll...' : manualStatus === 'IZIN' ? 'Contoh: Acara keluarga, dll...' : 'Contoh: Tanpa keterangan...'}
                  value={manualKeterangan}
                  onChange={(e) => setManualKeterangan(e.target.value)}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 text-sm resize-none"
                  rows={2}
                />
              </div>
            )}
            
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Cari nama atau NIS..."
                value={manualNIS}
                onChange={(e) => {
                  setManualNIS(e.target.value);
                  searchSiswa(e.target.value);
                }}
                className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
              />
              {isSearching && (
                <RefreshCw className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-slate-400" />
              )}
            </div>
            
            {searchResults.length > 0 && (
              <ScrollArea className="h-64 rounded-xl border border-slate-700">
                {searchResults.map((siswa) => (
                  <button
                    key={siswa.id}
                    onClick={() => processAttendance(siswa.id, 'manual')}
                    className="w-full flex items-center gap-3 p-3 hover:bg-slate-700/50 transition-colors border-b border-slate-700/50 last:border-0"
                  >
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className={`${
                        manualStatus === 'HADIR' ? 'bg-gradient-to-br from-emerald-500 to-teal-600' :
                        manualStatus === 'SAKIT' ? 'bg-gradient-to-br from-purple-500 to-violet-600' :
                        manualStatus === 'IZIN' ? 'bg-gradient-to-br from-sky-500 to-blue-600' :
                        'bg-gradient-to-br from-red-500 to-rose-600'
                      } text-white`}>
                        {siswa.nama.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 text-left">
                      <p className="font-medium text-white">{siswa.nama}</p>
                      <p className="text-sm text-slate-400">{siswa.nis} - {siswa.kelas.nama}</p>
                    </div>
                    <Badge className={`text-xs ${
                      manualStatus === 'HADIR' ? 'bg-emerald-500/20 text-emerald-400' :
                      manualStatus === 'SAKIT' ? 'bg-purple-500/20 text-purple-400' :
                      manualStatus === 'IZIN' ? 'bg-sky-500/20 text-sky-400' :
                      'bg-red-500/20 text-red-400'
                    }`}>
                      {manualStatus}
                    </Badge>
                  </button>
                ))}
              </ScrollArea>
            )}
            
            {manualNIS.length >= 2 && searchResults.length === 0 && !isSearching && (
              <div className="text-center py-8 text-slate-400">
                <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>Siswa tidak ditemukan</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Last Scan Result */}
      {lastScan && (
        <Card className={`bg-slate-800/50 border-slate-700/50 backdrop-blur-sm ${
          lastScan.status === 'HADIR' ? 'ring-2 ring-emerald-500/50' :
          lastScan.status === 'TERLAMBAT' ? 'ring-2 ring-amber-500/50' :
          lastScan.status === 'SAKIT' ? 'ring-2 ring-purple-500/50' :
          lastScan.status === 'IZIN' ? 'ring-2 ring-sky-500/50' :
          'ring-2 ring-red-500/50'
        }`}>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                lastScan.status === 'HADIR' ? 'bg-emerald-500/20' :
                lastScan.status === 'TERLAMBAT' ? 'bg-amber-500/20' :
                lastScan.status === 'SAKIT' ? 'bg-purple-500/20' :
                lastScan.status === 'IZIN' ? 'bg-sky-500/20' :
                'bg-red-500/20'
              }`}>
                {lastScan.status === 'HADIR' ? (
                  <CheckCircle className="w-8 h-8 text-emerald-500" />
                ) : lastScan.status === 'TERLAMBAT' ? (
                  <Clock className="w-8 h-8 text-amber-500" />
                ) : lastScan.status === 'SAKIT' ? (
                  <Heart className="w-8 h-8 text-purple-500" />
                ) : lastScan.status === 'IZIN' ? (
                  <ShieldAlert className="w-8 h-8 text-sky-500" />
                ) : (
                  <Ban className="w-8 h-8 text-red-500" />
                )}
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white">{lastScan.siswa?.nama || lastScan.nama}</h3>
                <p className="text-slate-400">
                  {lastScan.siswa?.kelas?.nama || lastScan.kelas || '-'} • {lastScan.jam || 'Hari ini'}
                </p>
              </div>
              <Badge className={`text-lg px-4 py-2 ${
                lastScan.status === 'HADIR' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                lastScan.status === 'TERLAMBAT' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                lastScan.status === 'SAKIT' ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' :
                lastScan.status === 'IZIN' ? 'bg-sky-500/20 text-sky-400 border-sky-500/30' :
                'bg-red-500/20 text-red-400 border-red-500/30'
              }`}>
                {lastScan.status}
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
