'use client';

import { format } from 'date-fns';
import { Sekolah, Siswa } from '@/lib/store';
import { GraduationCap, Users, QrCode } from 'lucide-react';

// Card Settings interface
export interface CardSettings {
  warnaHeader: string;
  warnaBackground: string;
  tahunAjaran: string;
  berlakuSampai: string;
  namaKepalaSekolah: string;
  nipKepalaSekolah: string;
  showQR: boolean;
  showFoto: boolean;
  logoSekolah: string | null;
  kartuPerHalaman: 6 | 8 | 10;
}

// Extended Siswa interface for card printing
export interface SiswaWithDetails extends Siswa {
  foto?: string | null;
  tempatLahir?: string | null;
  tanggalLahir?: Date | string | null;
  alamat?: string | null;
}

// Student Card Component - KTP Size (85.6mm x 53.98mm)
export function StudentCard({ 
  siswa, 
  sekolah, 
  qrCode, 
  settings 
}: { 
  siswa: SiswaWithDetails; 
  sekolah: Sekolah | null; 
  qrCode: string;
  settings: CardSettings;
}) {
  const formatDate = (date: Date | string | null | undefined) => {
    if (!date) return '-';
    try {
      const d = typeof date === 'string' ? new Date(date) : date;
      return format(d, 'dd-MM-yyyy');
    } catch {
      return '-';
    }
  };

  return (
    <div 
      className="student-card bg-white rounded-lg overflow-hidden shadow-lg"
      style={{ 
        width: '85.6mm', 
        height: '53.98mm',
        backgroundColor: settings.warnaBackground || '#ffffff'
      }}
    >
      {/* Card Header */}
      <div 
        className="p-1.5 text-white text-center"
        style={{ backgroundColor: settings.warnaHeader || '#059669' }}
      >
        <div className="flex items-center justify-center gap-1.5">
          {settings.logoSekolah ? (
            <img 
              src={settings.logoSekolah} 
              alt="Logo" 
              className="w-7 h-7 rounded-full object-contain flex-shrink-0 bg-white p-0.5"
            />
          ) : (
            <div className="w-7 h-7 bg-white rounded-full flex items-center justify-center flex-shrink-0">
              <GraduationCap className="w-4 h-4" style={{ color: settings.warnaHeader || '#059669' }} />
            </div>
          )}
          <div>
            <h3 className="font-bold text-[8px] leading-tight">KARTU PELAJAR</h3>
            <p className="text-[6px] opacity-90 leading-tight">{sekolah?.nama || 'Nama Sekolah'}</p>
          </div>
        </div>
      </div>
      
      {/* Card Body */}
      <div className="p-2 flex gap-2">
        {/* Photo */}
        <div className="flex-shrink-0" style={{ width: '23mm', height: '30mm' }}>
          {siswa.foto && settings.showFoto ? (
            <img 
              src={siswa.foto} 
              alt={siswa.nama} 
              className="w-full h-full object-cover rounded border border-gray-200"
            />
          ) : (
            <div className="w-full h-full bg-gray-100 rounded border border-gray-200 flex items-center justify-center">
              <div className="text-center text-gray-400">
                <Users className="w-6 h-6 mx-auto" />
                <span className="text-[5px]">FOTO 3x4</span>
              </div>
            </div>
          )}
        </div>
        
        {/* Student Info */}
        <div className="flex-1 text-[7px]">
          <table className="w-full">
            <tbody>
              <tr>
                <td className="text-gray-500 py-0.5 w-12">Nama</td>
                <td className="text-gray-900 font-medium py-0.5">: {siswa.nama}</td>
              </tr>
              <tr>
                <td className="text-gray-500 py-0.5">NIS</td>
                <td className="text-gray-900 py-0.5">: {siswa.nis}</td>
              </tr>
              <tr>
                <td className="text-gray-500 py-0.5">NISN</td>
                <td className="text-gray-900 py-0.5">: {siswa.nisn || '-'}</td>
              </tr>
              <tr>
                <td className="text-gray-500 py-0.5">Kelas</td>
                <td className="text-gray-900 py-0.5">: {siswa.kelas?.nama || '-'}</td>
              </tr>
              <tr>
                <td className="text-gray-500 py-0.5">TTL</td>
                <td className="text-gray-900 py-0.5">: {siswa.tempatLahir || '-'}, {formatDate(siswa.tanggalLahir)}</td>
              </tr>
              <tr>
                <td className="text-gray-500 py-0.5">Alamat</td>
                <td className="text-gray-900 py-0.5 truncate max-w-[40mm]">: {siswa.alamat || '-'}</td>
              </tr>
            </tbody>
          </table>
        </div>
        
        {/* QR Code */}
        {settings.showQR && (
          <div className="flex flex-col items-center justify-end flex-shrink-0">
            {qrCode ? (
              <img src={qrCode} alt="QR" className="w-12 h-12" />
            ) : (
              <div className="w-12 h-12 bg-gray-100 rounded flex items-center justify-center">
                <QrCode className="w-8 h-8 text-gray-300" />
              </div>
            )}
            <span className="text-[5px] text-gray-400 mt-0.5">Scan</span>
          </div>
        )}
      </div>
      
      {/* Card Footer */}
      <div className="px-2 pb-1.5">
        <div className="flex justify-between items-end border-t border-gray-200 pt-1">
          <div className="text-[6px] text-gray-500">
            <p>TA: {settings.tahunAjaran || '2024/2025'}</p>
            <p>Berlaku: {settings.berlakuSampai || 'Juli 2025'}</p>
          </div>
          <div className="text-center">
            <p className="text-[6px] text-gray-500">Kepala Sekolah</p>
            <p className="text-[7px] font-medium text-gray-900 mt-3">{settings.namaKepalaSekolah || '________________'}</p>
            <p className="text-[5px] text-gray-500">{settings.nipKepalaSekolah ? `NIP. ${settings.nipKepalaSekolah}` : ''}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// Get grid layout config based on cards per page
export function getGridLayout(kartuPerHalaman: number) {
  switch (kartuPerHalaman) {
    case 8: return { cols: 2, rows: 4, padding: '6mm', gap: '3mm' };
    case 10: return { cols: 2, rows: 5, padding: '4mm', gap: '2mm' };
    default: return { cols: 2, rows: 3, padding: '8mm', gap: '4mm' };
  }
}
