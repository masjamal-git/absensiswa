/**
 * WhatsApp Notification Service
 * Using Fonnte API for Indonesia
 * 
 * Settings are stored in database (PengaturanWhatsApp model)
 * Message templates are stored in database (TemplatePesanWhatsApp model)
 */

import { db } from './db';

interface WhatsAppMessage {
  phone: string;
  message: string;
  siswaId: string;
  absensiId: string;
  sekolahId?: string;
}

interface WhatsAppResponse {
  success: boolean;
  messageId?: string;
  error?: string;
}

interface WhatsAppSettings {
  provider: string;
  apiKey: string | null;
  apiUrl: string;
  isActive: boolean;
  notifMasuk: boolean;
  notifPulang: boolean;
}

// Get WhatsApp settings from database
async function getWhatsAppSettings(sekolahId: string): Promise<WhatsAppSettings | null> {
  try {
    const settings = await db.pengaturanWhatsApp.findUnique({
      where: { sekolahId }
    });
    
    if (!settings) {
      return null;
    }
    
    return {
      provider: settings.provider,
      apiKey: settings.apiKey,
      apiUrl: settings.apiUrl,
      isActive: settings.isActive,
      notifMasuk: settings.notifMasuk,
      notifPulang: settings.notifPulang
    };
  } catch (error) {
    console.error('Error getting WhatsApp settings:', error);
    return null;
  }
}

// Format phone number
export function formatPhoneNumber(phone: string | null | undefined): string {
  if (!phone) return '';
  
  // Remove non-numeric characters
  let cleaned = phone.replace(/\D/g, '');
  
  // Convert 08 to 628
  if (cleaned.startsWith('08')) {
    cleaned = '62' + cleaned.substring(1);
  }
  
  // Ensure starts with 62
  if (!cleaned.startsWith('62')) {
    cleaned = '62' + cleaned;
  }
  
  return cleaned;
}

// ==================== TEMPLATE PESAN SYSTEM ====================

// Template variables that can be used in message templates
export const TEMPLATE_VARIABLES = [
  { key: '{{nama_siswa}}', label: 'Nama Siswa', example: 'Ahmad Fauzan' },
  { key: '{{nis}}', label: 'NIS', example: '2024001' },
  { key: '{{kelas}}', label: 'Kelas', example: 'X-A' },
  { key: '{{sekolah}}', label: 'Nama Sekolah', example: 'SMA Nurul Huda' },
  { key: '{{tanggal}}', label: 'Tanggal', example: 'Senin, 28 Maret 2025' },
  { key: '{{jam}}', label: 'Jam Absensi', example: '06:45' },
  { key: '{{jam_masuk}}', label: 'Jam Masuk', example: '06:45' },
  { key: '{{jam_keluar}}', label: 'Jam Keluar', example: '14:30' },
  { key: '{{status}}', label: 'Status Kehadiran', example: 'HADIR / TERLAMBAT' },
  { key: '{{metode}}', label: 'Metode Absensi', example: 'QR / MANUAL' },
  { key: '{{keterangan}}', label: 'Keterangan', example: '' },
];

// Default templates (used when no custom template exists)
const DEFAULT_TEMPLATE_MASUK = `✅ *NOTIFIKASI ABSENSI*

Sekolah: {{sekolah}}
Tanggal: {{tanggal}}

Ananda *{{nama_siswa}}* (Kelas {{kelas}}) telah {{status}} pada pukul *{{jam}}*.

_Status: {{status}}_

---
Pesan ini dikirim otomatis oleh Sistem Absensi Digital.
_Jika ini adalah kesalahan, silakan hubungi pihak sekolah._`;

const DEFAULT_TEMPLATE_PULANG = `🏃 *NOTIFIKASI ABSENSI - PULANG*

Sekolah: {{sekolah}}
Tanggal: {{tanggal}}

Ananda *{{nama_siswa}}* (Kelas {{kelas}}) telah *PULANG* pada pukul *{{jam}}*.

---
Pesan ini dikirim otomatis oleh Sistem Absensi Digital.`;

// Get template from database (Pengaturan key-value store), fallback to default
export async function getPesanTemplate(sekolahId: string): Promise<{
  templateMasuk: string;
  templatePulang: string;
}> {
  try {
    const [masukSetting, pulangSetting] = await Promise.all([
      db.pengaturan.findUnique({
        where: { sekolahId_key: { sekolahId, key: 'template_pesan_masuk' } }
      }),
      db.pengaturan.findUnique({
        where: { sekolahId_key: { sekolahId, key: 'template_pesan_pulang' } }
      })
    ]);

    if (masukSetting && pulangSetting) {
      return {
        templateMasuk: masukSetting.value,
        templatePulang: pulangSetting.value
      };
    }
  } catch (error) {
    console.error('Error getting template, using default:', error);
  }

  return {
    templateMasuk: DEFAULT_TEMPLATE_MASUK,
    templatePulang: DEFAULT_TEMPLATE_PULANG
  };
}

// Render template by replacing variables with actual values
export function renderTemplate(template: string, variables: Record<string, string>): string {
  let rendered = template;
  
  for (const [key, value] of Object.entries(variables)) {
    rendered = rendered.replaceAll(key, value);
  }
  
  return rendered;
}

// Interface for message data
export interface MessageData {
  namaSiswa: string;
  nis: string;
  kelas: string;
  status: string;
  jam: string;
  jamMasuk?: string;
  jamKeluar?: string;
  tanggal: string;
  sekolah: string;
  metode: string;
  keterangan?: string;
}

// Generate MASUK message using template from DB
export async function generateMasukMessage(sekolahId: string, data: MessageData): Promise<string> {
  const { templateMasuk } = await getPesanTemplate(sekolahId);
  
  const variables: Record<string, string> = {
    '{{nama_siswa}}': data.namaSiswa,
    '{{nis}}': data.nis,
    '{{kelas}}': data.kelas,
    '{{sekolah}}': data.sekolah,
    '{{tanggal}}': data.tanggal,
    '{{jam}}': data.jam,
    '{{jam_masuk}}': data.jamMasuk || data.jam,
    '{{jam_keluar}}': data.jamKeluar || '-',
    '{{status}}': data.status.toLowerCase(),
    '{{metode}}': data.metode,
    '{{keterangan}}': data.keterangan || '-',
  };
  
  return renderTemplate(templateMasuk, variables);
}

// Generate PULANG message using template from DB
export async function generatePulangMessage(sekolahId: string, data: MessageData): Promise<string> {
  const { templatePulang } = await getPesanTemplate(sekolahId);
  
  const variables: Record<string, string> = {
    '{{nama_siswa}}': data.namaSiswa,
    '{{nis}}': data.nis,
    '{{kelas}}': data.kelas,
    '{{sekolah}}': data.sekolah,
    '{{tanggal}}': data.tanggal,
    '{{jam}}': data.jam,
    '{{jam_masuk}}': data.jamMasuk || '-',
    '{{jam_keluar}}': data.jamKeluar || data.jam,
    '{{status}}': 'pulang',
    '{{metode}}': data.metode,
    '{{keterangan}}': data.keterangan || '-',
  };
  
  return renderTemplate(templatePulang, variables);
}

// Keep backward compatible function (uses default hardcoded template)
export function generateAttendanceMessage(data: {
  namaSiswa: string;
  kelas: string;
  status: string;
  jam: string;
  tanggal: string;
  sekolah: string;
}): string {
  const statusEmoji: Record<string, string> = {
    HADIR: '✅',
    TERLAMBAT: '⏰',
    IZIN: '📝',
    SAKIT: '🏥',
    ALPA: '❌'
  };
  
  const emoji = statusEmoji[data.status] || '📝';
  
  return `${emoji} *NOTIFIKASI ABSENSI*

Sekolah: ${data.sekolah}
Tanggal: ${data.tanggal}

Ananda *${data.namaSiswa}* (Kelas ${data.kelas}) telah ${data.status.toLowerCase()} pada pukul *${data.jam}*.

_Status: ${data.status}_

---
Pesan ini dikirim otomatis oleh Sistem Absensi Digital.
_Jika ini adalah kesalahan, silakan hubungi pihak sekolah._`;
}

// ==================== SENDING FUNCTIONS ====================

// Mock WhatsApp service (for testing without API)
async function mockSendWhatsApp(data: WhatsAppMessage): Promise<WhatsAppResponse> {
  console.log('[MOCK WHATSAPP] Sending message to:', data.phone);
  console.log('[MOCK WHATSAPP] Message:', data.message.substring(0, 100) + '...');
  
  // Simulate 90% success rate
  const success = Math.random() > 0.1;
  
  if (success) {
    return {
      success: true,
      messageId: `mock_${Date.now()}_${Math.random().toString(36).substring(7)}`
    };
  } else {
    return {
      success: false,
      error: 'MOCK_ERROR: Simulated failure'
    };
  }
}

// Fonnte WhatsApp API
async function fonnteSendWhatsApp(data: WhatsAppMessage, settings: WhatsAppSettings): Promise<WhatsAppResponse> {
  try {
    if (!settings.apiKey) {
      console.error('Fonnte API key not configured');
      return {
        success: false,
        error: 'API Key tidak dikonfigurasi'
      };
    }
    
    const response = await fetch(settings.apiUrl || 'https://api.fonnte.com/send', {
      method: 'POST',
      headers: {
        'Authorization': settings.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        target: data.phone,
        message: data.message,
        countryCode: '62'
      })
    });
    
    const result = await response.json();
    console.log('[FONNTE] Response:', result);
    
    // Fonnte returns { status: true, ... } on success
    if (result.status === true || result.status === 'success') {
      return {
        success: true,
        messageId: result.id || result.messageId || `fonnte_${Date.now()}`
      };
    } else {
      return {
        success: false,
        error: result.reason || result.message || result.msg || 'Unknown error from Fonnte'
      };
    }
  } catch (error) {
    console.error('[FONNTE] Error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Network error'
    };
  }
}

// Main send function - uses database settings
export async function sendWhatsAppNotification(data: WhatsAppMessage): Promise<WhatsAppResponse> {
  let settings: WhatsAppSettings | null = null;
  
  // Get settings from database if sekolahId is provided
  if (data.sekolahId) {
    settings = await getWhatsAppSettings(data.sekolahId);
  }
  
  // If no settings or not active, use mock
  if (!settings || !settings.isActive || !settings.apiKey) {
    console.log('[WHATSAPP] No active settings found, using mock mode');
    return mockSendWhatsApp(data);
  }
  
  let response: WhatsAppResponse;
  
  switch (settings.provider) {
    case 'fonnte':
      response = await fonnteSendWhatsApp(data, settings);
      break;
    case 'twilio':
      // TODO: Implement Twilio
      console.log('[WHATSAPP] Twilio not implemented, using mock');
      response = await mockSendWhatsApp(data);
      break;
    default:
      response = await mockSendWhatsApp(data);
  }
  
  // Update notification status in database
  try {
    await db.notifikasiQueue.updateMany({
      where: {
        siswaId: data.siswaId,
        absensiId: data.absensiId,
        status: 'PENDING'
      },
      data: {
        status: response.success ? 'SENT' : 'FAILED',
        sentAt: response.success ? new Date() : null,
        errorMessage: response.error || null,
        updatedAt: new Date()
      }
    });
  } catch (dbError) {
    console.error('Error updating notification status:', dbError);
  }
  
  return response;
}

// Queue notification for retry
export async function queueNotification(data: {
  siswaId: string;
  absensiId: string;
  phone: string;
  message: string;
}): Promise<void> {
  try {
    await db.notifikasiQueue.create({
      data: {
        siswaId: data.siswaId,
        absensiId: data.absensiId,
        phone: data.phone,
        pesan: data.message,
        status: 'PENDING',
        maxRetry: 3
      }
    });
  } catch (error) {
    console.error('Error queueing notification:', error);
  }
}

// Process notification queue (to be called by cron job)
export async function processNotificationQueue(): Promise<void> {
  const pendingNotifications = await db.notifikasiQueue.findMany({
    where: {
      status: 'PENDING',
      retryCount: { lt: 3 }
    },
    take: 50
  });
  
  for (const notification of pendingNotifications) {
    // Get sekolahId from the related siswa
    const siswa = await db.siswa.findUnique({
      where: { id: notification.siswaId },
      select: { sekolahId: true }
    });
    
    const response = await sendWhatsAppNotification({
      phone: notification.phone,
      message: notification.pesan,
      siswaId: notification.siswaId,
      absensiId: notification.absensiId,
      sekolahId: siswa?.sekolahId
    });
    
    if (!response.success) {
      await db.notifikasiQueue.update({
        where: { id: notification.id },
        data: {
          retryCount: { increment: 1 },
          errorMessage: response.error
        }
      });
    }
  }
}

// Test WhatsApp connection
export async function testWhatsAppConnection(sekolahId: string, phone: string): Promise<WhatsAppResponse> {
  const settings = await getWhatsAppSettings(sekolahId);
  
  if (!settings || !settings.isActive || !settings.apiKey) {
    return {
      success: false,
      error: 'WhatsApp tidak dikonfigurasi atau tidak aktif'
    };
  }
  
  const testMessage = `🧪 *TEST NOTIFIKASI*

Ini adalah pesan test dari Sistem Absensi Digital.

Waktu: ${new Date().toLocaleString('id-ID')}

Jika Anda menerima pesan ini, berarti konfigurasi WhatsApp berhasil! ✅

---
Pesan ini dikirim otomatis oleh Sistem Absensi Digital.`;
  
  return sendWhatsAppNotification({
    phone: formatPhoneNumber(phone),
    message: testMessage,
    siswaId: 'test',
    absensiId: 'test',
    sekolahId
  });
}
