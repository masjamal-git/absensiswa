/**
 * Server-side Socket.io emitter
 * Used by API routes to broadcast events to connected clients
 */

import { io as SocketIOClient } from 'socket.io-client';

const REALTIME_PORT = process.env.REALTIME_PORT || 3003;

// Singleton socket client connection
let socketClient: ReturnType<typeof SocketIOClient> | null = null;

function getSocketClient() {
  if (!socketClient) {
    socketClient = SocketIOClient(`http://localhost:${REALTIME_PORT}`, {
      transports: ['websocket'],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    socketClient.on('connect', () => {
      console.log('[Socket] Connected to realtime service');
    });

    socketClient.on('connect_error', (err) => {
      console.warn('[Socket] Connection error to realtime service:', err.message);
    });

    socketClient.on('disconnect', () => {
      console.log('[Socket] Disconnected from realtime service');
    });
  }
  return socketClient;
}

/**
 * Emit attendance update event to all connected clients in a sekolah room
 */
export function emitAttendanceUpdate(data: {
  sekolahId: string;
  siswaId: string;
  nama: string;
  kelas: string;
  status: string;
  jam: string;
  mode: string;
}): void {
  try {
    const client = getSocketClient();
    if (client.connected) {
      client.emit('new-attendance', data);
      console.log(`[Socket] Emitted attendance-update for ${data.nama} (${data.status})`);
    } else {
      console.warn('[Socket] Not connected, skipping attendance event');
    }
  } catch (err) {
    console.error('[Socket] Error emitting attendance update:', err);
  }
}

/**
 * Emit stats refresh event to all connected clients in a sekolah room
 */
export function emitStatsUpdate(data: {
  sekolahId: string;
  totalHadir: number;
  totalTerlambat: number;
  totalIzin: number;
  totalSakit: number;
  totalAlpa: number;
  totalSiswa: number;
}): void {
  try {
    const client = getSocketClient();
    if (client.connected) {
      client.emit('stats-update', data);
    }
  } catch (err) {
    console.error('[Socket] Error emitting stats update:', err);
  }
}
