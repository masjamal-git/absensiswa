/**
 * Timezone Utility
 * Handles timezone conversion for Indonesian time zones (WIB/WITA/WIT)
 * All server-side time calculations should go through this module.
 */

export const TIMEZONE_OPTIONS = [
  { value: 'Asia/Jakarta', label: 'WIB', description: 'Waktu Indonesia Barat (UTC+7)', offset: 7 },
  { value: 'Asia/Makassar', label: 'WITA', description: 'Waktu Indonesia Tengah (UTC+8)', offset: 8 },
  { value: 'Asia/Jayapura', label: 'WIT', description: 'Waktu Indonesia Timur (UTC+9)', offset: 9 },
] as const;

export type TimezoneValue = typeof TIMEZONE_OPTIONS[number]['value'];

/**
 * Get the UTC offset in hours for a given timezone name
 */
export function getTimezoneOffset(timezone: string): number {
  const found = TIMEZONE_OPTIONS.find(tz => tz.value === timezone);
  return found ? found.offset : 7; // Default to WIB
}

/**
 * Convert a Date to the target timezone's hours and minutes
 * Returns { hours, minutes } in the target timezone
 */
export function getTimeInTimezone(date: Date, timezone: string): { hours: number; minutes: number } {
  const offset = getTimezoneOffset(timezone);
  const utcMs = date.getTime() + (date.getTimezoneOffset() * 60000);
  const tzDate = new Date(utcMs + (offset * 60 * 60 * 1000));
  return {
    hours: tzDate.getHours(),
    minutes: tzDate.getMinutes(),
  };
}

/**
 * Format a Date as HH:mm in the given timezone
 */
export function formatTimeInTimezone(date: Date, timezone: string): string {
  const { hours, minutes } = getTimeInTimezone(date, timezone);
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
}

/**
 * Format a Date as full date string in Indonesian locale in the given timezone
 * Example: "Senin, 29 Maret 2026"
 */
export function formatDateInTimezone(date: Date, timezone: string): string {
  const offset = getTimezoneOffset(timezone);
  const utcMs = date.getTime() + (date.getTimezoneOffset() * 60000);
  const tzDate = new Date(utcMs + (offset * 60 * 60 * 1000));

  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  return `${days[tzDate.getDay()]}, ${tzDate.getDate()} ${months[tzDate.getMonth()]} ${tzDate.getFullYear()}`;
}

/**
 * Get the start of day (00:00:00) in the given timezone as a UTC Date
 * This is used for database queries (which store in UTC)
 */
export function getStartOfDayInTimezone(date: Date, timezone: string): Date {
  const offset = getTimezoneOffset(timezone);
  const utcMs = date.getTime() + (date.getTimezoneOffset() * 60000);
  const tzDate = new Date(utcMs + (offset * 60 * 60 * 1000));
  // Set to midnight in the target timezone
  tzDate.setHours(0, 0, 0, 0);
  // Convert back to UTC by subtracting the offset
  return new Date(tzDate.getTime() - (offset * 60 * 60 * 1000));
}

/**
 * Get end of day (23:59:59.999) in the given timezone as a UTC Date
 */
export function getEndOfDayInTimezone(date: Date, timezone: string): Date {
  const offset = getTimezoneOffset(timezone);
  const utcMs = date.getTime() + (date.getTimezoneOffset() * 60000);
  const tzDate = new Date(utcMs + (offset * 60 * 60 * 1000));
  // Set to end of day in the target timezone
  tzDate.setHours(23, 59, 59, 999);
  // Convert back to UTC by subtracting the offset
  return new Date(tzDate.getTime() - (offset * 60 * 60 * 1000));
}

/**
 * Get current time as a Date adjusted to the target timezone
 */
export function getNowInTimezone(timezone: string): Date {
  const offset = getTimezoneOffset(timezone);
  const now = new Date();
  const utcMs = now.getTime() + (now.getTimezoneOffset() * 60000);
  return new Date(utcMs + (offset * 60 * 60 * 1000));
}

/**
 * Format current datetime as locale string in the given timezone
 */
export function formatNowInTimezone(timezone: string): string {
  const tzDate = getNowInTimezone(timezone);
  return tzDate.toLocaleString('id-ID');
}

/**
 * Get current time in minutes since midnight in the given timezone
 * Used for attendance time window comparisons
 */
export function getCurrentMinutesInTimezone(timezone: string): number {
  const { hours, minutes } = getTimeInTimezone(new Date(), timezone);
  return hours * 60 + minutes;
}

/**
 * Check if current time is within an attendance time window
 * Returns { allowed, message }
 */
export function isWithinTimeWindow(
  timezone: string,
  jamBuka: string,
  jamTutup: string
): { allowed: boolean; message: string } {
  const [bukaJam, bukaMenit] = jamBuka.split(':').map(Number);
  const [tutupJam, tutupMenit] = jamTutup.split(':').map(Number);

  const currentMinutes = getCurrentMinutesInTimezone(timezone);
  const bukaMinutes = bukaJam * 60 + bukaMenit;
  const tutupMinutes = tutupJam * 60 + tutupMenit;

  if (currentMinutes < bukaMinutes) {
    return {
      allowed: false,
      message: `Sistem absensi belum dibuka. Absensi dapat dilakukan mulai pukul ${jamBuka}`
    };
  }

  if (currentMinutes > tutupMinutes) {
    return {
      allowed: false,
      message: `Sistem absensi sudah ditutup. Absensi hanya dapat dilakukan hingga pukul ${jamTutup}`
    };
  }

  return { allowed: true, message: '' };
}

/**
 * Check if student is late based on school's jam masuk and toleransi
 */
export function isLateInTimezone(
  timezone: string,
  jamMasuk: string,
  jamToleransi: string
): boolean {
  const [masukJam, masukMenit] = jamMasuk.split(':').map(Number);
  const toleransi = parseInt(jamToleransi);
  const batasTepatWaktu = masukJam * 60 + masukMenit + toleransi;
  const currentMinutes = getCurrentMinutesInTimezone(timezone);
  return currentMinutes > batasTepatWaktu;
}

/**
 * Format a date as yyyy-MM-dd in the given timezone (for date pickers)
 */
export function formatDateYYYYMMDD(date: Date, timezone: string): string {
  const offset = getTimezoneOffset(timezone);
  const utcMs = date.getTime() + (date.getTimezoneOffset() * 60000);
  const tzDate = new Date(utcMs + (offset * 60 * 60 * 1000));
  const year = tzDate.getFullYear();
  const month = (tzDate.getMonth() + 1).toString().padStart(2, '0');
  const day = tzDate.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
}
