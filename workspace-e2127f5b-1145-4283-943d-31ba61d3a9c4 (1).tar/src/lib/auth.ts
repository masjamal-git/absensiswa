import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from './db';
import { cookies } from 'next/headers';

const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key-change-in-production';
const JWT_EXPIRES_IN = '7d';

export interface JWTPayload {
  userId: string;
  email: string;
  role: string;
  sekolahId?: string;
  yayasanId?: string;
}

export interface AuthUser {
  id: string;
  email: string;
  nama: string;
  role: string;
  sekolahId?: string | null;
  yayasanId?: string | null;
  sekolah?: {
    id: string;
    nama: string;
    yayasanId: string;
  } | null;
}

// Hash password
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

// Verify password
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword);
}

// Generate JWT token
export function generateToken(payload: JWTPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

// Verify JWT token
export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JWTPayload;
  } catch {
    return null;
  }
}

// Get current user from cookies
export async function getCurrentUser(): Promise<AuthUser | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('auth-token')?.value;
    
    if (!token) return null;
    
    const payload = verifyToken(token);
    if (!payload) return null;
    
    const user = await db.user.findUnique({
      where: { id: payload.userId },
      include: {
        sekolah: {
          select: {
            id: true,
            nama: true,
            yayasanId: true
          }
        }
      }
    });
    
    if (!user || !user.isActive) return null;
    
    return {
      id: user.id,
      email: user.email,
      nama: user.nama,
      role: user.role,
      sekolahId: user.sekolahId,
      yayasanId: user.yayasanId,
      sekolah: user.sekolah
    };
  } catch {
    return null;
  }
}

// Set auth cookie
export async function setAuthCookie(token: string) {
  const cookieStore = await cookies();
  cookieStore.set('auth-token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7 // 7 days
  });
}

// Clear auth cookie
export async function clearAuthCookie() {
  const cookieStore = await cookies();
  cookieStore.delete('auth-token');
}

// Check if user has access to sekolah
export function hasAccessToSekolah(user: AuthUser, sekolahId: string): boolean {
  if (user.role === 'SUPER_ADMIN') return true;
  if (user.role === 'ADMIN_SEKOLAH' && user.sekolahId === sekolahId) return true;
  if (user.role === 'GURU' && user.sekolahId === sekolahId) return true;
  if (user.role === 'OPERATOR' && user.sekolahId === sekolahId) return true;
  return false;
}
