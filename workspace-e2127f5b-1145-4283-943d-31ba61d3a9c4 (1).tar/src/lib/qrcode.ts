import QRCode from 'qrcode';
import crypto from 'crypto';
import { db } from './db';

const QR_SECRET = process.env.QR_SECRET || 'qr-secret-key-change-in-production';

// Generate secure token for QR
export function generateSecureToken(siswaId: string, nis: string): string {
  const timestamp = Date.now();
  const data = `${siswaId}:${nis}:${timestamp}`;
  const hash = crypto.createHmac('sha256', QR_SECRET).update(data).digest('hex');
  return `${siswaId}.${hash.substring(0, 16)}`;
}

// Verify QR token by looking it up directly in the database
// This works regardless of token format (old hash-only or new siswaId.hash)
export async function verifyQRToken(token: string): Promise<{ siswaId: string } | null> {
  try {
    if (!token || typeof token !== 'string') return null;
    
    // Look up the token directly in DB - qrToken is @unique so this is efficient
    const siswa = await db.siswa.findUnique({
      where: { qrToken: token },
      select: { id: true, qrExpiredAt: true }
    });
    
    if (!siswa) return null;
    
    // Check expiration
    if (siswa.qrExpiredAt && new Date() > siswa.qrExpiredAt) return null;
    
    return { siswaId: siswa.id };
  } catch {
    return null;
  }
}

// Generate QR code as data URL
export async function generateQRCodeDataURL(token: string): Promise<string> {
  return QRCode.toDataURL(token, {
    errorCorrectionLevel: 'H',
    margin: 2,
    width: 300
  });
}

// Generate QR code as buffer
export async function generateQRCodeBuffer(token: string): Promise<Buffer> {
  return QRCode.toBuffer(token, {
    errorCorrectionLevel: 'H',
    margin: 2,
    width: 300
  });
}

// Regenerate QR token for siswa
export async function regenerateQRToken(siswaId: string): Promise<string> {
  const siswa = await db.siswa.findUnique({
    where: { id: siswaId },
    select: { id: true, nis: true }
  });
  
  if (!siswa) throw new Error('Siswa not found');
  
  const token = generateSecureToken(siswaId, siswa.nis);
  const expiredAt = new Date();
  expiredAt.setFullYear(expiredAt.getFullYear() + 1); // Valid for 1 year
  
  await db.siswa.update({
    where: { id: siswaId },
    data: { qrToken: token, qrExpiredAt: expiredAt }
  });
  
  return token;
}

// Regenerate QR tokens for all students in a school (batch)
export async function regenerateAllTokensForSekolah(sekolahId: string): Promise<number> {
  const siswaList = await db.siswa.findMany({
    where: { sekolahId },
    select: { id: true, nis: true }
  });
  
  const expiredAt = new Date();
  expiredAt.setFullYear(expiredAt.getFullYear() + 1);
  
  for (const siswa of siswaList) {
    const token = generateSecureToken(siswa.id, siswa.nis);
    await db.siswa.update({
      where: { id: siswa.id },
      data: { qrToken: token, qrExpiredAt: expiredAt }
    });
  }
  
  return siswaList.length;
}
