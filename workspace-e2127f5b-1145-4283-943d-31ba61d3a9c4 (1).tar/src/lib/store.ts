import { create } from 'zustand';

export interface User {
  id: string;
  email: string;
  nama: string;
  role: string;
  phone?: string | null;
  avatar?: string | null;
  isActive?: boolean;
  lastLogin?: string | null;
  createdAt?: string;
  updatedAt?: string;
  sekolahId?: string | null;
  yayasanId?: string | null;
  sekolah?: {
    id: string;
    nama: string;
    yayasanId: string;
  } | null;
  yayasan?: {
    id: string;
    nama: string;
  } | null;
}

export interface Sekolah {
  id: string;
  nama: string;
  npsn: string | null;
  jenis: string;
  jamMasuk: string;
  jamToleransi: string;
  jamPulang: string;
  jamToleransiPulang: string;
  jamBukaAbsen?: string;
  jamTutupAbsen?: string;
  jamBukaAbsenPulang?: string;
  jamTutupAbsenPulang?: string;
  absensiAktif?: boolean;
  _count?: {
    siswa: number;
    kelas: number;
  };
}

export interface Kelas {
  id: string;
  nama: string;
  tingkat: number;
  waliKelas: string | null;
}

export interface Siswa {
  id: string;
  nis: string;
  nisn: string | null;
  nama: string;
  jenisKelamin: string;
  kelas: {
    id: string;
    nama: string;
    tingkat: number;
  };
  qrToken: string;
  phoneAyah?: string | null;
  phoneIbu?: string | null;
  phoneWali?: string | null;
}

export interface Absensi {
  id: string;
  siswaId: string;
  tanggal: string;
  jamMasuk: string | null;
  status: string;
  metode: string;
  siswa: {
    nama: string;
    kelas: { nama: string };
  };
}

interface AppState {
  // Auth
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  
  // UI State
  currentPage: 'dashboard' | 'scanner' | 'siswa' | 'sekolah' | 'tahun-ajaran' | 'laporan' | 'pengaturan' | 'users';
  selectedSekolah: Sekolah | null;
  sidebarOpen: boolean;
  
  // Data
  sekolahList: Sekolah[];
  kelasList: Kelas[];
  
  // Actions
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  setCurrentPage: (page: AppState['currentPage']) => void;
  setSelectedSekolah: (sekolah: Sekolah | null) => void;
  setSidebarOpen: (open: boolean) => void;
  setSekolahList: (list: Sekolah[]) => void;
  setKelasList: (list: Kelas[]) => void;
  logout: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  currentPage: 'dashboard',
  selectedSekolah: null,
  sidebarOpen: false,
  sekolahList: [],
  kelasList: [],
  
  setUser: (user) => set({ user, isAuthenticated: !!user, isLoading: false }),
  setLoading: (loading) => set({ isLoading: loading }),
  setCurrentPage: (page) => set({ currentPage: page }),
  setSelectedSekolah: (sekolah) => set({ selectedSekolah: sekolah }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setSekolahList: (list) => set({ sekolahList: list }),
  setKelasList: (list) => set({ kelasList: list }),
  logout: () => set({ 
    user: null, 
    isAuthenticated: false, 
    selectedSekolah: null,
    currentPage: 'dashboard'
  })
}));
