# Panduan Setup Notifikasi WhatsApp

## Overview

Aplikasi ini mendukung notifikasi WhatsApp otomatis ke orang tua/wali siswa ketika:
- Siswa scan QR untuk absen masuk
- Siswa scan QR untuk absen pulang
- Absensi manual dicatat (opsional)

## Provider WhatsApp yang Didukung

### 1. Fonnte (Rekomendasi untuk Indonesia)

**Keunggulan:**
- Harga terjangkau (mulai Rp 75.000/bulan)
- Support Indonesia
- Mudah integrasi
- No ribet, cukup scan QR sekali

**Langkah Setup Fonnte:**

1. **Daftar Fonnte**
   - Buka https://fonnte.com
   - Daftar dengan nomor WhatsApp yang akan digunakan
   - Verifikasi via WhatsApp

2. **Dapatkan API Key**
   - Login ke dashboard Fonnte
   - Copy API Key dari menu "Api Key"

3. **Konfigurasi Environment Variables**
   Di file `.env` atau di dashboard hosting:
   ```
   WHATSAPP_PROVIDER=fonnte
   WHATSAPP_API_KEY=your_api_key_from_fonnte
   WHATSAPP_API_URL=https://api.fonnte.com/send
   ```

4. **Test Koneksi**
   - Di aplikasi, buka menu Pengaturan
   - Masukkan nomor HP untuk test
   - Klik "Kirim Test"

### 2. Twilio WhatsApp API

**Keunggulan:**
- Provider global terpercaya
- Free trial tersedia
- Dokumentasi lengkap

**Langkah Setup Twilio:**

1. Daftar di https://www.twilio.com/whatsapp
2. Dapatkan Account SID dan Auth Token
3. Aktifkan WhatsApp Sandbox
4. Konfigurasi:
   ```
   WHATSAPP_PROVIDER=twilio
   TWILIO_ACCOUNT_SID=your_account_sid
   TWILIO_AUTH_TOKEN=your_auth_token
   TWILIO_FROM_NUMBER=whatsapp:+14155238886
   ```

### 3. WhatsApp Business API (Official)

Untuk skala enterprise dengan volume tinggi:
- Daftar di https://developers.facebook.com/docs/whatsapp
- Butuh verifikasi bisnis
- Lebih kompleks tapi official

## Konfigurasi di Aplikasi

### Environment Variables

Buat file `.env.local` atau set di hosting:

```env
# WhatsApp Configuration
WHATSAPP_PROVIDER=fonnte          # 'fonnte', 'twilio', atau 'mock'
WHATSAPP_API_KEY=your_api_key     # API key dari provider
WHATSAPP_API_URL=https://api.fonnte.com/send  # URL API (optional)
```

### Mock Mode (Testing)

Jika belum ada API key, aplikasi akan menggunakan mock mode:
- Tidak mengirim pesan real
- Log akan muncul di console
- Cocok untuk development/testing

## Format Pesan

Pesan yang dikirim ke orang tua:

```
✅ *NOTIFIKASI ABSENSI*

Sekolah: MA Al Mujahidin Samarinda
Tanggal: Senin, 1 Januari 2025

Ananda *Ahmad Fauzi* (Kelas X IPA 1) telah hadir pada pukul *07:15* WIB.

_Status: HADIR_

---
Pesan ini dikirim otomatis oleh Sistem Absensi Digital.
```

## Format Nomor HP

Sistem otomatis mengkonversi format nomor:
- `08123456789` → `628123456789`
- `+628123456789` → `628123456789`
- `628123456789` → `628123456789`

## Troubleshooting

### Pesan Tidak Terkirim

1. **Cek API Key**
   - Pastikan API key benar dan aktif
   - Cek di dashboard provider

2. **Cek Nomor HP**
   - Format harus benar (08xxx)
   - Pastikan nomor aktif di WhatsApp

3. **Cek Saldo/Kuota**
   - Fonnte: cek sisa saldo
   - Twilio: cek credit

4. **Cek Log**
   - Di console server akan ada error message
   - Di database `NotifikasiQueue` ada status dan error

### Error Umum

| Error | Penyebab | Solusi |
|-------|----------|--------|
| Invalid API Key | API key salah | Cek kembali API key |
| Number not registered | Nomor tidak ada di WhatsApp | Pastikan nomor valid |
| Insufficient balance | Saldo habis | Top up saldo |
| Rate limit exceeded | Terlalu banyak request | Tunggu beberapa menit |

## Monitoring Notifikasi

### Database

Cek status notifikasi di table `NotifikasiQueue`:
- `PENDING` - Antrian pengiriman
- `SENT` - Terkirim berhasil
- `FAILED` - Gagal kirim

### Table Absensi

Field terkait di table `Absensi`:
- `notifSent` - Boolean status terkirim
- `notifSentAt` - Waktu pengiriman
- `notifStatus` - Status detail
- `notifRetry` - Jumlah percobaan

## Tips & Best Practices

1. **Testing**
   - Selalu test dengan nomor sendiri dulu
   - Gunakan mock mode untuk development

2. **Backup Provider**
   - Siapkan 2 provider untuk failover
   - Monitor status pengiriman

3. **Rate Limiting**
   - Jangan spam pesan
   - Rate limit Fonnte: 60 pesan/menit

4. **Privacy**
   - Simpan API key dengan aman
   - Jangan commit ke git

## Biaya Estimasi

| Provider | Biaya | Catatan |
|----------|-------|---------|
| Fonnte | Rp 75.000/bln (500 pesan) | Cocok untuk sekolah kecil |
| Fonnte | Rp 150.000/bln (2000 pesan) | Cocok untuk sekolah menengah |
| Twilio | $0.005/pesan | Perlu credit card |
| Mock | Gratis | Tidak kirim real |

## Dukungan

- Fonnte Support: https://fonnte.com/kontak
- Twilio Support: https://support.twilio.com
- WhatsApp API Docs: https://developers.facebook.com/docs/whatsapp
