#!/bin/bash
cd /home/z/my-project
while true; do
    echo "Starting Next.js dev server..."
    bun x next dev -p 3000
    echo "Server exited. Restarting in 2 seconds..."
    sleep 2
done
