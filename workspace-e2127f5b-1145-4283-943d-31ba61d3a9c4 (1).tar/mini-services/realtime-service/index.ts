import { Server } from 'socket.io';

const PORT = 3003;

const io = new Server(PORT, {
  cors: {
    origin: ['http://localhost:3000', 'http://127.0.0.1:3000'],
    methods: ['GET', 'POST'],
    credentials: true
  }
});

console.log(`🔌 Real-time service running on port ${PORT}`);

// Store connected clients per sekolah
const sekolahRooms = new Map<string, Set<string>>();

io.on('connection', (socket) => {
  console.log(`📱 Client connected: ${socket.id}`);
  
  // Join sekolah room
  socket.on('join-sekolah', (sekolahId: string) => {
    socket.join(`sekolah:${sekolahId}`);
    
    if (!sekolahRooms.has(sekolahId)) {
      sekolahRooms.set(sekolahId, new Set());
    }
    sekolahRooms.get(sekolahId)!.add(socket.id);
    
    console.log(`👥 Client ${socket.id} joined sekolah ${sekolahId}`);
    socket.emit('joined-sekolah', { sekolahId, success: true });
  });
  
  // Leave sekolah room
  socket.on('leave-sekolah', (sekolahId: string) => {
    socket.leave(`sekolah:${sekolahId}`);
    
    if (sekolahRooms.has(sekolahId)) {
      sekolahRooms.get(sekolahId)!.delete(socket.id);
    }
    
    console.log(`👋 Client ${socket.id} left sekolah ${sekolahId}`);
  });
  
  // New attendance event
  socket.on('new-attendance', (data: {
    sekolahId: string;
    siswaId: string;
    nama: string;
    kelas: string;
    status: string;
    jam: string;
    foto?: string;
  }) => {
    console.log(`✅ New attendance: ${data.nama} - ${data.status}`);
    
    // Broadcast to all clients in the sekolah room
    io.to(`sekolah:${data.sekolahId}`).emit('attendance-update', {
      ...data,
      timestamp: new Date().toISOString()
    });
  });
  
  // Statistics update
  socket.on('stats-update', (data: {
    sekolahId: string;
    totalHadir: number;
    totalTerlambat: number;
    totalIzin: number;
    totalSakit: number;
    totalAlpa: number;
    totalSiswa: number;
  }) => {
    io.to(`sekolah:${data.sekolahId}`).emit('stats-refresh', data);
  });
  
  // Disconnect
  socket.on('disconnect', () => {
    console.log(`📱 Client disconnected: ${socket.id}`);
    
    // Remove from all rooms
    sekolahRooms.forEach((clients, sekolahId) => {
      if (clients.has(socket.id)) {
        clients.delete(socket.id);
      }
    });
  });
});

// API endpoint for triggering attendance notification
// This can be called from the Next.js API route
io.of('/api').on('connection', (socket) => {
  socket.on('broadcast-attendance', (data) => {
    io.to(`sekolah:${data.sekolahId}`).emit('attendance-update', data);
  });
});

export { io };
