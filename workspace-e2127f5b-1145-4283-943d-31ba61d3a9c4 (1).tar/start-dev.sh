#!/bin/bash
cd /home/z/my-project
while true; do
  echo "[$(date)] Starting..." >> /home/z/my-project/dev.log 2>&1
  bun run dev >> /home/z/my-project/dev.log 2>&1
  EXIT_CODE=$?
  echo "[$(date)] Exited with code $EXIT_CODE, restarting in 3s..." >> /home/z/my-project/dev.log 2>&1
  sleep 3
done
