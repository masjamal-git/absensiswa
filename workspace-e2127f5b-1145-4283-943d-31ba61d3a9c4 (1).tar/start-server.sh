#!/bin/bash
cd /home/z/my-project
while true; do
    echo "Starting Next.js server..."
    node .next/standalone/server.js
    EXIT_CODE=$?
    echo "Server exited with code $EXIT_CODE"
    if [ $EXIT_CODE -eq 0 ]; then
        break
    fi
    sleep 2
done
