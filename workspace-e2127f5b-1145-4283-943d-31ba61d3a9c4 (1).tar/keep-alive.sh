#!/bin/bash
cd /home/z/my-project
while true; do
    echo "[$(date)] Starting Next.js server..."
    bun run dev 2>&1
    echo "[$(date)] Server exited. Restarting in 2 seconds..."
    sleep 2
done
